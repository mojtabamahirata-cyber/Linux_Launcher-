plugins { id("com.android.application") }

android {
    namespace = "com.sparrow.launcher"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.sparrow.launcher"
        minSdk = 26
        targetSdk = 33
        versionCode = 16
        versionName = "1.0-clean-architecture"
    }
}
