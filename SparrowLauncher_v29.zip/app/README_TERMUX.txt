Sparrow Launcher v16 (clean architecture)
البناء في Termux:
  cd SparrowLauncher && gradle assembleDebug
  الناتج: app/build/outputs/apk/debug/app-debug.apk
  termux-open app/build/outputs/apk/debug/app-debug.apk
إذا طلع خطأ Compile: ألصق أول 15 سطر من الخطأ وأصلحه.
