package com.sparrow.launcher.gestures

import android.content.Intent
import android.provider.Settings
import com.sparrow.launcher.core.Prefs

/** الإيماءات القابلة للتخصيص. القيمة المحفوظة بصيغة "النوع|المعطى" مثل app|pkg/class */
object GestureActions {
    val NAMES = listOf(
        "swipe_down" to "السحب للأسفل",
        "swipe_up" to "السحب للأعلى",
        "double_tap" to "النقر المزدوج",
        "two_left" to "سحب بإصبعين لليسار",
        "two_right" to "سحب بإصبعين لليمين",
        "pinch" to "تصغير بإصبعين (Pinch)"
    )

    val TYPES = listOf(
        "none" to "لا شيء",
        "drawer" to "فتح App Drawer",
        "search" to "فتح البحث",
        "overview" to "Workspace Overview",
        "recents" to "التطبيقات الأخيرة",
        "controls" to "لوحة التحكم ثلاثية الأبعاد",
        "settings" to "إعدادات Sparrow",
        "next" to "الصفحة التالية",
        "prev" to "الصفحة السابقة",
        "hidden" to "التطبيقات المخفية",
        "menu" to "قائمة التخصيص",
        "app" to "فتح تطبيق…",
        "image" to "فتح صورة…",
        "sysset" to "فتح إعداد أندرويد…",
        "workspace" to "الذهاب إلى Workspace…"
    )

    val SYSTEM_SETTINGS = listOf(
        "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
        "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "العرض" to Settings.ACTION_DISPLAY_SETTINGS,
        "الصوت" to Settings.ACTION_SOUND_SETTINGS,
        "البطارية" to Intent.ACTION_POWER_USAGE_SUMMARY,
        "التخزين" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        "التطبيقات" to Settings.ACTION_APPLICATION_SETTINGS,
        "الموقع" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        "إمكانية الوصول" to Settings.ACTION_ACCESSIBILITY_SETTINGS,
        "وضع الطيران" to Settings.ACTION_AIRPLANE_MODE_SETTINGS
    )

    fun default(name: String): String = when (name) {
        "swipe_down" -> "drawer"
        "swipe_up" -> "search"
        "double_tap" -> "recents"
        "pinch" -> "overview"
        "two_left" -> "controls"
        else -> "none"
    }

    fun spec(name: String): String = Prefs.str("g_$name", default(name))

    fun typeLabel(spec: String): String {
        val t = spec.substringBefore("|")
        return TYPES.firstOrNull { it.first == t }?.second ?: "لا شيء"
    }
}
