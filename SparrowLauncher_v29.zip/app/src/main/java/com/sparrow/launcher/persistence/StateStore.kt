package com.sparrow.launcher.persistence

import android.content.Context
import com.sparrow.launcher.core.Bg
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * مصدر الحقيقة الوحيد لكل بيانات اللانشر (Workspaces, Folders, المخفي، الأسماء، الأيقونات ...).
 * يُحفظ في ملف JSON داخل التطبيق (كتابة ذرية + نسخة احتياطية) فيبقى بعد إعادة تشغيل الهاتف.
 * كل التعديل يتم على الخيط الرئيسي، والكتابة على القرص في خيط خلفي.
 */
object StateStore {
    val workspaces = ArrayList<Workspace>()
    val folders = LinkedHashMap<String, Folder>()
    val hidden = LinkedHashSet<String>()
    val names = HashMap<String, String>()        // اسم مخصص لتطبيق
    val icons = HashMap<String, String>()        // مسار أيقونة مخصصة لتطبيق
    val categories = HashMap<String, String>()   // تصنيف يدوي لتطبيق
    val launchCount = HashMap<String, Int>()
    val lastLaunch = HashMap<String, Long>()
    val recents = ArrayList<String>()            // الأحدث أولاً
    val dock = ArrayList<String>()               // Dock واحد لكل الصفحات ("a:key" أو "f:id")
    var homeIndex = 0
    var currentIndex = 0

    private var file: File? = null
    private var seq = 0
    private val saveTask = Runnable { flush() }

    fun newId(prefix: String): String {
        seq++
        return prefix + System.currentTimeMillis().toString(36) + seq
    }

    // ------------------------------------------------------------ تحميل
    fun load(ctx: Context) {
        if (file != null) return // محمّل مسبقاً في هذه العملية: لا نقرأ الملف القديم فوق التعديلات غير المحفوظة
        val f = File(ctx.filesDir, "launcher_state.json")
        file = f
        val bak = File(f.parentFile, f.name + ".bak")
        for (c in listOf(f, bak)) {
            if (!c.exists()) continue
            try {
                parse(JSONObject(c.readText()))
                break
            } catch (e: Exception) {
                clear()
            }
        }
        if (workspaces.isEmpty()) {
            for (i in 1..3) addWorkspace("مساحة $i")
        }
        homeIndex = homeIndex.coerceIn(0, workspaces.size - 1)
        currentIndex = currentIndex.coerceIn(0, workspaces.size - 1)
    }

    private fun clear() {
        workspaces.clear(); folders.clear(); hidden.clear(); names.clear(); icons.clear()
        categories.clear(); launchCount.clear(); lastLaunch.clear(); recents.clear(); dock.clear()
        homeIndex = 0; currentIndex = 0
    }

    private fun readStrMap(o: JSONObject?, m: MutableMap<String, String>) {
        if (o == null) return
        val ks = o.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            m[k] = o.getString(k)
        }
    }

    private fun parse(o: JSONObject) {
        clear()
        homeIndex = o.optInt("home")
        currentIndex = o.optInt("cur")
        val ws = o.optJSONArray("ws") ?: JSONArray()
        for (i in 0 until ws.length()) {
            val w = ws.getJSONObject(i)
            val wk = Workspace(w.getString("id"), w.optString("name", "مساحة"), w.optInt("tint"))
            val its = w.optJSONArray("items") ?: JSONArray()
            for (j in 0 until its.length()) {
                val x = its.getJSONObject(j)
                wk.items.add(
                    Item(
                        x.getString("id"), x.getString("t"), x.getString("r"),
                        x.getInt("c"), x.getInt("w"), x.optInt("sx", 1), x.optInt("sy", 1)
                    )
                )
            }
            val d = w.optJSONArray("dock") ?: JSONArray()
            for (j in 0 until d.length()) wk.dock.add(d.getString(j))
            workspaces.add(wk)
        }
        val fs = o.optJSONArray("folders") ?: JSONArray()
        for (i in 0 until fs.length()) {
            val x = fs.getJSONObject(i)
            val f = Folder(
                x.getString("id"), x.optString("name", "مجلد"), x.optString("emoji"),
                x.optString("icon"), x.optInt("color"), x.optString("view", "grid")
            )
            val a = x.optJSONArray("apps") ?: JSONArray()
            for (j in 0 until a.length()) f.apps.add(a.getString(j))
            val c = x.optJSONArray("subs") ?: JSONArray()
            for (j in 0 until c.length()) f.folders.add(c.getString(j))
            folders[f.id] = f
        }
        val h = o.optJSONArray("hidden") ?: JSONArray()
        for (i in 0 until h.length()) hidden.add(h.getString(i))
        readStrMap(o.optJSONObject("names"), names)
        readStrMap(o.optJSONObject("icons"), icons)
        readStrMap(o.optJSONObject("cats"), categories)
        val lc = o.optJSONObject("count")
        if (lc != null) {
            val ks = lc.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                launchCount[k] = lc.getInt(k)
            }
        }
        val ll = o.optJSONObject("last")
        if (ll != null) {
            val ks = ll.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                lastLaunch[k] = ll.getLong(k)
            }
        }
        val r = o.optJSONArray("recents") ?: JSONArray()
        for (i in 0 until r.length()) recents.add(r.getString(i))
        val gd = o.optJSONArray("gdock") ?: JSONArray()
        for (i in 0 until gd.length()) dock.add(gd.getString(i))
        // ترحيل من النسخ القديمة: Dock كان لكل مساحة، الآن واحد للجميع
        if (dock.isEmpty()) for (w in workspaces) if (w.dock.isNotEmpty()) { dock.addAll(w.dock); break }
        for (w in workspaces) w.dock.clear()
    }

    // ------------------------------------------------------------ حفظ
    private fun toJson(): String {
        val o = JSONObject()
        o.put("home", homeIndex)
        o.put("cur", currentIndex)
        val ws = JSONArray()
        for (w in workspaces) {
            val j = JSONObject()
            j.put("id", w.id)
            j.put("name", w.name)
            j.put("tint", w.tint)
            val its = JSONArray()
            for (i in w.items) {
                val x = JSONObject()
                x.put("id", i.id); x.put("t", i.type); x.put("r", i.ref)
                x.put("c", i.col); x.put("w", i.row); x.put("sx", i.sx); x.put("sy", i.sy)
                its.put(x)
            }
            j.put("items", its)
            j.put("dock", JSONArray(w.dock))
            ws.put(j)
        }
        o.put("ws", ws)
        val fs = JSONArray()
        for (f in folders.values) {
            val x = JSONObject()
            x.put("id", f.id); x.put("name", f.name); x.put("emoji", f.emoji)
            x.put("icon", f.iconPath); x.put("color", f.color); x.put("view", f.view)
            x.put("apps", JSONArray(f.apps))
            x.put("subs", JSONArray(f.folders))
            fs.put(x)
        }
        o.put("folders", fs)
        o.put("hidden", JSONArray(hidden))
        o.put("names", JSONObject(names as Map<*, *>))
        o.put("icons", JSONObject(icons as Map<*, *>))
        o.put("cats", JSONObject(categories as Map<*, *>))
        o.put("count", JSONObject(launchCount as Map<*, *>))
        o.put("last", JSONObject(lastLaunch as Map<*, *>))
        o.put("recents", JSONArray(recents))
        o.put("gdock", JSONArray(dock))
        return o.toString()
    }

    fun exportState(): String = toJson()

    /** استرجاع نسخة احتياطية. إذا كان الملف تالفاً نرجع للحالة السابقة ولا نخسر شيئاً */
    fun importState(text: String): Boolean {
        val prev = toJson()
        return try {
            parse(JSONObject(text))
            if (workspaces.isEmpty()) addWorkspace("مساحة 1")
            homeIndex = homeIndex.coerceIn(0, workspaces.size - 1)
            currentIndex = currentIndex.coerceIn(0, workspaces.size - 1)
            flush()
            true
        } catch (e: Exception) {
            parse(JSONObject(prev))
            false
        }
    }

    /** حفظ مؤجل (يجمع التعديلات المتتالية في كتابة واحدة) */
    fun save() {
        Bg.main.removeCallbacks(saveTask)
        Bg.main.postDelayed(saveTask, 500)
    }

    /** حفظ فوري (يُستدعى عند إيقاف التطبيق) */
    fun flush() {
        Bg.main.removeCallbacks(saveTask)
        val f = file ?: return
        val text = try { toJson() } catch (e: Exception) { return }
        Bg.io.execute {
            try {
                val tmp = File(f.parentFile, f.name + ".tmp")
                tmp.writeText(text)
                if (f.exists()) f.copyTo(File(f.parentFile, f.name + ".bak"), true)
                if (!tmp.renameTo(f)) {
                    f.delete()
                    tmp.renameTo(f)
                }
            } catch (_: Exception) {
            }
        }
    }

    // ------------------------------------------------------------ Workspaces
    fun addWorkspace(name: String): Workspace {
        val w = Workspace(newId("ws"), name)
        workspaces.add(w)
        return w
    }

    fun removeWorkspace(idx: Int): Workspace? {
        if (workspaces.size <= 1 || idx !in workspaces.indices) return null
        val w = workspaces.removeAt(idx)
        if (homeIndex >= workspaces.size) homeIndex = workspaces.size - 1
        else if (idx < homeIndex) homeIndex--
        currentIndex = currentIndex.coerceIn(0, workspaces.size - 1)
        return w
    }

    fun moveWorkspace(from: Int, to: Int): Boolean {
        if (from !in workspaces.indices || to !in workspaces.indices || from == to) return false
        val w = workspaces.removeAt(from)
        workspaces.add(to, w)
        if (homeIndex == from) homeIndex = to
        else if (from < homeIndex && to >= homeIndex) homeIndex--
        else if (from > homeIndex && to <= homeIndex) homeIndex++
        return true
    }

    // ------------------------------------------------------------ الشبكة
    fun isFree(ws: Workspace, col: Int, row: Int, sx: Int, sy: Int, cols: Int, rows: Int, ignore: Item? = null): Boolean {
        if (col < 0 || row < 0 || col + sx > cols || row + sy > rows) return false
        for (o in ws.items) {
            if (o === ignore) continue
            if (col < o.col + o.sx && col + sx > o.col && row < o.row + o.sy && row + sy > o.row) return false
        }
        return true
    }

    fun findFree(ws: Workspace, sx: Int, sy: Int, cols: Int, rows: Int): Pair<Int, Int>? {
        for (r in 0..(rows - sy)) {
            for (c in 0..(cols - sx)) {
                if (isFree(ws, c, r, sx, sy, cols, rows)) return Pair(c, r)
            }
        }
        return null
    }

    /**
     * عند تغيير أبعاد الشبكة: يقلّص/ينقل العناصر التي خرجت عن الحدود.
     * يرجع قائمة العناصر التي لم تجد مكاناً (ليُحذف الويدجت الخاص بها من النظام).
     */
    fun relayout(cols: Int, rows: Int): List<Item> {
        val lost = ArrayList<Item>()
        for (w in workspaces) {
            for (it in ArrayList(w.items)) {
                if (it.col + it.sx <= cols && it.row + it.sy <= rows) continue
                it.sx = it.sx.coerceAtMost(cols)
                it.sy = it.sy.coerceAtMost(rows)
                w.items.remove(it)
                val pos = findFree(w, it.sx, it.sy, cols, rows)
                if (pos == null) lost.add(it) else {
                    it.col = pos.first; it.row = pos.second
                    w.items.add(it)
                }
            }
        }
        save()
        return lost
    }

    // ------------------------------------------------------------ تطبيقات ومجلدات
    fun recordLaunch(key: String) {
        launchCount[key] = (launchCount[key] ?: 0) + 1
        lastLaunch[key] = System.currentTimeMillis()
        recents.remove(key)
        recents.add(0, key)
        while (recents.size > 20) recents.removeAt(recents.size - 1)
        save()
    }

    fun removeAppFromHome(key: String) {
        for (w in workspaces) {
            w.items.removeAll { it.type == Item.APP && it.ref == key }
            w.dock.remove("a:$key")
        }
        dock.remove("a:$key")
    }

    fun newFolder(name: String): Folder {
        val f = Folder(newId("f"), name, color = 0x8C5B7BD5.toInt(), view = com.sparrow.launcher.core.Prefs.folderView)
        folders[f.id] = f
        return f
    }

    fun parentOf(id: String): Folder? = folders.values.firstOrNull { id in it.folders }

    /** المجلد + كل أبنائه على أي عمق */
    fun descendants(id: String): Set<String> {
        val out = LinkedHashSet<String>()
        val st = ArrayDeque<String>()
        st.add(id)
        while (st.isNotEmpty()) {
            val c = st.removeFirst()
            if (out.add(c)) folders[c]?.let { st.addAll(it.folders) }
        }
        return out
    }

    fun addAppToFolder(fid: String, key: String) {
        val f = folders[fid] ?: return
        removeAppFromHome(key)
        for (o in folders.values) o.apps.remove(key)
        f.apps.add(key)
        save()
    }

    /** إزالة مجلد من كل أماكنه (الصفحات، الـ Dock، مجلد أب) دون حذفه */
    fun detachFolder(id: String) {
        for (w in workspaces) {
            w.items.removeAll { it.type == Item.FOLDER && it.ref == id }
            w.dock.remove("f:$id")
        }
        dock.remove("f:$id")
        for (o in folders.values) o.folders.remove(id)
    }

    fun moveFolderInto(child: String, parent: String): Boolean {
        if (child == parent || parent in descendants(child)) return false
        val p = folders[parent] ?: return false
        detachFolder(child)
        p.folders.add(child)
        save()
        return true
    }

    fun deleteFolder(id: String) {
        val all = descendants(id)
        for (fid in all) detachFolder(fid)
        for (fid in all) folders.remove(fid)
        save()
    }

    /** تنظيف المراجع لتطبيقات لم تعد مثبتة */
    fun prune(valid: Set<String>) {
        for (w in workspaces) {
            w.items.removeAll { it.type == Item.APP && it.ref !in valid }
            w.dock.removeAll { it.startsWith("a:") && it.substring(2) !in valid }
        }
        dock.removeAll { it.startsWith("a:") && it.substring(2) !in valid }
        for (f in folders.values) f.apps.removeAll { it !in valid }
        recents.removeAll { it !in valid }
    }
}
