package com.sparrow.launcher.widgets

import android.service.notification.NotificationListenerService

/** فارغة عمداً: وجودها مع تفعيل المستخدم لها يسمح بقراءة MediaSession (Spotify وغيره) */
class SparrowNotificationListener : NotificationListenerService()
