package com.sparrow.launcher.appdrawer

import android.content.Context
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import com.sparrow.launcher.apps.AppCellView
import com.sparrow.launcher.apps.AppInfo
import com.sparrow.launcher.apps.AppRepository
import com.sparrow.launcher.apps.Categories
import com.sparrow.launcher.core.Bg
import com.sparrow.launcher.core.Icons
import com.sparrow.launcher.core.LauncherController
import com.sparrow.launcher.core.Overlay
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.core.afterLayout
import com.sparrow.launcher.persistence.StateStore
import kotlin.math.abs

/**
 * App Drawer: GridView (يعيد تدوير الخلايا فلا يتأثر بعدد التطبيقات).
 * البحث والفرز والتصنيف يتم في خيط خلفي مع تأخير قصير (debounce) وإلغاء النتائج القديمة، فلا يحدث Freeze.
 */
class DrawerView(
    ctx: Context,
    private val c: LauncherController,
    private val hiddenMode: Boolean,
    private val topInset: Int,
    private val bottomInset: Int,
    private val pickMode: ((AppInfo) -> Unit)? = null
) : FrameLayout(ctx), Overlay {

    override val depth: Float get() = 1f

    private val search = EditText(ctx)
    private val chips = LinearLayout(ctx)
    private val grid = GridView(ctx)
    private val adapter = Adapter()
    private var shown: List<AppInfo> = emptyList()
    private var filter = "all"
    private var query = ""
    private var gen = 0
    private var downY = 0f
    private var downX = 0f
    private val refreshRun = Runnable { refresh() }

    init {
        layoutDirection = Ui.layoutDir()
        setBackgroundColor(Theme.surface(ctx))
        isClickable = true

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(ctx, 12), topInset + Ui.dp(ctx, 12), Ui.dp(ctx, 12), bottomInset)
        addView(col, LayoutParams(-1, -1))

        // شريط البحث + زر الفرز
        val top = LinearLayout(ctx)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        search.hint = if (hiddenMode) "بحث في التطبيقات المخفية" else "ابحث في التطبيقات"
        search.setHintTextColor(Theme.sub(ctx))
        search.setTextColor(Theme.text(ctx))
        search.typeface = Prefs.typeface()
        search.isSingleLine = true
        search.inputType = InputType.TYPE_CLASS_TEXT
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.background = Theme.panel(ctx, Ui.dpf(ctx, 24f))
        search.setPadding(Ui.dp(ctx, 18), Ui.dp(ctx, 10), Ui.dp(ctx, 18), Ui.dp(ctx, 10))
        search.setCompoundDrawablesRelative(Icons.drawable(ctx, "search", 20, Theme.sub(ctx)), null, null, null)
        search.compoundDrawablePadding = Ui.dp(ctx, 10)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, cc: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, cc: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                Bg.main.removeCallbacks(refreshRun)
                Bg.main.postDelayed(refreshRun, 90)
            }
        })
        search.setOnEditorActionListener { _, _, _ ->
            if (shown.isNotEmpty()) activate(shown[0], null)
            true
        }
        top.addView(search, LinearLayout.LayoutParams(0, -2, 1f))
        val sort = com.sparrow.launcher.core.Icons.button(ctx, "sort", Theme.text(ctx), true) { sortMenu() }
        top.addView(sort, LinearLayout.LayoutParams(Ui.dp(ctx, 46), Ui.dp(ctx, 46)).apply { setMargins(Ui.dp(ctx, 8), 0, 0, 0) })
        col.addView(top, LinearLayout.LayoutParams(-1, -2))

        // التصنيفات
        if (Prefs.drawerChips && !hiddenMode) {
            val hs = HorizontalScrollView(ctx)
            hs.isHorizontalScrollBarEnabled = false
            chips.orientation = LinearLayout.HORIZONTAL
            hs.addView(chips)
            col.addView(hs, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 10) })
            buildChips()
        }

        grid.numColumns = Prefs.drawerCols.coerceIn(3, 6)
        grid.adapter = adapter
        grid.selector = android.graphics.drawable.ColorDrawable(0)
        grid.setVerticalSpacing(Ui.dp(ctx, 6))
        grid.isVerticalScrollBarEnabled = false
        grid.overScrollMode = View.OVER_SCROLL_NEVER
        grid.setOnItemClickListener { _, v, pos, _ -> activate(shown[pos], v) }
        grid.setOnItemLongClickListener { _, v, pos, _ ->
            if (pickMode == null) c.dragFromDrawer(v, shown[pos])
            true
        }
        col.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = Ui.dp(ctx, 10) })

        refresh()

        // دخول: ينزلق من الأسفل
        alpha = 0f
        afterLayout {
            translationY = height * 0.12f
            scaleX = 0.94f
            scaleY = 0.94f
            val d = if (Prefs.reduceMotion) 0L else 240L
            animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(d).setInterpolator(android.view.animation.PathInterpolator(0.05f, 0.7f, 0.1f, 1f)).start()
        }
    }

    private fun activate(a: AppInfo, v: View?) {
        val pm = pickMode
        if (pm != null) { c.closeOverlay(this); pm(a) } else c.launchApp(a.key, v)
    }

    fun setHint(t: String) { search.hint = t }

    fun focusSearch() {
        search.requestFocus()
        search.post {
            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(search, 0)
        }
    }

    private fun hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }

    /** يعاد بناؤها عند تغير قائمة التطبيقات أو تصنيفاتها */
    fun buildChips() {
        if (!Prefs.drawerChips || hiddenMode) return
        chips.removeAllViews()
        fun chip(id: String, label: String) {
            val sel = filter == id
            val t = Ui.text(context, label, 13f, if (sel) 0xFF0B1020.toInt() else Theme.text(context), true)
            Icons.withText(context, t, catIcon(id), 15, if (sel) 0xFF0B1020.toInt() else Theme.text(context))
            t.setPadding(Ui.dp(context, 14), Ui.dp(context, 7), Ui.dp(context, 14), Ui.dp(context, 7))
            t.background = if (sel) Ui.round(Theme.ACCENT, Ui.dpf(context, 18f)) else Theme.panel(context, Ui.dpf(context, 18f))
            t.setOnClickListener { filter = id; buildChips(); refresh() }
            chips.addView(t, LinearLayout.LayoutParams(-2, -2).apply { setMargins(Ui.dp(context, 3), 0, Ui.dp(context, 3), 0) })
        }
        chip("all", "الكل")
        chip("recent", "الأخيرة")
        chip("used", "الأكثر استخداماً")
        val present = LinkedHashSet<String>()
        for (a in AppRepository.apps) present.add(Categories.of(a))
        for (b in Categories.builtin) if (b in present) chip("cat:$b", Categories.name(b))
        for (p in present) if (p.startsWith("c:")) chip("cat:$p", Categories.name(p))
    }

    /** رمز لكل تصنيف يظهر يسار اسمه */
    private fun catIcon(id: String): String = when (id) {
        "all" -> "apps"; "recent" -> "star"; "used" -> "flame"
        "cat:comm" -> "chat"; "cat:social" -> "globe"; "cat:games" -> "gamepad"; "cat:media" -> "music"
        "cat:prod" -> "briefcase"; "cat:tools" -> "gear"; "cat:finance" -> "coin"; "cat:edu" -> "book"
        "cat:system" -> "lock"; "cat:other" -> "apps"
        else -> "folder"
    }

    private fun sortMenu() {
        val ids = listOf("az", "za", "recent", "used")
        Ui.list(context, "ترتيب التطبيقات", listOf("أبجدي (أ - ي)", "أبجدي عكسي", "الأحدث استخداماً", "الأكثر استخداماً")) { i ->
            Prefs.put("drawer_sort", ids[i])
            refresh()
        }
    }

    /** الفلترة والفرز في خيط خلفي. رقم gen يلغي أي نتيجة قديمة وصلت متأخرة */
    fun refresh() {
        val g = ++gen
        val q = query.trim().lowercase()
        val f = filter
        val sort = Prefs.drawerSort
        val all = AppRepository.apps
        val hidden = HashSet<String>(StateStore.hidden)
        val names = HashMap<String, String>(StateStore.names)
        val cats = HashMap<String, String>(StateStore.categories)
        val last = HashMap<String, Long>(StateStore.lastLaunch)
        val cnt = HashMap<String, Int>(StateStore.launchCount)
        val hm = hiddenMode
        Bg.search.execute {
            try {
                var list: List<AppInfo> = all.filter { (it.key in hidden) == hm }
                if (q.isNotEmpty()) {
                    list = list.filter { (names[it.key] ?: it.label).lowercase().contains(q) || it.pkg.lowercase().contains(q) }
                }
                list = when {
                    f == "recent" -> list.filter { (last[it.key] ?: 0L) > 0L }.sortedByDescending { last[it.key] ?: 0L }.take(40)
                    f == "used" -> list.filter { (cnt[it.key] ?: 0) > 0 }.sortedByDescending { cnt[it.key] ?: 0 }.take(40)
                    f.startsWith("cat:") -> list.filter { (cats[it.key] ?: it.category) == f.substring(4) }
                        .sortedBy { (names[it.key] ?: it.label).lowercase() }
                    else -> when (sort) {
                        "za" -> list.sortedByDescending { (names[it.key] ?: it.label).lowercase() }
                        "recent" -> list.sortedByDescending { last[it.key] ?: 0L }
                        "used" -> list.sortedByDescending { cnt[it.key] ?: 0 }
                        else -> list.sortedBy { (names[it.key] ?: it.label).lowercase() }
                    }
                }
                val res = list
                Bg.main.post {
                    if (g == gen) {
                        shown = res
                        adapter.notifyDataSetChanged()
                    }
                }
            } catch (e: Exception) {
            }
        }
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = (convertView as? AppCellView) ?: AppCellView(context).apply {
                layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(context, Prefs.iconSize.coerceAtMost(72) + 40))
            }
            v.bind(shown[position], Prefs.iconSize.coerceAtMost(72), Prefs.showLabels, Theme.text(context), false)
            return v
        }
    }

    /** السحب للأسفل وأنت في أول القائمة يغلق الدرج */
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downY = e.rawY; downX = e.rawX }
            MotionEvent.ACTION_UP -> {
                val dy = e.rawY - downY
                if (dy > Ui.dp(context, 130) && dy > abs(e.rawX - downX) * 1.5f && !grid.canScrollVertically(-1)) {
                    Bg.main.post { c.closeOverlay(this) }
                }
            }
        }
        return super.dispatchTouchEvent(e)
    }

    override fun animateOut(end: () -> Unit) {
        Bg.main.removeCallbacks(refreshRun)
        hideKeyboard()
        val d = if (Prefs.reduceMotion) 0L else 200L
        animate().alpha(0f).translationY(height * 0.1f).setDuration(d).withEndAction { end() }.start()
    }

    override fun handleBack(): Boolean {
        if (query.isNotEmpty()) {
            search.setText("")
            return true
        }
        return false
    }
}
