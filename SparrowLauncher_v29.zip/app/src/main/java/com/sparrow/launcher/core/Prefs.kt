package com.sparrow.launcher.core

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import org.json.JSONObject

/**
 * كل إعدادات المستخدم. محفوظة في SharedPreferences فتبقى بعد إغلاق التطبيق وإعادة تشغيل الهاتف.
 * كل خاصية هنا = إعداد واحد مع قيمته الافتراضية.
 */
object Prefs {
    private var sp: SharedPreferences? = null

    fun init(ctx: Context) {
        if (sp == null) sp = ctx.applicationContext.getSharedPreferences("sparrow_settings", Context.MODE_PRIVATE)
    }

    private val p: SharedPreferences get() = sp!!

    /** رقم يزيد كلما تغير إعداد؛ الشاشة الرئيسية تقارنه لتعرف متى تعيد الرسم */
    val version: Int get() = p.getInt("_version", 0)

    fun int(k: String, d: Int): Int = p.getInt(k, d)
    fun bool(k: String, d: Boolean): Boolean = p.getBoolean(k, d)
    fun str(k: String, d: String): String = p.getString(k, d) ?: d

    fun put(k: String, v: Any) {
        val e = p.edit()
        when (v) {
            is Int -> e.putInt(k, v)
            is Boolean -> e.putBoolean(k, v)
            is String -> e.putString(k, v)
        }
        e.putInt("_version", version + 1)
        e.apply()
    }

    /** حفظ بدون إشعار الواجهة (لأشياء داخلية مثل "تم تجهيز الافتراضيات") */
    fun putQuiet(k: String, v: Any) {
        val e = p.edit()
        when (v) {
            is Int -> e.putInt(k, v)
            is Boolean -> e.putBoolean(k, v)
            is String -> e.putString(k, v)
        }
        e.apply()
    }

    /** كل الإعدادات كـ JSON (للنسخ الاحتياطي) */
    fun exportJson(): JSONObject {
        val o = JSONObject()
        for ((k, v) in p.all) {
            if (k == "_version" || k == "seeded") continue
            if (v is Int || v is Boolean || v is String) o.put(k, v)
        }
        return o
    }

    fun importJson(o: JSONObject) {
        val e = p.edit()
        val ks = o.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            when (val v = o.get(k)) {
                is Int -> e.putInt(k, v)
                is Long -> e.putInt(k, v.toInt())
                is Boolean -> e.putBoolean(k, v)
                is String -> e.putString(k, v)
            }
        }
        e.putInt("_version", version + 1)
        e.apply()
    }

    // ---------- المظهر ----------
    val theme: String get() = str("theme", "dark")            // dark | light | auto
    val direction: String get() = str("direction", "rtl")     // rtl | ltr | auto
    val uiAlpha: Int get() = int("ui_alpha", 88)               // شفافية عناصر الواجهة %
    val blur: Int get() = int("blur", 40)
    val iconSize: Int get() = int("icon_size", 56)             // dp
    val iconShape: String get() = str("icon_shape", "circle")  // circle | rounded | square | custom | original
    val iconRadius: Int get() = int("icon_radius", 30)         // % للشكل المخصص
    val labelSize: Int get() = int("label_size", 11)           // sp
    val showLabels: Boolean get() = bool("show_labels", true)
    val spacing: Int get() = int("spacing", 8)                 // dp
    val font: String get() = str("font", "medium")             // default | medium | bold | serif
    val glass: Boolean get() = bool("glass", true)
    val lyrics: Boolean get() = bool("lyrics", false)
    val dynamicColor: Boolean get() = bool("dynamic_color", true)
    val launchSplash: Boolean get() = bool("launch_splash", true)
    val iconPack: String get() = str("icon_pack", "")
    val gridPad: Int get() = int("grid_pad", 6)                // هوامش جانبية للشبكة dp
    val searchDelay: Int get() = int("search_delay", 5)        // ثواني قبل ظهور كلمة بحث
    val cols: Int get() = int("grid_cols", 4)
    val rows: Int get() = int("grid_rows", 6)

    // ---------- الشاشة الرئيسية ----------
    val searchPill: Boolean get() = bool("search_pill", true)
    val showDots: Boolean get() = bool("show_dots", true)
    val wallpaperParallax: Boolean get() = bool("wp_parallax", true)
    val wallpaperZoom: Boolean get() = bool("wp_zoom", true)

    // ---------- Workspace ----------
    val transition: String get() = str("transition", "carousel") // carousel | depth | flat
    val perspective: Int get() = int("perspective", 60)
    val parallax: Int get() = int("parallax", 60)
    val reduceMotion: Boolean get() = bool("reduce_motion", false)

    // ---------- App Drawer ----------
    val drawerCols: Int get() = int("drawer_cols", 4)
    val drawerSort: String get() = str("drawer_sort", "az")     // az | za | recent | used
    val drawerChips: Boolean get() = bool("drawer_chips", true)

    // ---------- Dock ----------
    val dockShow: Boolean get() = bool("dock_show", true)
    val dockSize: Int get() = int("dock_size", 54)
    val dockAlpha: Int get() = int("dock_alpha", 55)
    val dockMax: Int get() = int("dock_max", 5)

    // ---------- Widgets / Folders ----------
    val widgetPad: Int get() = int("widget_pad", 4)
    val widgetRadius: Int get() = int("widget_radius", 18)
    val widgetHandle: Boolean get() = bool("widget_handle", true)
    val folderAnim: Boolean get() = bool("folder_anim", true)
    val folderCols: Int get() = int("folder_cols", 4)
    val folderView: String get() = str("folder_view", "orbit")

    fun typeface(): Typeface = when (font) {
        "default" -> Typeface.DEFAULT
        "bold" -> Typeface.DEFAULT_BOLD
        "serif" -> Typeface.SERIF
        else -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
}

/** ألوان الثيم (داكن / فاتح / تلقائي حسب النظام) */
object Theme {
    /** لون مأخوذ من الخلفية (إذا فُعّل في الإعدادات) وإلا الأزرق الافتراضي */
    var dynamic: Int? = null
    val ACCENT: Int get() = dynamic ?: 0xFF7EA6FF.toInt()

    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    fun dark(ctx: Context): Boolean = when (Prefs.theme) {
        "dark" -> true
        "light" -> false
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    /** لون سطح الواجهة (الدرج، البطاقات) مع الشفافية التي اختارها المستخدم */
    fun surface(ctx: Context): Int {
        val a = (Prefs.uiAlpha * 255 / 100).coerceIn(60, 255)
        return if (dark(ctx)) Color.argb(a, 16, 20, 30) else Color.argb(a, 244, 246, 251)
    }

    fun card(ctx: Context): Int = if (dark(ctx)) Color.argb(235, 34, 40, 56) else Color.argb(240, 255, 255, 255)
    fun text(ctx: Context): Int = if (dark(ctx)) 0xFFF1F4FF.toInt() else 0xFF161B26.toInt()
    fun sub(ctx: Context): Int = if (dark(ctx)) 0xFF9AA6C4.toInt() else 0xFF5B6478.toInt()

    /** لوحة زجاجية: طبقة داكنة خفيفة + تدرج أبيض شفاف + حد لامع. إذا أُطفئ الزجاج ترجع بطاقة عادية */
    fun panel(ctx: Context, radius: Float): Drawable {
        if (!Prefs.glass) return Ui.round(card(ctx), radius)
        val k = Prefs.uiAlpha / 100f
        val sheen = mix(0xFFFFFF, ACCENT, 0.22f)
        val g = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.argb((0x5A * k).toInt(), Color.red(sheen), Color.green(sheen), Color.blue(sheen)),
                Color.argb((0x1C * k).toInt(), Color.red(sheen), Color.green(sheen), Color.blue(sheen))
            )
        )
        g.cornerRadius = radius
        g.setStroke((ctx.resources.displayMetrics.density * 1.2f).toInt().coerceAtLeast(1), Color.argb((0x70 * k).toInt(), 255, 255, 255))
        val base = mix(if (dark(ctx)) 0x0C101C else 0x141E32, ACCENT, 0.16f)
        val tint = Ui.round(Color.argb(((if (dark(ctx)) 0x88 else 0x40) * k).toInt(), Color.red(base), Color.green(base), Color.blue(base)), radius)
        return LayerDrawable(arrayOf<Drawable>(tint, g))
    }
}
