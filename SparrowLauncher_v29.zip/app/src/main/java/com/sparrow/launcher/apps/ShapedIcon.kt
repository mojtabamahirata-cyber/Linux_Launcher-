package com.sparrow.launcher.apps

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.persistence.Folder
import com.sparrow.launcher.persistence.StateStore
import kotlin.math.min

/** يرسم الأيقونة بالشكل الذي اختاره المستخدم (دائرة / مربع مدوّر / مربع / مخصص / أصلي) */
class ShapedIcon(private val bmp: Bitmap, private val shape: String) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
    private val rect = RectF()

    init {
        paint.shader = shader
    }

    override fun onBoundsChange(b: Rect) {
        rect.set(b)
        val m = Matrix()
        m.setScale(b.width().toFloat() / bmp.width, b.height().toFloat() / bmp.height)
        m.postTranslate(b.left.toFloat(), b.top.toFloat())
        shader.setLocalMatrix(m)
    }

    override fun draw(c: Canvas) {
        when (shape) {
            "circle" -> c.drawCircle(rect.centerX(), rect.centerY(), min(rect.width(), rect.height()) / 2f, paint)
            "rounded" -> c.drawRoundRect(rect, rect.width() * 0.28f, rect.height() * 0.28f, paint)
            "custom" -> {
                val r = rect.width() * Prefs.iconRadius.coerceIn(0, 50) / 100f
                c.drawRoundRect(rect, r, r, paint)
            }
            else -> c.drawRect(rect, paint) // square + original (الأصلية مقنّعة مسبقاً)
        }
    }

    override fun setAlpha(a: Int) { paint.alpha = a }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** خلية تطبيق: أيقونة + اسم. تُستعمل في الرئيسية والدرج والمجلدات (تُعاد تدويرها في GridView) */
class AppCellView(ctx: Context) : LinearLayout(ctx) {
    private val icon = ImageView(ctx)
    private val label = TextView(ctx)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        addView(icon, LayoutParams(1, 1))
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        label.gravity = Gravity.CENTER
        addView(label, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        // ضغط ناعم: الأيقونة تصغر عند اللمس وترجع بقفزة خفيفة
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(android.view.animation.OvershootInterpolator(3f)).start()
            }
            false
        }
    }

    fun bind(app: AppInfo, iconDp: Int, showLabel: Boolean, textColor: Int, shadow: Boolean, horizontal: Boolean = false) {
        val px = Ui.dp(context, iconDp)
        orientation = if (horizontal) HORIZONTAL else VERTICAL
        val lp = icon.layoutParams as LayoutParams
        lp.width = px
        lp.height = px
        val bmp = AppRepository.icon(app.key)
        icon.setImageDrawable(if (bmp != null) ShapedIcon(bmp, Prefs.iconShape) else null)
        label.text = StateStore.names[app.key] ?: app.label
        label.visibility = if (showLabel) View.VISIBLE else View.GONE
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, Prefs.labelSize.toFloat())
        label.setTextColor(textColor)
        label.typeface = Prefs.typeface()
        label.gravity = if (horizontal) Gravity.CENTER_VERTICAL else Gravity.CENTER
        if (shadow) label.setShadowLayer(4f, 0f, 1.5f, 0x99000000.toInt()) else label.setShadowLayer(0f, 0f, 0f, 0)
        val pad = Ui.dp(context, 3)
        label.setPadding(pad, if (horizontal) 0 else pad, pad, 0)
    }
}

/** أيقونة مجلد: معاينة 2×2 للتطبيقات، أو Emoji، أو صورة من الجهاز + سهم إذا فيه مجلدات فرعية */
class FolderIconView(ctx: Context, private val folder: Folder, private val size: Int) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(size, size)
    }

    override fun onDraw(c: Canvas) {
        val s = size.toFloat()
        val r = s * 0.28f
        val full = RectF(0f, 0f, s, s)
        val custom = if (folder.iconPath.isNotEmpty()) AppRepository.bitmapFile(folder.iconPath) else null
        if (custom != null) {
            val d = ShapedIcon(custom, "rounded")
            d.setBounds(0, 0, size, size)
            d.draw(c)
        } else {
            paint.style = Paint.Style.FILL
            paint.color = if (folder.color != 0) folder.color else 0x8C5B7BD5.toInt()
            c.drawRoundRect(full, r, r, paint)
            if (folder.emoji.startsWith("vec:")) {
                val g = com.sparrow.launcher.core.VIcon(folder.emoji.substring(4), Color.WHITE)
                val i = (s * 0.24f).toInt()
                g.setBounds(i, i, size - i, size - i)
                g.draw(c)
            } else if (folder.emoji.isNotEmpty()) {
                paint.color = Color.WHITE
                paint.textSize = s * 0.52f
                paint.textAlign = Paint.Align.CENTER
                c.drawText(folder.emoji, s / 2f, s / 2f + paint.textSize * 0.35f, paint)
            } else {
                val pad = s * 0.14f
                val cell = (s - pad * 2) / 2f
                val isz = cell * 0.9f
                var n = 0
                for (key in folder.apps) {
                    if (n >= 4) break
                    val b = AppRepository.icon(key) ?: continue
                    val col = n % 2
                    val row = n / 2
                    val x = pad + col * cell + (cell - isz) / 2f
                    val y = pad + row * cell + (cell - isz) / 2f
                    c.drawBitmap(b, null, RectF(x, y, x + isz, y + isz), paint)
                    n++
                }
                // المجلدات الفرعية تظهر بأيقونة المجلد الاعتيادية
                for (sub in folder.folders) {
                    if (n >= 4) break
                    val col = n % 2
                    val row = n / 2
                    val g = com.sparrow.launcher.core.VIcon("folder", Color.WHITE)
                    val sz = (cell * 0.8f).toInt()
                    val gx = (pad + col * cell + cell * 0.1f).toInt()
                    val gy = (pad + row * cell + cell * 0.1f).toInt()
                    g.setBounds(gx, gy, gx + sz, gy + sz)
                    g.draw(c)
                    n++
                }
            }
        }
        if (folder.folders.isNotEmpty()) {
            // سهم صغير = هذا المجلد يحتوي مجلدات داخله
            val p = Path()
            p.moveTo(s * 0.72f, s * 0.80f)
            p.lineTo(s * 0.94f, s * 0.80f)
            p.lineTo(s * 0.83f, s * 0.94f)
            p.close()
            paint.color = Color.WHITE
            c.drawPath(p, paint)
        }
    }
}
