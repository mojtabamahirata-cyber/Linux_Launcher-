package com.sparrow.launcher.core

import android.app.Dialog
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/**
 * قائمة خيارات بصرية: لوحة زجاجية تنزلق من الأسفل، كل خيار أيقونة دائرية + اسم (بدل قائمة نصية).
 * الأيقونة تُختار تلقائياً من معنى الاسم.
 */
object Sheet {
    fun iconFor(l: String): String = when {
        l.contains("إلغاء التثبيت") -> "trash"
        l.contains("معلومات") -> "info"
        l.contains("Widget") -> "widget"
        l.contains("Workspace") || l.contains("المساحات") -> "workspace"
        l.contains("الخلفية") -> "image"
        l.contains("ترتيب") || l.contains("تجميع") -> "sort"
        l.contains("الحجم") -> "widget"
        l.contains("التخطيط") || l.contains("العرض") -> "apps"
        l.contains("الإعدادات") -> "gear"
        l.contains("لون") -> "palette"
        l.contains("تكبير") -> "plus"
        l.contains("تصغير") -> "minus"
        l.contains("تقديم") -> "back"
        l.contains("تأخير") -> "fwd"
        l.contains("حذف") || l.contains("إزالة") || l.contains("مسح") -> "trash"
        l.contains("Dock") -> "dock"
        l.contains("مجلد") -> "folder"
        l == "إضافة تطبيق" || l == "تطبيق" -> "apps"
        l.contains("إضافة") -> "plus"
        l.contains("نقل") -> "move"
        l.contains("إخفاء") -> "eyeoff"
        l.contains("الاسم") || l.contains("اسم") -> "edit"
        l.contains("أيقونة") || l.contains("الأيقونة") -> "image"
        l.contains("تصنيف") -> "tag"
        l.contains("فتح") -> "open"
        else -> "gear"
    }

    fun show(ctx: Context, title: String?, opts: List<Opt>) {
        val dlg = Dialog(ctx, android.R.style.Theme_Translucent_NoTitleBar)
        val root = FrameLayout(ctx)
        root.layoutDirection = Ui.layoutDir()
        root.setBackgroundColor(0x77000000)
        root.setOnClickListener { dlg.dismiss() }
        val panel = LinearLayout(ctx)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = Theme.panel(ctx, Ui.dpf(ctx, 30f))
        panel.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 16), Ui.dp(ctx, 14), Ui.dp(ctx, 12))
        panel.isClickable = true
        if (title != null) {
            val t = Ui.text(ctx, title, 17f, Theme.text(ctx), true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, 0, 0, Ui.dp(ctx, 12))
            panel.addView(t, LinearLayout.LayoutParams(-1, -2))
        }
        val grid = LinearLayout(ctx)
        grid.orientation = LinearLayout.VERTICAL
        val tw = (ctx.resources.displayMetrics.widthPixels - Ui.dp(ctx, 20 + 28)) / 4
        var row: LinearLayout? = null
        for ((i, o) in opts.withIndex()) {
            if (i % 4 == 0) {
                row = LinearLayout(ctx)
                grid.addView(row, LinearLayout.LayoutParams(-1, -2))
            }
            val tile = LinearLayout(ctx)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER_HORIZONTAL
            tile.setPadding(0, Ui.dp(ctx, 6), 0, Ui.dp(ctx, 6))
            val ic = ImageView(ctx)
            ic.setImageDrawable(VIcon(iconFor(o.label), Theme.text(ctx)))
            val pad = Ui.dp(ctx, 15)
            ic.setPadding(pad, pad, pad, pad)
            ic.background = Theme.panel(ctx, Ui.dpf(ctx, 30f))
            tile.addView(ic, LinearLayout.LayoutParams(Ui.dp(ctx, 60), Ui.dp(ctx, 60)))
            val lb = Ui.text(ctx, o.label, 11f, Theme.text(ctx))
            lb.gravity = Gravity.CENTER
            lb.maxLines = 2
            lb.setPadding(Ui.dp(ctx, 2), Ui.dp(ctx, 5), Ui.dp(ctx, 2), 0)
            tile.addView(lb, LinearLayout.LayoutParams(-1, -2))
            tile.setOnClickListener { dlg.dismiss(); o.run() }
            row?.addView(tile, LinearLayout.LayoutParams(tw, -2))
        }
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(grid)
        panel.addView(sv, LinearLayout.LayoutParams(-1, -2))
        root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            setMargins(Ui.dp(ctx, 10), 0, Ui.dp(ctx, 10), Ui.dp(ctx, 14))
        })
        dlg.setContentView(root)
        dlg.window?.setLayout(-1, -1)
        dlg.show()
        panel.alpha = 0f
        panel.afterLayout {
            panel.translationY = panel.height * 0.5f
            val d = if (Prefs.reduceMotion) 0L else 300L
            panel.animate().alpha(1f).translationY(0f).setDuration(d).setInterpolator(PathInterpolator(0.05f, 0.7f, 0.1f, 1f)).start()
        }
    }
}
