package com.sparrow.launcher.controls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.core.VIcon

/** شريط عمودي زجاجي (سطوع/صوت) يُسحب بالإصبع، يتعبأ من الأسفل مثل أنظمة الهواتف الحديثة */
class VSlider(ctx: Context, icon: String, private val onChange: (Float) -> Unit) : View(ctx) {
    var value = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var onLockedTap: (() -> Unit)? = null
    var locked = false
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val ic = VIcon(icon, 0xFF1B2233.toInt())

    init {
        bg.color = 0x33FFFFFF
        fill.color = 0xF2FFFFFF.toInt()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = w / 2f
        path.reset()
        path.addRoundRect(RectF(0f, 0f, w, h), r, r, Path.Direction.CW)
        c.drawPath(path, bg)
        c.save()
        c.clipPath(path)
        c.drawRect(0f, h * (1f - value), w, h, fill)
        c.restore()
        val s = (w * 0.5f).toInt()
        val x = ((w - s) / 2f).toInt()
        val y = (h - s - Ui.dp(context, 16)).toInt()
        ic.setBounds(x, y, x + s, y + s)
        ic.draw(c)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN && locked) { onLockedTap?.invoke(); return true }
        if (locked) return true
        parent?.requestDisallowInterceptTouchEvent(true)
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            value = 1f - e.y / height
            onChange(value)
        }
        return true
    }
}
