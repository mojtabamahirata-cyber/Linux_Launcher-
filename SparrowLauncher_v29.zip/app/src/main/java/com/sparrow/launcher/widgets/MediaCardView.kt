package com.sparrow.launcher.widgets

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import com.sparrow.launcher.core.Icons
import com.sparrow.launcher.core.VIcon
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.Ui

/**
 * مشغل موسيقى حقيقي عبر MediaSession: عنوان، فنان، غلاف، Play/Pause/Next/Previous.
 * يحتاج المستخدم يفعّل "الوصول للإشعارات" لـ Sparrow مرة واحدة (قيد من أندرويد).
 */
class MediaCardView(ctx: Context) : LinearLayout(ctx) {
    private val art = ImageView(ctx)
    private val title = Ui.text(ctx, "", 15f, Color.WHITE, true)
    private val artist = Ui.text(ctx, "", 12f, 0xCCFFFFFF.toInt())
    private val play = ImageView(ctx)
    private var ctl: MediaController? = null
    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val comp = ComponentName(ctx, SparrowNotificationListener::class.java)

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(s: PlaybackState?) { refresh() }
        override fun onMetadataChanged(m: MediaMetadata?) { refresh() }
    }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(0xB3101420.toInt())
        setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 8), Ui.dp(ctx, 12), Ui.dp(ctx, 8))
        addView(art, LayoutParams(Ui.dp(ctx, 64), Ui.dp(ctx, 64)))
        val col = LinearLayout(ctx)
        col.orientation = VERTICAL
        title.maxLines = 1; artist.maxLines = 1
        col.addView(title); col.addView(artist)
        val ctrl = LinearLayout(ctx)
        ctrl.gravity = Gravity.CENTER
        fun b(kind: String, f: () -> Unit) {
            ctrl.addView(Icons.button(ctx, kind, Color.WHITE, false, f), LinearLayout.LayoutParams(Ui.dp(ctx, 44), Ui.dp(ctx, 44)))
        }
        play.setPadding(Ui.dp(ctx, 9), Ui.dp(ctx, 9), Ui.dp(ctx, 9), Ui.dp(ctx, 9))
        play.setImageDrawable(VIcon("play", Color.WHITE))
        b("prev") { ctl?.transportControls?.skipToPrevious() }
        ctrl.addView(play, LinearLayout.LayoutParams(Ui.dp(ctx, 44), Ui.dp(ctx, 44)))
        play.setOnClickListener {
            val st = ctl?.playbackState?.state
            if (st == PlaybackState.STATE_PLAYING) ctl?.transportControls?.pause() else ctl?.transportControls?.play()
        }
        b("next") { ctl?.transportControls?.skipToNext() }
        col.addView(ctrl)
        addView(col, LayoutParams(0, -2, 1f).apply { setMargins(Ui.dp(ctx, 10), 0, 0, 0) })
    }

    private fun hasAccess(): Boolean {
        val s = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: ""
        return s.contains(context.packageName)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        try {
            if (hasAccess()) {
                msm.addOnActiveSessionsChangedListener(sessionsListener, comp)
                pick(msm.getActiveSessions(comp))
                return
            }
        } catch (e: Exception) {
        }
        title.text = "فعّل الوصول للإشعارات"
        artist.text = "اضغط هنا لتشغيل مشغل الموسيقى"
        setOnClickListener {
            try { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        ctl?.unregisterCallback(cb)
        ctl = null
    }

    private fun pick(list: List<MediaController>?) {
        ctl?.unregisterCallback(cb)
        ctl = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        ctl?.registerCallback(cb)
        refresh()
    }

    private fun refresh() {
        val c = ctl
        if (c == null) { title.text = "لا يوجد تشغيل"; artist.text = "شغّل أغنية في Spotify أو أي مشغل"; art.setImageDrawable(null); play.setImageDrawable(VIcon("play", Color.WHITE)); return }
        val m = c.metadata
        title.text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: c.packageName
        artist.text = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp: Bitmap? = m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        art.setImageBitmap(bmp)
        play.setImageDrawable(VIcon(if (c.playbackState?.state == PlaybackState.STATE_PLAYING) "pause" else "play", Color.WHITE))
    }
}
