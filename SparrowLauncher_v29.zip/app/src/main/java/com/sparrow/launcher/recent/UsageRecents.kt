package com.sparrow.launcher.recent

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process

/**
 * التطبيقات الأخيرة الحقيقية (حتى التي فتحتها خارج Sparrow). تعمل فقط إذا فعّل المستخدم
 * "الوصول لبيانات الاستخدام" يدوياً من إعدادات أندرويد (صلاحية اختيارية، لا يعمل اللانشر بدونها).
 */
object UsageRecents {
    fun granted(ctx: Context): Boolean = try {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (e: Exception) { false }

    /** حزم التطبيقات التي دخلت للواجهة خلال آخر 24 ساعة، الأحدث أولاً */
    fun recentPackages(ctx: Context, max: Int): List<String> {
        try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val ev = usm.queryEvents(end - 24L * 3600L * 1000L, end)
            val last = HashMap<String, Long>()
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) last[e.packageName] = e.timeStamp
            }
            return last.entries.sortedByDescending { it.value }.map { it.key }.take(max)
        } catch (x: Exception) {
            return emptyList()
        }
    }
}
