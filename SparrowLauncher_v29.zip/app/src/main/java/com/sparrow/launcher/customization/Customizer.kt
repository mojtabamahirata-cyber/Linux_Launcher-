package com.sparrow.launcher.customization

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.widget.GridLayout
import android.widget.ScrollView
import com.sparrow.launcher.apps.AppInfo
import com.sparrow.launcher.apps.Categories
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.persistence.StateStore
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

/** أدوات تخصيص العناصر: أسماء، أيقونات، ألوان، Emoji، تصنيفات (لا تعدّل التطبيق الأصلي أبداً) */
object Customizer {
    private val EMOJIS = listOf("🎮", "📁", "💬", "🎵", "📷", "🛠️", "💰", "📚", "⭐", "❤️", "🔥", "🌙", "☀️", "🚀", "🎬", "🛒", "🧠", "🏠", "✈️", "⚽", "🍔", "📱", "💼", "🔒", "🌐", "🎨", "📰", "🧩", "🏆", "⚔️")
    private val COLORS = listOf(0x8C5B7BD5, 0x8CE57373, 0x8C81C784, 0x8CFFB74D, 0x8CBA68C8, 0x8C4DD0E1, 0x8C90A4AE, 0xCC000000, 0x66FFFFFF)

    private fun grid(ctx: Context, title: String, n: Int, bind: (Int, android.widget.TextView) -> Unit, pick: (Int) -> Unit) {
        val g = GridLayout(ctx)
        g.columnCount = 5
        val sv = ScrollView(ctx)
        val dlg = Ui.builder(ctx).setTitle(title).setView(sv).setNegativeButton("إلغاء", null).create()
        for (i in 0 until n) {
            val t = Ui.text(ctx, "", 26f, Color.WHITE)
            t.gravity = Gravity.CENTER
            bind(i, t)
            t.setOnClickListener { dlg.dismiss(); pick(i) }
            g.addView(t, GridLayout.LayoutParams().apply { width = Ui.dp(ctx, 56); height = Ui.dp(ctx, 56); setMargins(4, 4, 4, 4) })
        }
        sv.addView(g)
        dlg.show()
    }

    /** أيقونات المجلد: مجموعة متجهة احترافية (تُحفظ بصيغة vec:الاسم) */
    fun pickEmoji(ctx: Context, onPick: (String) -> Unit) {
        val names = com.sparrow.launcher.core.VIcon.FOLDER_GLYPHS
        grid(ctx, "اختر أيقونة", names.size, { i, t ->
            val d = com.sparrow.launcher.core.Icons.drawable(ctx, names[i], 28, Color.WHITE)
            t.setCompoundDrawablesRelative(null, d, null, null)
            t.setPadding(0, Ui.dp(ctx, 14), 0, 0)
            t.background = Ui.round(0x33FFFFFF, Ui.dpf(ctx, 14f))
        }) { onPick("vec:" + names[it]) }
    }

    fun pickColor(ctx: Context, onPick: (Int) -> Unit) =
        grid(ctx, "لون المجلد", COLORS.size, { i, t -> t.background = Ui.round(COLORS[i].toInt(), Ui.dpf(ctx, 14f)) }) { onPick(COLORS[it].toInt()) }

    /** تصنيف يدوي لتطبيق: يبقى محفوظاً */
    fun chooseCategory(ctx: Context, app: AppInfo, done: () -> Unit) {
        val ids = ArrayList<String>(Categories.builtin)
        for (v in StateStore.categories.values) if (v.startsWith("c:") && v !in ids) ids.add(v)
        val labels = ArrayList<String>(ids.map { Categories.name(it) })
        labels.add("تصنيف جديد…"); labels.add("تلقائي")
        Ui.list(ctx, "تصنيف ${app.label}", labels) { i ->
            when {
                i < ids.size -> { StateStore.categories[app.key] = ids[i]; StateStore.save(); done() }
                i == ids.size -> Ui.input(ctx, "اسم التصنيف", "") { n ->
                    if (n.isNotBlank()) { StateStore.categories[app.key] = "c:" + n.trim(); StateStore.save(); done() }
                }
                else -> { StateStore.categories.remove(app.key); StateStore.save(); done() }
            }
        }
    }

    fun saveBitmap(ctx: Context, bmp: Bitmap): String? {
        return try {
            val dir = File(ctx.filesDir, "icons")
            dir.mkdirs()
            val f = File(dir, "i" + System.currentTimeMillis() + ".png")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            f.absolutePath
        } catch (e: Exception) { null }
    }

    /** ينسخ صورة من المعرض كأيقونة مربعة داخل مساحة التطبيق (لا تعتمد على صلاحية الصورة لاحقاً) */
    fun importIcon(ctx: Context, uri: Uri): String? {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 512) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val side = min(bmp.width, bmp.height)
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 192, 192, true)
            val dir = File(ctx.filesDir, "icons")
            dir.mkdirs()
            val f = File(dir, "i" + System.currentTimeMillis() + ".png")
            FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            return f.absolutePath
        } catch (e: Exception) {
            return null
        }
    }
}
