package com.sparrow.launcher.core

import android.app.Activity
import android.view.View
import com.sparrow.launcher.apps.AppInfo
import com.sparrow.launcher.persistence.Item

/**
 * واجهة يتحدث بها كل نظام (Drawer, Folders, Dock ...) مع الشاشة الرئيسية
 * بدون أن يعرف تفاصيلها. هكذا كل نظام مسؤول عن نفسه.
 */
interface LauncherController {
    val activity: Activity
    fun launchApp(key: String, from: View?)
    fun launchDockEntry(entry: String, from: View?)
    fun showAppMenu(app: AppInfo, fromDrawer: Boolean, item: Item?, folderId: String?)
    fun showFolderMenu(id: String)
    fun showDockMenu(entry: String)
    fun addToDock()
    fun dragDockEntry(v: View, entry: String)
    fun dragFromDrawer(v: View, app: AppInfo)
    fun closeOverlay(v: View)
    fun pickApp(title: String, cb: (AppInfo) -> Unit)
    fun addAppToFolderPicker(folderId: String)
    fun newSubFolder(parentId: String)
    fun openFolder(id: String, from: View?)
}

/** أي شاشة تظهر فوق الرئيسية (درج، مجلد، Overview، Recents) */
interface Overlay {
    /** مقدار تعتيم/طمس الخلفية 0..1 */
    val depth: Float
    fun animateOut(end: () -> Unit)
    /** يرجع true إذا عالج زر الرجوع بنفسه (مثل الرجوع لمجلد أب) */
    fun handleBack(): Boolean
}
