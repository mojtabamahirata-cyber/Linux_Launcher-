package com.sparrow.launcher.controls

import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/**
 * كلمات الأغاني المتزامنة من خدمة lrclib.net (خدمة مجانية خارجية). تعمل فقط إذا فعّلها المستخدم من الإعدادات،
 * وترسل اسم الأغنية والفنان فقط. أندرويد نفسه لا يعطي الكلمات، لذلك هذا هو الطريق الوحيد.
 */
object LyricsRepo {
    class Line(val ms: Long, val text: String)

    private val cache = HashMap<String, List<Line>>()
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun get(artist: String, title: String, durSec: Int, cb: (List<Line>) -> Unit) {
        val key = "$artist|$title"
        val hit = cache[key]
        if (hit != null) { cb(hit); return }
        io.execute {
            val res = try { fetch(artist, title, durSec) } catch (e: Exception) { emptyList() }
            main.post { cache[key] = res; cb(res) }
        }
    }

    private fun fetch(artist: String, title: String, durSec: Int): List<Line> {
        val q = "https://lrclib.net/api/get?artist_name=" + URLEncoder.encode(artist, "UTF-8") +
            "&track_name=" + URLEncoder.encode(title, "UTF-8") + (if (durSec > 0) "&duration=$durSec" else "")
        val con = URL(q).openConnection() as HttpURLConnection
        con.connectTimeout = 6000
        con.readTimeout = 6000
        con.setRequestProperty("User-Agent", "SparrowLauncher/1.0")
        if (con.responseCode != 200) return emptyList()
        val body = con.inputStream.bufferedReader().use { it.readText() }
        return parse(JSONObject(body).optString("syncedLyrics", ""))
    }

    /** يحوّل نص LRC ([mm:ss.xx] سطر) إلى قائمة أسطر مرتبة بالزمن */
    fun parse(lrc: String): List<Line> {
        val out = ArrayList<Line>()
        val re = Regex("^\\[(\\d+):(\\d+(?:\\.\\d+)?)](.*)$")
        for (raw in lrc.lines()) {
            val m = re.find(raw.trim()) ?: continue
            val ms = ((m.groupValues[1].toLong() * 60 + m.groupValues[2].toDouble()) * 1000).toLong()
            val text = m.groupValues[3].trim()
            if (text.isNotEmpty()) out.add(Line(ms, text))
        }
        return out.sortedBy { it.ms }
    }
}
