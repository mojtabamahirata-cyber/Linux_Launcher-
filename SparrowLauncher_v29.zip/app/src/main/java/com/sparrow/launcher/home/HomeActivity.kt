package com.sparrow.launcher.home

import android.app.Activity
import android.app.ActivityOptions
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.DragEvent
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowInsets
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.sparrow.launcher.apps.AppCellView
import com.sparrow.launcher.apps.AppInfo
import com.sparrow.launcher.apps.AppRepository
import com.sparrow.launcher.apps.FolderIconView
import com.sparrow.launcher.appdrawer.DrawerView
import com.sparrow.launcher.core.*
import com.sparrow.launcher.controls.ControlPanelView
import com.sparrow.launcher.customization.Customizer
import com.sparrow.launcher.dock.DockView
import com.sparrow.launcher.folders.FolderStageView
import com.sparrow.launcher.gestures.GestureActions
import com.sparrow.launcher.persistence.Folder
import com.sparrow.launcher.persistence.Item
import com.sparrow.launcher.persistence.StateStore
import com.sparrow.launcher.persistence.Workspace
import com.sparrow.launcher.recent.RecentsView
import com.sparrow.launcher.settings.SettingsActivity
import com.sparrow.launcher.widgets.MediaCardView
import com.sparrow.launcher.widgets.ResizeOverlay
import com.sparrow.launcher.widgets.WidgetPickerView
import com.sparrow.launcher.workspace.OverviewView
import com.sparrow.launcher.workspace.WorkspacePager
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.ceil
import kotlin.math.max

/** المتحكم الرئيسي: يربط كل الأنظمة (Workspaces, Drawer, Dock, Widgets, Gestures ...) */
class HomeActivity : Activity(), LauncherController {
    companion object {
        private const val HOST_ID = 0x535052
        private const val REQ_PICK = 101
        private const val REQ_CONFIG = 102
        private const val REQ_ICON = 103
        private const val REQ_BIND = 104
    }

    override val activity: Activity get() = this
    private lateinit var root: FrameLayout
    private lateinit var pager: WorkspacePager
    private lateinit var dock: DockView
    private lateinit var dots: LinearLayout
    private lateinit var pill: TextView
    private lateinit var wm: WallpaperManager
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var widgetMgr: AppWidgetManager
    private val hostViews = HashMap<Int, AppWidgetHostView>()
    private val overlays = ArrayList<View>()
    private var topInset = 0
    private var bottomInset = 0
    private var moving: Item? = null
    private var crashMode = false
    private var seenVersion = -1
    private var pendingId = -1
    private var pendingWs = 0
    private var pendingIcon = ""
    private var pendingSx = 0
    private var pendingSy = 0
    private var pendingInfo: AppWidgetProviderInfo? = null
    private var lastDot = -1
    private var lastWp = -1f
    private var gx = 0f
    private var gy = 0f
    private var gt = 0L
    private var gOk = false
    private var gEmpty = false
    private var lastTapT = 0L
    private var lastTapX = 0f
    private var twoStartX = 0f
    private var twoX = 0f
    private var twoOn = false
    private var pinch = 1f
    private val reloadRun = Runnable { reloadApps() }
    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            Bg.main.removeCallbacks(reloadRun); Bg.main.postDelayed(reloadRun, 600)
        }
    }
    private val scale by lazy {
        android.view.ScaleGestureDetector(this, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: android.view.ScaleGestureDetector): Boolean { pinch = 1f; return true }
            override fun onScale(d: android.view.ScaleGestureDetector): Boolean { pinch *= d.scaleFactor; return true }
            override fun onScaleEnd(d: android.view.ScaleGestureDetector) { if (pinch < 0.78f) runAction(GestureActions.spec("pinch")) }
        }).also { it.isQuickScaleEnabled = false }
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    // ------------------------------------------------------------ دورة الحياة
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (CrashReporter.showIfAny(this)) { crashMode = true; return }
        CrashReporter.install(this)
        Prefs.init(this)
        StateStore.load(this)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        wm = WallpaperManager.getInstance(this)
        updateDynamicColors()
        widgetMgr = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, HOST_ID)
        buildRoot()
        seenVersion = Prefs.version
        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED); f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_REPLACED); f.addDataScheme("package")
        registerReceiver(pkgReceiver, f)
        reloadApps()
    }

    override fun onStart() { super.onStart(); try { widgetHost.startListening() } catch (_: Exception) {} }
    override fun onStop() { super.onStop(); if (crashMode) return; hideSplashNow(); try { widgetHost.stopListening() } catch (_: Exception) {}; StateStore.flush() }
    override fun onDestroy() { super.onDestroy(); try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {} }

    override fun onResume() {
        super.onResume()
        if (crashMode) return
        if (seenVersion != Prefs.version) {
            seenVersion = Prefs.version
            root.layoutDirection = Ui.layoutDir()
            updateDynamicColors()
            layoutHome()
            // إذا صغّر المستخدم الشبكة من الإعدادات: نعيد ترتيب العناصر الخارجة عن الحدود
            for (m in StateStore.relayout(Prefs.cols, Prefs.rows)) {
                if (m.type == Item.WIDGET) m.ref.toIntOrNull()?.let { id -> try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {} }
            }
            reloadApps()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (crashMode) return
        if (intent.action == Intent.ACTION_MAIN) { closeAllOverlays(); moving = null; pager.goTo(StateStore.homeIndex); if (intent.getBooleanExtra("overview", false)) openOverview() }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val top = overlays.lastOrNull()
        if (top != null) { if ((top as? Overlay)?.handleBack() != true) closeOverlay(top); return }
        if (moving != null) { moving = null; setGrid(false) }
    }

    // ------------------------------------------------------------ الواجهة
    private fun buildRoot() {
        root = FrameLayout(this)
        root.layoutDirection = Ui.layoutDir()
        root.setOnDragListener(dragListener)
        setContentView(root)
        pager = WorkspacePager(this)
        pager.listener = object : WorkspacePager.Listener {
            override fun onPosition(pos: Float) { onPos(pos) }
            override fun onSettled(index: Int) { StateStore.currentIndex = index; StateStore.save(); dock.bind(); rebuildDots(); scheduleSearch() }
        }
        root.addView(pager, FrameLayout.LayoutParams(-1, -1))
        dots = LinearLayout(this)
        dots.gravity = Gravity.CENTER
        dots.setOnLongClickListener { openOverview(); true }
        root.addView(dots, FrameLayout.LayoutParams(-1, dp(14), Gravity.BOTTOM))
        dock = DockView(this, this)
        root.addView(dock, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        pill = Ui.text(this, "بحث", 14f, Color.WHITE, true)
        Icons.withText(this, pill, "search", 18, Color.WHITE)
        pill.gravity = Gravity.CENTER
        pill.setPadding(dp(18), 0, dp(20), 0)
        pill.setOnClickListener { openDrawer(true, false) }
        root.addView(pill, FrameLayout.LayoutParams(-2, dp(34), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        pill.alpha = 0f
        pill.visibility = View.INVISIBLE
        root.setOnApplyWindowInsetsListener { _, ins ->
            topInset = ins.systemWindowInsetTop; bottomInset = ins.systemWindowInsetBottom; layoutHome(); ins
        }
        layoutHome()
    }

    private var searchShown = false
    private val searchRun = Runnable { showSearch(true) }

    private fun scheduleSearch() {
        Bg.main.removeCallbacks(searchRun)
        if (Prefs.searchPill && overlays.isEmpty()) Bg.main.postDelayed(searchRun, Prefs.searchDelay * 1000L)
    }

    /** كلمة (بحث) تحل مكان النقاط بحركة ناعمة، وترجع النقاط عند أول تنقل */
    private fun showSearch(on: Boolean) {
        if (!Prefs.searchPill) return
        searchShown = on
        if (on) pill.visibility = View.VISIBLE
        pill.animate().alpha(if (on) 1f else 0f).setDuration(260).withEndAction { if (!searchShown) pill.visibility = View.INVISIBLE }.start()
        dots.animate().alpha(if (on) 0f else 1f).setDuration(260).start()
    }

    /** يأخذ اللون الغالب من الخلفية الحقيقية ليلوّن الزجاج والأزرار */
    private fun updateDynamicColors() {
        if (!Prefs.dynamicColor) { Theme.dynamic = null; return }
        try {
            val p = wm.getWallpaperColors(WallpaperManager.FLAG_SYSTEM)?.primaryColor?.toArgb() ?: return
            val hsv = FloatArray(3)
            Color.colorToHSV(p, hsv)
            hsv[1] = max(hsv[1], 0.45f)
            hsv[2] = max(hsv[2], 0.88f)
            Theme.dynamic = Color.HSVToColor(hsv)
        } catch (_: Exception) {}
    }

    private fun layoutHome() {
        val dockH = if (Prefs.dockShow) dock.heightPx() + dp(10) else 0
        pill.background = Theme.panel(this, dp(17).toFloat())
        (pill.layoutParams as FrameLayout.LayoutParams).apply { bottomMargin = bottomInset + dockH + dp(4); gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL }
        (pager.layoutParams as FrameLayout.LayoutParams).apply { topMargin = topInset + dp(12); bottomMargin = bottomInset + dockH + dp(40) }
        (dock.layoutParams as FrameLayout.LayoutParams).apply { bottomMargin = bottomInset + dp(10); leftMargin = dp(12); rightMargin = dp(12) }
        dock.visibility = if (Prefs.dockShow) View.VISIBLE else View.GONE
        (dots.layoutParams as FrameLayout.LayoutParams).bottomMargin = bottomInset + dockH + dp(14)
        root.requestLayout()
        if (::pager.isInitialized) onPos(pager.position)
        if (!searchShown) scheduleSearch()
    }

    private fun currentWs(): Workspace = StateStore.workspaces[pager.current.coerceIn(0, StateStore.workspaces.size - 1)]

    private fun rebuildPages() {
        val list = StateStore.workspaces.map { ws -> CellLayout(this).also { populate(it, ws, true) } }
        pager.setPages(list, StateStore.currentIndex)
        lastDot = -1
        rebuildDots()
        dock.bind()
    }

    private fun refreshPage(i: Int) { pager.page(i)?.let { populate(it, StateStore.workspaces[i]) } }
    private fun refreshCurrent() { refreshPage(pager.current); dock.bind() }

    private fun rebuildDots() {
        dots.removeAllViews()
        val n = StateStore.workspaces.size
        if (!Prefs.showDots || n < 2) return
        for (i in 0 until n) {
            val d = View(this)
            d.background = Ui.round(Color.WHITE, dp(4).toFloat())
            d.alpha = if (i == pager.current) 1f else 0.4f
            dots.addView(d, LinearLayout.LayoutParams(dp(if (i == pager.current) 14 else 6), dp(6)).apply { setMargins(dp(3), 0, dp(3), 0) })
            d.setOnClickListener { pager.goTo(i) }
        }
    }

    private fun onPos(pos: Float) {
        if (pager.current != lastDot) { lastDot = pager.current; rebuildDots() }
        val frac = pos - Math.round(pos)
        dock.translationX = -(if (pager.rtl) -1f else 1f) * frac * root.width * 0.08f
        dock.alpha = 1f - abs(frac) * 0.5f
        // أثناء التنقل: النقاط تظهر وكلمة (بحث) تختفي. بعد استقرار الصفحة مدة (5 ثواني افتراضياً) تظهر كلمة بحث
        if (!Prefs.searchPill) { pill.visibility = View.GONE; dots.alpha = 1f }
        else if (abs(frac) > 0.002f) { Bg.main.removeCallbacks(searchRun); if (searchShown || pill.alpha > 0f) showSearch(false) }
        val n = StateStore.workspaces.size
        if (Prefs.wallpaperParallax && n > 1) {
            var x = pos / (n - 1)
            if (pager.rtl) x = 1f - x
            if (abs(x - lastWp) < 0.002f) return
            lastWp = x
            try {
                val tok = window.decorView.windowToken ?: return
                wm.setWallpaperOffsetSteps(1f / (n - 1), 1f)
                wm.setWallpaperOffsets(tok, x, 0.5f)
            } catch (_: Exception) {}
        }
    }

    private fun setGrid(on: Boolean) { for (i in 0 until pager.count) pager.page(i)?.showGrid = on }

    // ------------------------------------------------------------ بناء عناصر الصفحة
    private fun populate(cell: CellLayout, ws: Workspace, animate: Boolean = false) {
        cell.removeAllViews()
        cell.tint = ws.tint
        var changed = false
        var n = 0
        for (item in ArrayList(ws.items)) {
            val v = createItemView(item)
            if (v == null) {
                if (item.type == Item.WIDGET) { ws.items.remove(item); changed = true }
                continue
            }
            cell.addView(v, CellLayout.LP(item.col, item.row, item.sx, item.sy))
            if (animate && !Prefs.reduceMotion) {
                v.alpha = 0f; v.scaleX = 0.5f; v.scaleY = 0.5f
                v.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(minOf(n * 16L, 320L)).setDuration(340)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.4f)).start()
            }
            n++
        }
        if (changed) StateStore.save()
        cell.setOnLongClickListener { showHomeMenu(); true }
        cell.setOnClickListener { placeMoving(cell) }
    }

    private fun createItemView(item: Item): View? {
        when (item.type) {
            Item.APP -> {
                val app = AppRepository.byKey[item.ref] ?: return null
                if (item.ref in StateStore.hidden) return null
                val v = AppCellView(this)
                v.bind(app, Prefs.iconSize, Prefs.showLabels, Color.WHITE, true)
                v.setOnClickListener { launchApp(app.key, v) }
                v.setOnLongClickListener { beginDrag(v, "item", item, "") { showAppMenu(app, false, item, null) }; true }
                return v
            }
            Item.FOLDER -> {
                val f = StateStore.folders[item.ref] ?: return null
                val lay = LinearLayout(this)
                lay.orientation = LinearLayout.VERTICAL; lay.gravity = Gravity.CENTER; lay.tag = "folder"
                val sz = dp(Prefs.iconSize)
                lay.addView(FolderIconView(this, f, sz), LinearLayout.LayoutParams(sz, sz))
                if (Prefs.showLabels) {
                    val l = Ui.text(this, f.name, Prefs.labelSize.toFloat(), Color.WHITE)
                    l.maxLines = 1; l.setShadowLayer(4f, 0f, 1.5f, 0x99000000.toInt())
                    lay.addView(l)
                }
                lay.setOnClickListener { openFolder(f.id, lay) }
                lay.setOnLongClickListener { beginDrag(lay, "item", item, "") { showFolderMenu(f.id) }; true }
                return lay
            }
            Item.WIDGET -> {
                val id = item.ref.toIntOrNull() ?: return null
                val hv = hostViewFor(id) ?: return null
                return widgetWrap(item, hv)
            }
            Item.MEDIA -> return widgetWrap(item, MediaCardView(this))
            Item.BUILTIN -> return widgetWrap(item, com.sparrow.launcher.widgets.BuiltinWidgets.create(this, item.ref) { openDrawer(true, false) })
        }
        return null
    }

    private fun hostViewFor(id: Int): AppWidgetHostView? {
        hostViews[id]?.let { return it }
        val info = widgetMgr.getAppWidgetInfo(id) ?: return null
        return try {
            val hv = widgetHost.createView(this, id, info)
            hv.setAppWidget(id, info)
            hv.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
                val d = resources.displayMetrics.density
                val w = ((r - l) / d).toInt(); val h = ((b - t) / d).toInt()
                try { hv.updateAppWidgetSize(Bundle(), w, h, w, h) } catch (_: Exception) {}
            }
            hostViews[id] = hv
            hv
        } catch (e: Exception) { null }
    }

    private fun widgetWrap(item: Item, content: View): FrameLayout {
        val pad = dp(Prefs.widgetPad)
        val w = FrameLayout(this)
        w.tag = "widget"
        w.setPadding(pad, pad, pad, pad)
        (content.parent as? ViewGroup)?.removeView(content)
        w.addView(content, FrameLayout.LayoutParams(-1, -1))
        val r = dp(Prefs.widgetRadius).toFloat()
        content.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
        }
        content.clipToOutline = true
        if (Prefs.widgetHandle) {
            val h = Icons.button(this, "more", Color.WHITE, false) { widgetMenu(item) }
            h.setPadding(dp(5), dp(5), dp(5), dp(5))
            h.background = Ui.round(0x66000000, dp(13).toFloat())
            h.setOnLongClickListener { beginDrag(w, "item", item, "") { widgetMenu(item) }; true }
            w.addView(h, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.TOP or Gravity.END).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        return w
    }

    // ------------------------------------------------------------ تشغيل وتحريك
    private var splash: View? = null

    /** شاشة تحميل بأيقونة التطبيق تظهر قبل أن ينفتح (مثل الهواتف القديمة) وتختفي حالما ينفتح */
    private fun showSplash(app: AppInfo) {
        hideSplashNow()
        val s = FrameLayout(this)
        s.setBackgroundColor(0xDD000000.toInt())
        s.isClickable = true
        val lay = LinearLayout(this)
        lay.orientation = LinearLayout.VERTICAL
        lay.gravity = Gravity.CENTER
        val iv = android.widget.ImageView(this)
        val bmp = AppRepository.icon(app.key)
        if (bmp != null) iv.setImageDrawable(com.sparrow.launcher.apps.ShapedIcon(bmp, Prefs.iconShape))
        lay.addView(iv, LinearLayout.LayoutParams(dp(88), dp(88)))
        val tv = Ui.text(this, StateStore.names[app.key] ?: app.label, 15f, Color.WHITE, true)
        tv.gravity = Gravity.CENTER
        tv.setPadding(0, dp(12), 0, 0)
        lay.addView(tv)
        s.addView(lay, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(s, FrameLayout.LayoutParams(-1, -1))
        s.alpha = 0f
        s.animate().alpha(1f).setDuration(160).start()
        iv.scaleX = 0.7f; iv.scaleY = 0.7f
        iv.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(android.view.animation.OvershootInterpolator(1.6f)).start()
        splash = s
        Bg.main.postDelayed({ if (splash === s) hideSplash() }, 1600)
    }

    private fun hideSplash() {
        val v = splash ?: return
        splash = null
        v.animate().alpha(0f).setDuration(200).withEndAction { root.removeView(v) }.start()
    }

    private fun hideSplashNow() {
        splash?.let { root.removeView(it) }
        splash = null
    }

    override fun launchApp(key: String, from: View?) {
        val app = AppRepository.byKey[key] ?: return
        if (Prefs.launchSplash && !Prefs.reduceMotion) showSplash(app)
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(app.component)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            val o = if (from != null) ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height).toBundle() else null
            startActivity(i, o)
            StateStore.recordLaunch(key)
        } catch (e: Exception) { Ui.toast(this, "تعذر فتح التطبيق") }
        Bg.main.postDelayed({ closeAllOverlays() }, 300)
    }

    override fun launchDockEntry(entry: String, from: View?) {
        if (entry.startsWith("a:")) launchApp(entry.substring(2), from) else openFolder(entry.substring(2), from)
    }

    private fun startMove(item: Item) { moving = item; setGrid(true); Ui.toast(this, "اضغط على مكان فارغ لوضع العنصر (رجوع = إلغاء)") }

    private fun placeMoving(cell: CellLayout) {
        val it = moving ?: return
        val pos = cell.cellAt(cell.lastX, cell.lastY) ?: return
        val target = StateStore.workspaces[pager.current]
        if (!StateStore.isFree(target, pos[0], pos[1], it.sx, it.sy, Prefs.cols, Prefs.rows, it)) { Ui.toast(this, "المكان مشغول"); return }
        for (w in StateStore.workspaces) w.items.remove(it)
        it.col = pos[0]; it.row = pos[1]
        target.items.add(it)
        moving = null; setGrid(false)
        StateStore.save(); for (i in 0 until pager.count) refreshPage(i)
    }

    private fun placeNew(type: String, ref: String, sx: Int = 1, sy: Int = 1): Boolean {
        val ws = currentWs()
        val pos = StateStore.findFree(ws, sx.coerceAtMost(Prefs.cols), sy, Prefs.cols, Prefs.rows)
        if (pos == null) { Ui.toast(this, "لا توجد مساحة فارغة في الصفحة"); return false }
        ws.items.add(Item(StateStore.newId("i"), type, ref, pos.first, pos.second, sx.coerceAtMost(Prefs.cols), sy))
        StateStore.save(); refreshCurrent()
        return true
    }

    private fun removeItem(item: Item) {
        if (item.type == Item.WIDGET) { item.ref.toIntOrNull()?.let { try { widgetHost.deleteAppWidgetId(it) } catch (_: Exception) {}; hostViews.remove(it) } }
        for (w in StateStore.workspaces) w.items.remove(item)
        StateStore.save(); for (i in 0 until pager.count) refreshPage(i)
    }

    // ------------------------------------------------------------ القوائم
    override fun showAppMenu(app: AppInfo, fromDrawer: Boolean, item: Item?, folderId: String?) {
        val o = ArrayList<Opt>()
        o.add(Opt("فتح") { launchApp(app.key, null) })
        o.add(Opt("معلومات التطبيق") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg))) })
        if (item != null) { o.add(Opt("نقل") { startMove(item) }); o.add(Opt("إزالة من الصفحة") { removeItem(item) }) }
        else o.add(Opt("إضافة إلى الصفحة") { if (placeNew(Item.APP, app.key)) closeAllOverlays() })
        if (folderId != null) o.add(Opt("إزالة من المجلد") { StateStore.folders[folderId]?.apps?.remove(app.key); StateStore.save(); refreshAll() })
        o.add(Opt("إضافة إلى مجلد") { chooseFolder(app.key) })
        val ws = currentWs()
        o.add(Opt(if ("a:${app.key}" in StateStore.dock) "إزالة من الـDock" else "إضافة إلى الـDock") {
            if (!StateStore.dock.remove("a:${app.key}")) StateStore.dock.add("a:${app.key}")
            StateStore.save(); dock.bind()
        })
        o.add(Opt("إخفاء") { StateStore.hidden.add(app.key); StateStore.save(); refreshAll() })
        o.add(Opt("تغيير الاسم") { Ui.input(this, "الاسم الظاهر", StateStore.names[app.key] ?: app.label) { n ->
            if (n.isBlank()) StateStore.names.remove(app.key) else StateStore.names[app.key] = n.trim()
            StateStore.save(); refreshAll() } })
        o.add(Opt("تغيير الأيقونة من الصور") { pendingIcon = "app:" + app.key; pickImage() })
        o.add(Opt("أيقونة من حزمة أيقونات") { pickPackIcon(app) })
        o.add(Opt("استعادة الأيقونة الأصلية") { StateStore.icons.remove(app.key); StateStore.save(); refreshAll() })
        o.add(Opt("تغيير التصنيف") { Customizer.chooseCategory(this, app) { refreshAll() } })
        if (!app.system) o.add(Opt("إلغاء التثبيت") { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg))) })
        Ui.options(this, StateStore.names[app.key] ?: app.label, o)
    }

    /** اختيار أيقونة لتطبيق من حزمة أيقونات مثبتة (شبكة بصرية) */
    private fun pickPackIcon(app: AppInfo) {
        val packs = AppRepository.listPacks(this)
        if (packs.isEmpty()) { Ui.toast(this, "لا توجد حزم أيقونات مثبتة"); return }
        val load = { pkg: String ->
            Ui.toast(this, "جارٍ تحميل الأيقونات…")
            Bg.io.execute {
                val icons = AppRepository.packIcons(applicationContext, pkg)
                Bg.main.post { if (!isDestroyed) showPackGrid(app, icons) }
            }
        }
        if (packs.size == 1) load(packs[0].first) else Ui.list(this, "حزمة الأيقونات", packs.map { it.second }) { load(packs[it].first) }
    }

    private fun showPackGrid(app: AppInfo, icons: List<Pair<String, android.graphics.drawable.Drawable>>) {
        if (icons.isEmpty()) { Ui.toast(this, "الحزمة لا تحتوي أيقونات قابلة للقراءة"); return }
        val g = android.widget.GridLayout(this)
        g.columnCount = 5
        val sv = android.widget.ScrollView(this)
        sv.addView(g)
        val dlg = Ui.builder(this).setTitle("اختر أيقونة").setView(sv).setNegativeButton("إلغاء", null).create()
        for (pair in icons) {
            val d = pair.second
            val iv = android.widget.ImageView(this)
            iv.setImageDrawable(d)
            iv.setPadding(dp(6), dp(6), dp(6), dp(6))
            iv.setOnClickListener {
                dlg.dismiss()
                val path = Customizer.saveBitmap(this, AppRepository.toBitmap(d, 192))
                if (path != null) { StateStore.icons[app.key] = path; StateStore.save(); refreshAll() }
            }
            g.addView(iv, android.widget.GridLayout.LayoutParams().apply { width = dp(56); height = dp(56) })
        }
        dlg.show()
    }

    private fun pickImage() {
        try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), REQ_ICON) } catch (_: Exception) { Ui.toast(this, "لا يوجد تطبيق صور") }
    }

    private fun chooseFolder(key: String) {
        val fs = StateStore.folders.values.toList()
        val labels = ArrayList<String>(fs.map { it.name }); labels.add("＋ مجلد جديد")
        Ui.list(this, "إضافة إلى مجلد", labels) { i ->
            if (i < fs.size) { StateStore.addAppToFolder(fs[i].id, key); refreshAll() }
            else Ui.input(this, "اسم المجلد", "مجلد جديد") { n ->
                val f = StateStore.newFolder(n.ifBlank { "مجلد" }.trim())
                StateStore.addAppToFolder(f.id, key)
                if (placeNew(Item.FOLDER, f.id)) refreshAll()
            }
        }
    }

    override fun showFolderMenu(id: String) {
        val f = StateStore.folders[id] ?: return
        val o = ArrayList<Opt>()
        o.add(Opt("تغيير الاسم") { Ui.input(this, "اسم المجلد", f.name) { n -> if (n.isNotBlank()) { f.name = n.trim(); StateStore.save(); refreshAll() } } })
        o.add(Opt("أيقونة من الصور") { pendingIcon = "folder:$id"; pickImage() })
        o.add(Opt("أيقونة من المجموعة") { Customizer.pickEmoji(this) { e -> f.emoji = e; f.iconPath = ""; StateStore.save(); refreshAll() } })
        o.add(Opt("الأيقونة الافتراضية") { f.emoji = ""; f.iconPath = ""; StateStore.save(); refreshAll() })
        o.add(Opt("لون المجلد") { Customizer.pickColor(this) { c -> f.color = c; StateStore.save(); refreshAll() } })
        o.add(Opt(if (f.view == "list") "العرض: خيوط" else "العرض: قائمة") { f.view = if (f.view == "list") "orbit" else "list"; StateStore.save(); refreshAll() })
        o.add(Opt("إضافة تطبيق") { addAppToFolderPicker(id) })
        o.add(Opt("إضافة مجلد فرعي") { newSubFolder(id) })
        o.add(Opt("نقل داخل مجلد آخر") { moveFolderPicker(id) })
        o.add(Opt("تحويل إلى تصنيف") {
            for (k in f.apps) StateStore.categories[k] = "c:" + f.name
            StateStore.save(); refreshAll(); Ui.toast(this, "تم إنشاء التصنيف: " + f.name)
        })
        o.add(Opt("حذف المجلد") { Ui.confirm(this, "حذف المجلد وما بداخله من مجلدات؟ التطبيقات تبقى مثبتة.") { StateStore.deleteFolder(id); refreshAll() } })
        Ui.options(this, f.name, o)
    }

    /** نقل مجلد داخل مجلد آخر (أو إخراجه للصفحة). يمنع وضعه داخل نفسه أو أبنائه */
    private fun moveFolderPicker(id: String) {
        val bad = StateStore.descendants(id)
        val fs = StateStore.folders.values.filter { it.id !in bad }
        val labels = ArrayList<String>()
        labels.add("إخراجه إلى الصفحة الحالية")
        fs.forEach { labels.add(it.name) }
        Ui.list(this, "نقل إلى", labels) { i ->
            if (i == 0) { StateStore.detachFolder(id); placeNew(Item.FOLDER, id) }
            else StateStore.moveFolderInto(id, fs[i - 1].id)
            StateStore.save(); refreshAll()
        }
    }

    override fun addAppToFolderPicker(folderId: String) = pickApp("إضافة تطبيق") { StateStore.addAppToFolder(folderId, it.key); refreshAll() }

    override fun newSubFolder(parentId: String) {
        Ui.input(this, "اسم المجلد الفرعي", "مجلد") { n ->
            val f = StateStore.newFolder(n.ifBlank { "مجلد" }.trim())
            StateStore.folders[parentId]?.folders?.add(f.id)
            StateStore.save(); refreshAll()
        }
    }

    /** فتح مجلد: نافذة تكبر من الأيقونة بأيقونات حقيقية، والمجلدات الفرعية بشبكة 3x3 (بلا حد للتداخل) */
    override fun openFolder(id: String, from: View?) {
        if (StateStore.folders[id] == null) return
        showOverlay(FolderStageView(this, this, id, from))
    }

    override fun showDockMenu(entry: String) {
        val ws = currentWs()
        val o = ArrayList<Opt>()
        o.add(Opt("فتح") { launchDockEntry(entry, null) })
        o.add(Opt("إزالة من الـDock") { StateStore.dock.remove(entry); StateStore.save(); dock.bind() })
        o.add(Opt("تقديم") { val i = StateStore.dock.indexOf(entry); if (i > 0) { StateStore.dock.removeAt(i); StateStore.dock.add(i - 1, entry); StateStore.save(); dock.bind() } })
        o.add(Opt("تأخير") { val i = StateStore.dock.indexOf(entry); if (i in 0 until StateStore.dock.size - 1) { StateStore.dock.removeAt(i); StateStore.dock.add(i + 1, entry); StateStore.save(); dock.bind() } })
        Ui.options(this, null, o)
    }

    override fun addToDock() = pickApp("إضافة إلى الـDock") {
        val ws = currentWs()
        if ("a:${it.key}" !in StateStore.dock) StateStore.dock.add("a:${it.key}")
        StateStore.save(); dock.bind()
    }

    /** منتقي تطبيقات بصري: نفس الدرج بأيقونات حقيقية وبحث، والضغط على تطبيق يختاره */
    override fun pickApp(title: String, cb: (AppInfo) -> Unit) {
        val d = DrawerView(this, this, false, topInset, bottomInset, cb)
        d.setHint(title)
        showOverlay(d)
    }

    override fun dragFromDrawer(v: View, app: AppInfo) { beginDrag(v, "drawer", null, "a:" + app.key) { showAppMenu(app, true, null, null) } }

    private fun showHomeMenu() {
        val o = ArrayList<Opt>()
        o.add(Opt("إضافة Widget") { addWidget() })
        o.add(Opt("إضافة تطبيق") { pickApp("إضافة تطبيق") { placeNew(Item.APP, it.key) } })
        o.add(Opt("إضافة مجلد") { Ui.input(this, "اسم المجلد", "مجلد جديد") { n -> val f = StateStore.newFolder(n.ifBlank { "مجلد" }.trim()); placeNew(Item.FOLDER, f.id) } })
        o.add(Opt("إضافة Workspace") { addWorkspace() })
        o.add(Opt("نظرة عامة على المساحات") { openOverview() })
        o.add(Opt("ترتيب الصفحة أبجدياً") { arrangePage(true) })
        o.add(Opt("تجميع الصفحة (سد الفراغات)") { arrangePage(false) })
        o.add(Opt("الخلفية") { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "الخلفية")) })
        o.add(Opt("التخطيط (الشبكة)") { layoutMenu() })
        o.add(Opt("الإعدادات") { startActivity(Intent(this, SettingsActivity::class.java)) })
        Ui.options(this, null, o)
    }

    /** ترتيب تلقائي لتطبيقات ومجلدات الصفحة (الويدجت تبقى بمكانها) */
    private fun arrangePage(alpha: Boolean) {
        val ws = currentWs()
        val movable = ws.items.filter { it.type == Item.APP || it.type == Item.FOLDER }
        if (movable.isEmpty()) { Ui.toast(this, "لا توجد عناصر لترتيبها"); return }
        fun label(m: Item): String =
            if (m.type == Item.APP) (StateStore.names[m.ref] ?: AppRepository.byKey[m.ref]?.label ?: m.ref) else (StateStore.folders[m.ref]?.name ?: "")
        val ordered = if (alpha) movable.sortedBy { label(it).lowercase() } else movable.sortedWith(compareBy<Item>({ it.row }, { it.col }))
        ws.items.removeAll(movable.toSet())
        for (m in ordered) {
            val pos = StateStore.findFree(ws, 1, 1, Prefs.cols, Prefs.rows)
            if (pos != null) { m.col = pos.first; m.row = pos.second }
            ws.items.add(m)
        }
        StateStore.save(); refreshCurrent()
    }

    private fun layoutMenu() {
        val p = listOf(3 to 4, 4 to 5, 4 to 6, 5 to 6, 5 to 7, 6 to 7, 6 to 8, 7 to 9)
        Ui.list(this, "حجم الشبكة", p.map { "${it.first} × ${it.second}" }) { i ->
            Prefs.put("grid_cols", p[i].first); Prefs.put("grid_rows", p[i].second)
            for (it in StateStore.relayout(p[i].first, p[i].second)) if (it.type == Item.WIDGET) it.ref.toIntOrNull()?.let { id -> try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {} }
            seenVersion = Prefs.version; rebuildPages()
        }
    }

    private fun addWorkspace() {
        StateStore.addWorkspace("مساحة ${StateStore.workspaces.size + 1}")
        StateStore.currentIndex = StateStore.workspaces.size - 1
        StateStore.save(); rebuildPages()
    }

    // ------------------------------------------------------------ Widgets الحقيقية
    /** يفتح منتقي Sparrow: بطاقات بمعاينة حقيقية وأحجام جاهزة (مثل 4×2) */
    private fun addWidget() {
        if (overlays.isNotEmpty()) return
        val page = pager.page(pager.current) ?: return
        showOverlay(WidgetPickerView(this, this, topInset, bottomInset, Prefs.cols, Prefs.rows, page.cellW, page.cellH) { kind, info, sx, sy -> startWidget(kind, info, sx, sy) })
    }

    private fun startWidget(kind: String, info: AppWidgetProviderInfo?, sx: Int, sy: Int) {
        if (info == null) { if (kind == "music") placeNew(Item.MEDIA, "media", sx, sy) else placeNew(Item.BUILTIN, kind, sx, sy); return }
        pendingWs = pager.current; pendingSx = sx; pendingSy = sy; pendingInfo = info
        pendingId = widgetHost.allocateAppWidgetId()
        val ok = try { widgetMgr.bindAppWidgetIdIfAllowed(pendingId, info.provider) } catch (e: Exception) { false }
        if (ok) afterBind(pendingId, info)
        else try {
            startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider), REQ_BIND)
        } catch (e: Exception) { Ui.toast(this, "تعذر ربط الويدجت"); try { widgetHost.deleteAppWidgetId(pendingId) } catch (_: Exception) {} }
    }

    private fun afterBind(id: Int, info: AppWidgetProviderInfo) {
        if (info.configure != null) {
            try { widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null) } catch (e: Exception) { finishWidget(id, info) }
        } else finishWidget(id, info)
    }

    private fun widgetMenu(item: Item) {
        val o = ArrayList<Opt>()
        o.add(Opt("تغيير الحجم بالسحب") { startResize(item) })
        o.add(Opt("تكبير العرض") { resizeWidget(item, 1, 0) })
        o.add(Opt("تصغير العرض") { resizeWidget(item, -1, 0) })
        o.add(Opt("تكبير الارتفاع") { resizeWidget(item, 0, 1) })
        o.add(Opt("تصغير الارتفاع") { resizeWidget(item, 0, -1) })
        o.add(Opt("نقل") { startMove(item) })
        o.add(Opt("إزالة") { removeItem(item) })
        Ui.options(this, "Widget", o)
    }

    /** تغيير حجم حر بالسحب: يلتصق بالخلايا ويحترم حدود الصفحة والعناصر الأخرى وقيود الويدجت */
    private fun startResize(item: Item) {
        if (overlays.isNotEmpty()) return
        val idx = StateStore.workspaces.indexOfFirst { item in it.items }
        if (idx < 0) return
        val cl = pager.page(idx) ?: return
        var wrapper: View? = null
        for (i in 0 until cl.childCount) {
            val c = cl.getChildAt(i)
            val l = c.layoutParams as CellLayout.LP
            if (l.col == item.col && l.row == item.row) wrapper = c
        }
        val w = wrapper ?: return
        val id = item.ref.toIntOrNull()
        val info = if (item.type == Item.WIDGET && id != null) widgetMgr.getAppWidgetInfo(id) else null
        if (info != null && info.resizeMode == AppWidgetProviderInfo.RESIZE_NONE) { Ui.toast(this, "هذا الويدجت لا يدعم تغيير الحجم"); return }
        val minSx = if (info != null) ceil((if (info.minResizeWidth > 0) info.minResizeWidth else info.minWidth).toFloat() / max(1, cl.cellW)).toInt().coerceAtLeast(1) else 1
        val minSy = if (info != null) ceil((if (info.minResizeHeight > 0) info.minResizeHeight else info.minHeight).toFloat() / max(1, cl.cellH)).toInt().coerceAtLeast(1) else 1
        val ws = StateStore.workspaces[idx]
        val ov = ResizeOverlay(this, w, w.layoutParams as CellLayout.LP, cl,
            { nx, ny ->
                val hOk = info == null || (info.resizeMode and AppWidgetProviderInfo.RESIZE_HORIZONTAL) != 0 || nx == item.sx
                val vOk = info == null || (info.resizeMode and AppWidgetProviderInfo.RESIZE_VERTICAL) != 0 || ny == item.sy
                if (nx >= minSx && ny >= minSy && hOk && vOk && StateStore.isFree(ws, item.col, item.row, nx, ny, Prefs.cols, Prefs.rows, item)) {
                    item.sx = nx; item.sy = ny; true
                } else false
            },
            { StateStore.save() },
            { closeOverlay(it) })
        showOverlay(ov)
    }

    private fun resizeWidget(item: Item, dx: Int, dy: Int) {
        val ws = StateStore.workspaces.firstOrNull { item in it.items } ?: return
        val id = item.ref.toIntOrNull()
        val info = if (id != null) widgetMgr.getAppWidgetInfo(id) else null
        if (info != null && info.resizeMode == AppWidgetProviderInfo.RESIZE_NONE) { Ui.toast(this, "هذا الويدجت لا يدعم تغيير الحجم"); return }
        val nx = item.sx + dx; val ny = item.sy + dy
        if (nx < 1 || ny < 1) return
        if (!StateStore.isFree(ws, item.col, item.row, nx, ny, Prefs.cols, Prefs.rows, item)) { Ui.toast(this, "لا توجد مساحة (حدود الصفحة أو عنصر آخر)"); return }
        item.sx = nx; item.sy = ny
        StateStore.save(); refreshPage(StateStore.workspaces.indexOf(ws))
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        when (req) {
            REQ_BIND -> {
                val info = pendingInfo
                if (res == RESULT_OK && info != null) afterBind(pendingId, info)
                else try { widgetHost.deleteAppWidgetId(pendingId) } catch (_: Exception) {}
            }
            REQ_CONFIG -> {
                val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId) ?: pendingId
                val info = widgetMgr.getAppWidgetInfo(id)
                if (res == RESULT_OK && info != null) finishWidget(id, info)
                else try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {}
            }
            REQ_ICON -> {
                val uri = data?.data ?: return
                val path = Customizer.importIcon(this, uri) ?: run { Ui.toast(this, "تعذر قراءة الصورة"); return }
                val parts = pendingIcon.split(":", limit = 2)
                if (parts.size == 2) {
                    if (parts[0] == "app") StateStore.icons[parts[1]] = path else StateStore.folders[parts[1]]?.iconPath = path
                    StateStore.save(); refreshAll()
                }
            }
        }
    }

    private fun finishWidget(id: Int, info: AppWidgetProviderInfo) {
        val page = pager.page(pendingWs) ?: return
        val ws = StateStore.workspaces[pendingWs]
        val sx = if (pendingSx > 0) pendingSx else ceil(info.minWidth.toFloat() / max(1, page.cellW)).toInt().coerceIn(1, Prefs.cols)
        val sy = if (pendingSy > 0) pendingSy else ceil(info.minHeight.toFloat() / max(1, page.cellH)).toInt().coerceIn(1, Prefs.rows)
        pendingSx = 0; pendingSy = 0
        val pos = StateStore.findFree(ws, sx, sy, Prefs.cols, Prefs.rows)
        if (pos == null) { Ui.toast(this, "لا توجد مساحة كافية بهذا الحجم في الصفحة"); try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {}; return }
        ws.items.add(Item(StateStore.newId("w"), Item.WIDGET, id.toString(), pos.first, pos.second, sx, sy))
        StateStore.save(); refreshPage(pendingWs)
    }

    // ------------------------------------------------------------ الشاشات العلوية (Overlays)
    private fun showOverlay(v: View) {
        overlays.add(v)
        root.addView(v, FrameLayout.LayoutParams(-1, -1))
        setDepth((v as? Overlay)?.depth ?: 1f)
    }

    override fun closeOverlay(v: View) {
        overlays.remove(v)
        val done = { root.removeView(v); if (overlays.isEmpty()) setDepth(0f) }
        if (v is Overlay) v.animateOut(done) else done()
    }

    private fun closeAllOverlays() {
        for (v in ArrayList(overlays)) root.removeView(v)
        overlays.clear(); setDepth(0f)
    }

    private var zoomM: java.lang.reflect.Method? = null
    private var zoomFail = false

    /** تكبير/تصغير الخلفية عند فتح الشاشات (Reflection آمن حتى لا يتعطل البناء على أي SDK) */
    private fun zoomWallpaper(z: Float) {
        if (zoomFail || !Prefs.wallpaperZoom) return
        try {
            val tok = window.decorView.windowToken ?: return
            if (zoomM == null) zoomM = WallpaperManager::class.java.getMethod("setWallpaperZoomOut", android.os.IBinder::class.java, java.lang.Float.TYPE)
            zoomM?.invoke(wm, tok, z)
        } catch (e: Throwable) { zoomFail = true }
    }

    private fun setDepth(z: Float) {
        zoomWallpaper(z * 0.5f)
        if (z > 0f) { Bg.main.removeCallbacks(searchRun); showSearch(false) } else scheduleSearch()
        for (v in listOf<View>(pager, dock, dots, pill)) { v.scaleX = 1f - 0.05f * z; v.scaleY = 1f - 0.05f * z }
        if (Build.VERSION.SDK_INT >= 31) try { window.setBackgroundBlurRadius((z * Prefs.blur * resources.displayMetrics.density * 0.6f).toInt()) } catch (_: Exception) {}
    }

    private fun openDrawer(focus: Boolean, hidden: Boolean) {
        if (overlays.isNotEmpty()) return
        val d = DrawerView(this, this, hidden, topInset, bottomInset)
        showOverlay(d)
        if (focus) d.focusSearch()
    }

    private fun openControls() { if (overlays.isEmpty()) showOverlay(ControlPanelView(this, this, topInset, bottomInset)) }

    private fun openRecents() { if (overlays.isEmpty()) showOverlay(RecentsView(this, this, topInset, bottomInset)) }

    private fun openOverview() {
        if (overlays.isNotEmpty()) return
        val snaps = ArrayList<Bitmap>()
        val sc = 0.4f
        for (i in 0 until pager.count) {
            val p = pager.page(i) ?: continue
            val b = Bitmap.createBitmap(max(1, (p.width * sc).toInt()), max(1, (p.height * sc).toInt()), Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            c.drawColor(Theme.surface(this))
            c.scale(sc, sc)
            try { p.draw(c) } catch (_: Exception) {}
            snaps.add(b)
        }
        lateinit var ov: OverviewView
        fun reopen() { closeAllOverlays(); rebuildPages(); pager.afterLayout { openOverview() } }
        ov = OverviewView(this, snaps, pager.current, topInset, bottomInset,
            onOpen = { i -> closeOverlay(ov); pager.goTo(i, false) },
            onAdd = { addWorkspace(); reopen() },
            onDelete = { i ->
                Ui.confirm(this, "حذف هذه المساحة وكل محتوياتها؟") {
                    StateStore.removeWorkspace(i)?.let { w -> for (it in w.items) if (it.type == Item.WIDGET) it.ref.toIntOrNull()?.let { id -> try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) {} } }
                    StateStore.save(); reopen()
                }
            },
            onHome = { i -> StateStore.homeIndex = i; StateStore.save(); Ui.toast(this, "تم تعيينها كصفحة رئيسية"); reopen() },
            onRename = { i -> Ui.input(this, "اسم المساحة", StateStore.workspaces[i].name) { n -> if (n.isNotBlank()) { StateStore.workspaces[i].name = n.trim(); StateStore.save(); reopen() } } },
            onTint = { i -> Customizer.pickColor(this) { col -> StateStore.workspaces[i].tint = if (col == 0x66FFFFFF) 0 else col and 0x33FFFFFF.toInt() or 0x22000000; StateStore.save(); reopen() } },
            onMove = { a, b -> if (StateStore.moveWorkspace(a, b)) { StateStore.currentIndex = b; StateStore.save(); reopen() } },
            onClose = { closeOverlay(ov) })
        showOverlay(ov)
    }

    private fun refreshAll() {
        for (i in 0 until pager.count) refreshPage(i)
        dock.bind()
        for (o in ArrayList(overlays)) { if (o is DrawerView) { o.buildChips(); o.refresh() } else if (o is FolderStageView) o.refresh() }
    }

    // ------------------------------------------------------------ تحميل التطبيقات
    private fun reloadApps() { AppRepository.load(this) { if (!isDestroyed) onAppsLoaded() } }

    private fun onAppsLoaded() {
        if (AppRepository.apps.isNotEmpty()) StateStore.prune(AppRepository.byKey.keys)
        seedDefaults()
        rebuildPages(); layoutHome()
        for (o in overlays) if (o is DrawerView) { o.buildChips(); o.refresh() }
    }

    /** أول تشغيل: يضع الهاتف/الرسائل/المتصفح/الكاميرا في الـDock إن وُجدت */
    private fun seedDefaults() {
        if (Prefs.bool("seeded", false) || AppRepository.apps.isEmpty()) return
        val ws = StateStore.workspaces[0]
        for (kw in listOf("dialer", "messag", "chrome", "camera")) {
            val a = AppRepository.apps.firstOrNull { it.pkg.lowercase().contains(kw) } ?: continue
            if ("a:${a.key}" !in StateStore.dock) StateStore.dock.add("a:${a.key}")
        }
        StateStore.save()
        Prefs.putQuiet("seeded", true)
        Ui.toast(this, "اضغط مطولاً على مساحة فارغة لإضافة ويدجت وتطبيقات")
    }

    // ------------------------------------------------------------ السحب والإفلات
    private var dragKind = ""
    private var dragItem: Item? = null
    private var dragEntry = ""
    private var dragView: View? = null
    private var dragMenu: (() -> Unit)? = null
    private var dragSx = 0f
    private var dragSy = 0f
    private var dragMoved = false
    private var zoneView: View? = null
    private var edgeSide = 0
    private val edgeRun = Runnable { val s = edgeSide; edgeSide = 0; if (s != 0) pager.goTo(pager.current + s) }

    private val dragListener = View.OnDragListener { _, e ->
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> { dragSx = e.x; dragSy = e.y; dragMoved = false; true }
            DragEvent.ACTION_DRAG_LOCATION -> { onDragMove(e.x, e.y); true }
            DragEvent.ACTION_DROP -> { onDrop(e.x, e.y); true }
            DragEvent.ACTION_DRAG_ENDED -> { onDragEnd(); true }
            else -> true
        }
    }

    override fun dragDockEntry(v: View, entry: String) { beginDrag(v, "dock", null, entry) { showDockMenu(entry) } }

    /** الضغط المطول يبدأ سحباً. إذا تركته بدون تحريك تظهر القائمة (menu) */
    private fun beginDrag(v: View, kind: String, item: Item?, entry: String, menu: () -> Unit) {
        dragKind = kind; dragItem = item; dragEntry = entry; dragView = v; dragMenu = menu; dragMoved = false
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        setGrid(true)
        if (kind != "drawer") showZone()
        v.alpha = 0.35f
        val ok = try { v.startDragAndDrop(ClipData.newPlainText("sparrow", "x"), View.DragShadowBuilder(v), null, 0) } catch (e: Exception) { false }
        if (!ok) { v.alpha = 1f; setGrid(false); zoneView?.let { root.removeView(it) }; zoneView = null; menu() }
    }

    private fun showZone() {
        val z = Ui.pillIcon(this, "trash", "اسحب هنا للإزالة") {}
        z.alpha = 0f
        root.addView(z, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = topInset + dp(14) })
        z.animate().alpha(1f).setDuration(160).start()
        zoneView = z
    }

    private fun dockHit(y: Float): Boolean = Prefs.dockShow && dock.visibility == View.VISIBLE && y > dock.top - dp(10)
    private fun inZone(y: Float): Boolean = y < topInset + dp(96)

    private fun toPage(page: CellLayout, rx: Float, ry: Float): Pair<Float, Float> {
        val a = IntArray(2); val b = IntArray(2)
        page.getLocationOnScreen(a); root.getLocationOnScreen(b)
        return Pair(rx - (a[0] - b[0]), ry - (a[1] - b[1]))
    }

    private fun onDragMove(x: Float, y: Float) {
        if (!dragMoved && hypot(x - dragSx, y - dragSy) > dp(24)) dragMoved = true
        if (dragKind == "drawer" && dragMoved) { val d = overlays.firstOrNull { it is DrawerView }; if (d != null) closeOverlay(d) }
        // السحب لحافة الشاشة ينقلك للصفحة المجاورة
        val side = when { x < dp(36) -> -1; x > root.width - dp(36) -> 1; else -> 0 }
        val pg = side * (if (pager.rtl) -1 else 1)
        if (side == 0) { edgeSide = 0; Bg.main.removeCallbacks(edgeRun) }
        else if (edgeSide != pg) { edgeSide = pg; Bg.main.removeCallbacks(edgeRun); Bg.main.postDelayed(edgeRun, 600) }
        for (i in 0 until pager.count) pager.page(i)?.hover = null
        if (inZone(y) || dockHit(y)) return
        val page = pager.page(pager.current) ?: return
        val p = toPage(page, x, y)
        page.hover = page.cellAt(p.first, p.second)
    }

    private fun onDrop(x: Float, y: Float) {
        if (inZone(y) && dragKind != "drawer") {
            val di = dragItem
            if (dragKind == "dock") StateStore.dock.remove(dragEntry) else if (di != null) removeItem(di)
            StateStore.save(); refreshAll(); return
        }
        if (dockHit(y)) { dropOnDock(x); return }
        val page = pager.page(pager.current) ?: return
        val p = toPage(page, x, y)
        val cell = page.cellAt(p.first, p.second) ?: return
        dropOnCell(cell[0], cell[1])
    }

    private fun dropOnDock(x: Float) {
        val di = dragItem
        val entry = when {
            dragKind == "dock" || dragKind == "drawer" -> dragEntry
            di != null && di.type == Item.APP -> "a:" + di.ref
            di != null && di.type == Item.FOLDER -> "f:" + di.ref
            else -> return
        }
        val loc = IntArray(2); root.getLocationOnScreen(loc)
        var idx = dock.indexAt(x + loc[0])
        val old = StateStore.dock.indexOf(entry)
        if (old >= 0) { StateStore.dock.removeAt(old); if (old < idx) idx-- }
        idx = idx.coerceIn(0, StateStore.dock.size)
        StateStore.dock.add(idx, entry)
        if (dragKind == "item" && di != null) for (w in StateStore.workspaces) w.items.remove(di)
        StateStore.save(); refreshAll()
    }

    private fun dropOnCell(c: Int, r: Int) {
        val ws = currentWs()
        val fromDock = dragKind == "dock"
        val src: Item = dragItem ?: run {
            val e = dragEntry
            if (e.length < 3) return
            Item(StateStore.newId("i"), if (e.startsWith("a:")) Item.APP else Item.FOLDER, e.substring(2), c, r)
        }
        // مكان فارغ: انقل
        if (StateStore.isFree(ws, c, r, src.sx, src.sy, Prefs.cols, Prefs.rows, src)) {
            for (w in StateStore.workspaces) w.items.remove(src)
            src.col = c; src.row = r; ws.items.add(src)
            if (fromDock) StateStore.dock.remove(dragEntry)
            StateStore.save(); refreshAll(); return
        }
        val o = ws.items.firstOrNull { it !== src && c >= it.col && c < it.col + it.sx && r >= it.row && r < it.row + it.sy }
        if (o == null) { Ui.toast(this, "لا توجد مساحة هنا"); return }
        // تطبيق فوق مجلد: أضفه للمجلد
        if (src.type == Item.APP && o.type == Item.FOLDER) {
            StateStore.addAppToFolder(o.ref, src.ref)
            if (fromDock) StateStore.dock.remove(dragEntry)
            StateStore.save(); refreshAll(); return
        }
        // تطبيق فوق تطبيق: أنشئ مجلداً جديداً يضمّهما
        if (src.type == Item.APP && o.type == Item.APP && src.ref != o.ref) {
            val f = StateStore.newFolder("مجلد")
            f.apps.add(o.ref); f.apps.add(src.ref)
            for (w in StateStore.workspaces) { w.items.remove(src); w.items.remove(o) }
            StateStore.dock.remove("a:" + src.ref)
            ws.items.add(Item(StateStore.newId("i"), Item.FOLDER, f.id, o.col, o.row))
            StateStore.save(); refreshAll()
            Ui.input(this, "اسم المجلد الجديد", "مجلد") { n -> if (n.isNotBlank()) { f.name = n.trim(); StateStore.save(); refreshAll() } }
            return
        }
        // مجلد فوق مجلد: تداخل (المجلد يصير داخل الآخر، بلا حد للعمق)
        if (src.type == Item.FOLDER && o.type == Item.FOLDER && src.ref != o.ref) {
            if (StateStore.moveFolderInto(src.ref, o.ref)) {
                if (fromDock) StateStore.dock.remove(dragEntry)
                StateStore.save(); refreshAll(); Ui.toast(this, "تم وضع المجلد داخل المجلد الآخر"); return
            }
        }
        Ui.toast(this, "المكان مشغول")
    }

    private fun onDragEnd() {
        Bg.main.removeCallbacks(edgeRun); edgeSide = 0
        dragView?.alpha = 1f
        setGrid(false)
        for (i in 0 until pager.count) pager.page(i)?.hover = null
        zoneView?.let { root.removeView(it) }; zoneView = null
        val m = dragMenu
        dragMenu = null; dragItem = null; dragView = null
        if (!dragMoved && m != null) m()
    }

    // ------------------------------------------------------------ الإيماءات
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        val r = super.dispatchTouchEvent(e)
        if (overlays.isEmpty() && moving == null) gestures(e)
        return r
    }

    private fun gestures(e: MotionEvent) {
        scale.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gx = e.rawX; gy = e.rawY; gt = e.eventTime; twoOn = false
                val hit = pager.page(pager.current)?.hitChild(e.rawX, e.rawY)
                gOk = hit == null || hit.tag != "widget"
                gEmpty = hit == null
            }
            MotionEvent.ACTION_POINTER_DOWN -> if (e.pointerCount == 2) { twoOn = true; gOk = false; twoStartX = (e.getX(0) + e.getX(1)) / 2; twoX = twoStartX }
            MotionEvent.ACTION_MOVE -> if (twoOn && e.pointerCount >= 2) twoX = (e.getX(0) + e.getX(1)) / 2
            MotionEvent.ACTION_POINTER_UP -> if (twoOn) {
                twoOn = false
                val dx = twoX - twoStartX
                if (abs(dx) > dp(120)) runAction(GestureActions.spec(if (dx < 0) "two_left" else "two_right"))
            }
            MotionEvent.ACTION_UP -> if (gOk && !twoOn && gy > topInset) {
                val dx = e.rawX - gx; val dy = e.rawY - gy
                if (dy > dp(90) && abs(dy) > abs(dx) * 1.4f) runAction(GestureActions.spec("swipe_down"))
                else if (dy < -dp(90) && abs(dy) > abs(dx) * 1.4f) runAction(GestureActions.spec("swipe_up"))
                else if (abs(dx) < dp(24) && abs(dy) < dp(24) && e.eventTime - gt < 260 && gEmpty) {
                    if (e.eventTime - lastTapT < 320 && abs(e.rawX - lastTapX) < dp(60)) { lastTapT = 0; runAction(GestureActions.spec("double_tap")) }
                    else { lastTapT = e.eventTime; lastTapX = e.rawX }
                }
            }
            MotionEvent.ACTION_CANCEL -> gOk = false
        }
    }

    private fun runAction(spec: String) {
        val p = spec.split("|", limit = 2)
        val arg = if (p.size > 1) p[1] else ""
        try {
            when (p[0]) {
                "drawer" -> openDrawer(false, false)
                "search" -> openDrawer(true, false)
                "overview" -> openOverview()
                "recents" -> openRecents()
                "controls" -> openControls()
                "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
                "next" -> pager.goTo(pager.current + 1)
                "prev" -> pager.goTo(pager.current - 1)
                "hidden" -> openDrawer(false, true)
                "menu" -> showHomeMenu()
                "app" -> launchApp(arg, null)
                "image" -> startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(arg), "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                "sysset" -> startActivity(Intent(arg))
                "workspace" -> pager.goTo(arg.toIntOrNull() ?: 0)
            }
        } catch (e: Exception) { Ui.toast(this, "تعذر تنفيذ الإيماءة") }
    }
}
