package com.sparrow.launcher.folders

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.LinearLayout
import com.sparrow.launcher.apps.AppCellView
import com.sparrow.launcher.apps.AppInfo
import com.sparrow.launcher.apps.AppRepository
import com.sparrow.launcher.apps.FolderIconView
import com.sparrow.launcher.core.LauncherController
import com.sparrow.launcher.core.Overlay
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.core.afterLayout
import com.sparrow.launcher.persistence.StateStore
import kotlin.math.ceil
import kotlin.math.min

/**
 * نافذة المجلد: تكبر من مكان المجلد، تعرض أيقونات التطبيقات (اضغط = يفتح التطبيق).
 * إذا فيه مجلدات فرعية تظهر بشبكة 3×3 حول المجلد الرئيسي (المركز). الضغط على مجلد فرعي يدخل إليه
 * بحركة انتقال، وسهم الرجوع يطلع خطوة لفوق. عمق التداخل غير محدود.
 */
class FolderStageView(
    ctx: Context,
    private val c: LauncherController,
    startId: String,
    private val src: View?
) : FrameLayout(ctx), Overlay {

    override val depth: Float get() = 1f
    private val stack = ArrayList<String>()
    private val card = LinearLayout(ctx)
    private var apps: List<AppInfo> = emptyList()
    private val adapter = Adapter()

    init {
        stack.add(startId)
        layoutDirection = Ui.layoutDir()
        isClickable = true
        setBackgroundColor(0x88000000.toInt())
        setOnClickListener { c.closeOverlay(this) }
        card.orientation = LinearLayout.VERTICAL
        card.background = Theme.panel(ctx, Ui.dpf(ctx, 30f))
        card.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 12), Ui.dp(ctx, 14), Ui.dp(ctx, 16))
        card.isClickable = true
        val w = (resources.displayMetrics.widthPixels * 0.92f).toInt()
        addView(card, LayoutParams(w, -2, Gravity.CENTER))
        render(false)
        // فتح: يكبر من مكان أيقونة المجلد
        alpha = 0f
        card.scaleX = 0.35f
        card.scaleY = 0.35f
        afterLayout {
            val s = src
            if (s != null) {
                val a = IntArray(2); val b = IntArray(2)
                s.getLocationOnScreen(a); card.getLocationOnScreen(b)
                card.pivotX = a[0] + s.width / 2f - b[0]
                card.pivotY = a[1] + s.height / 2f - b[1]
            }
            val d = if (Prefs.reduceMotion || !Prefs.folderAnim) 0L else 280L
            animate().alpha(1f).setDuration(d).start()
            card.animate().scaleX(1f).scaleY(1f).setDuration(d).setInterpolator(android.view.animation.OvershootInterpolator(0.8f)).start()
        }
    }

    private fun cur() = StateStore.folders[stack.last()]

    fun refresh() {
        if (cur() == null) { c.closeOverlay(this); return }
        render(false)
    }

    private fun go(id: String) { stack.add(id); render(true) }

    private fun back() {
        if (stack.size > 1) { stack.removeAt(stack.size - 1); render(true) } else c.closeOverlay(this)
    }

    private fun render(animate: Boolean) {
        val f = cur() ?: run { c.closeOverlay(this); return }
        card.removeAllViews()
        val ctx = context
        val txt = Theme.text(ctx)

        // الرأس: رجوع | الاسم | إضافة | خيارات
        val head = LinearLayout(ctx)
        head.gravity = Gravity.CENTER_VERTICAL
        val arrow = if (stack.size > 1) (if (Ui.layoutDir() == View.LAYOUT_DIRECTION_LTR) "back" else "fwd") else "close"
        fun hb(kind: String, click: () -> Unit) {
            head.addView(com.sparrow.launcher.core.Icons.button(ctx, kind, txt, false, click), LinearLayout.LayoutParams(Ui.dp(ctx, 44), Ui.dp(ctx, 44)))
        }
        hb(arrow) { back() }
        val title = Ui.text(ctx, f.name, 19f, txt, true)
        title.gravity = Gravity.CENTER
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        hb("plus") {
            Ui.options(ctx, "إضافة", listOf(
                com.sparrow.launcher.core.Opt("تطبيق") { c.addAppToFolderPicker(f.id) },
                com.sparrow.launcher.core.Opt("مجلد فرعي") { c.newSubFolder(f.id) }
            ))
        }
        hb("gear") { c.showFolderMenu(f.id) }
        card.addView(head, LinearLayout.LayoutParams(-1, -2))

        // مجلدات فرعية: المجلد الرئيسي بالمركز وخيوط بيضاء تربطه بأيقونات المجلدات الفرعية
        val kids = f.folders.mapNotNull { StateStore.folders[it] }
        if (kids.isNotEmpty() && f.view == "list") {
            val lines = LinesView(ctx)
            val orbit = OrbitLayout(ctx, lines)
            orbit.addView(lines, LayoutParams(-1, -1))
            orbit.addView(centerNode(f), LayoutParams(-2, -2))
            val shownKids = if (kids.size > 6) kids.take(5) else kids
            for (k in shownKids) orbit.addView(kidNode(k), LayoutParams(-2, -2))
            if (kids.size > 6) orbit.addView(moreNode(kids), LayoutParams(-2, -2))
            card.addView(orbit, LinearLayout.LayoutParams(-1, Ui.dp(ctx, 270)))
        }

        if (f.view != "list") {
            // نمط الخيوط: المجلد بالمركز، وحوله مجلداته الفرعية وتطبيقاته مربوطة بخيوط بيضاء
            val appsList = f.apps.mapNotNull { AppRepository.byKey[it] }
            apps = appsList
            val entries = ArrayList<Pair<String, () -> Unit>>()
            val nodes = ArrayList<View>()
            for (k in kids) { nodes.add(kidNode(k)); entries.add(Pair(k.name) { go(k.id) }) }
            for (a in appsList) { nodes.add(appNode(a, f.id)); entries.add(Pair(StateStore.names[a.key] ?: a.label) { c.launchApp(a.key, null) }) }
            if (nodes.isEmpty()) {
                val e = Ui.text(ctx, "المجلد فارغ — اضغط زر الإضافة أعلاه", 13f, Theme.sub(ctx))
                e.gravity = Gravity.CENTER
                e.setPadding(0, Ui.dp(ctx, 20), 0, Ui.dp(ctx, 12))
                card.addView(centerNode(f), LinearLayout.LayoutParams(-1, -2))
                card.addView(e, LinearLayout.LayoutParams(-1, -2))
            } else {
                val lines = LinesView(ctx)
                val orbit = OrbitLayout(ctx, lines)
                orbit.addView(lines, LayoutParams(-1, -1))
                orbit.addView(centerNode(f), LayoutParams(-2, -2))
                val limit = 16
                val shown = if (nodes.size > limit) nodes.take(limit - 1) else nodes
                for (v in shown) orbit.addView(v, LayoutParams(Ui.dp(ctx, 76), -2))
                if (nodes.size > limit) orbit.addView(moreNode(entries.drop(limit - 1)), LayoutParams(Ui.dp(ctx, 76), -2))
                card.addView(orbit, LinearLayout.LayoutParams(-1, Ui.dp(ctx, if (nodes.size > 6) 440 else 270)))
            }
        } else {
        // التطبيقات: أيقونات حقيقية بأسمائها
        apps = f.apps.mapNotNull { AppRepository.byKey[it] }
        if (apps.isEmpty()) {
            val e = Ui.text(ctx, "المجلد فارغ — اضغط زر الإضافة أعلاه لإضافة تطبيقات", 13f, Theme.sub(ctx))
            e.gravity = Gravity.CENTER
            e.setPadding(0, Ui.dp(ctx, 20), 0, Ui.dp(ctx, 12))
            card.addView(e, LinearLayout.LayoutParams(-1, -2))
        } else {
            val list = f.view == "list"
            val g = GridView(ctx)
            g.numColumns = if (list) 1 else Prefs.folderCols.coerceIn(3, 5)
            g.adapter = adapter
            g.selector = android.graphics.drawable.ColorDrawable(0)
            g.overScrollMode = View.OVER_SCROLL_NEVER
            g.setOnItemClickListener { _, v, p, _ -> c.launchApp(apps[p].key, v) }
            g.setOnItemLongClickListener { _, _, p, _ -> c.showAppMenu(apps[p], false, null, f.id); true }
            val rowH = Ui.dp(ctx, if (list) 56 else Prefs.iconSize.coerceAtMost(64) + 36)
            val rows = ceil(apps.size / g.numColumns.toFloat()).toInt()
            card.addView(g, LinearLayout.LayoutParams(-1, min(rows * rowH, Ui.dp(ctx, 300))).apply { topMargin = Ui.dp(ctx, 10) })
        }
        adapter.notifyDataSetChanged()

        }

        if (animate) {
            card.alpha = 0f
            card.translationX = Ui.dp(ctx, 24).toFloat() * (if (layoutDirection == View.LAYOUT_DIRECTION_RTL) -1 else 1)
            card.animate().alpha(1f).translationX(0f).setDuration(if (Prefs.reduceMotion) 0L else 220L).start()
        }
    }

    /** المجلد الرئيسي بالمركز: أيقونة مجلد مثل الفرعي، والضغط عليها يفتح خيارات التخصيص (اسم، أيقونة، لون) */
    private fun centerNode(f: com.sparrow.launcher.persistence.Folder): View {
        val ctx = context
        val n = LinearLayout(ctx)
        n.orientation = LinearLayout.VERTICAL
        n.gravity = Gravity.CENTER
        val sz = Ui.dp(ctx, 72)
        val ic: View = if (f.iconPath.isNotEmpty() || f.emoji.isNotEmpty()) FolderIconView(ctx, f, sz) else {
            val iv = android.widget.ImageView(ctx)
            iv.setImageDrawable(com.sparrow.launcher.core.VIcon("folder", Theme.text(ctx)))
            val p = Ui.dp(ctx, 18)
            iv.setPadding(p, p, p, p)
            iv.background = Theme.panel(ctx, sz / 2f)
            iv
        }
        n.addView(ic, LinearLayout.LayoutParams(sz, sz))
        val l = Ui.text(ctx, "${f.apps.size} تطبيق", 11f, Theme.sub(ctx))
        l.gravity = Gravity.CENTER
        l.setPadding(0, Ui.dp(ctx, 4), 0, 0)
        n.addView(l)
        n.setOnClickListener { c.showFolderMenu(f.id) }
        return n
    }

    private fun appNode(a: AppInfo, folderId: String): View {
        val v = AppCellView(context)
        v.bind(a, 44, true, Theme.text(context), false)
        v.setOnClickListener { c.launchApp(a.key, v) }
        v.setOnLongClickListener { c.showAppMenu(a, false, null, folderId); true }
        return v
    }

    /** مجلد فرعي: أيقونة المجلد الاعتيادية (إلا إذا خصّص المستخدم أيقونته) + اسمه */
    private fun kidNode(k: com.sparrow.launcher.persistence.Folder): View {
        val ctx = context
        val n = LinearLayout(ctx)
        n.orientation = LinearLayout.VERTICAL
        n.gravity = Gravity.CENTER
        val sz = Ui.dp(ctx, 58)
        val ic: View = if (k.iconPath.isNotEmpty() || k.emoji.isNotEmpty()) FolderIconView(ctx, k, sz) else {
            val iv = android.widget.ImageView(ctx)
            iv.setImageDrawable(com.sparrow.launcher.core.VIcon("folder", Theme.text(ctx)))
            val p = Ui.dp(ctx, 15)
            iv.setPadding(p, p, p, p)
            iv.background = Theme.panel(ctx, sz / 2f)
            iv
        }
        n.addView(ic, LinearLayout.LayoutParams(sz, sz))
        val t = Ui.text(ctx, k.name, 11f, Theme.text(ctx))
        t.maxLines = 1
        t.gravity = Gravity.CENTER
        t.maxWidth = Ui.dp(ctx, 80)
        t.setPadding(0, Ui.dp(ctx, 4), 0, 0)
        n.addView(t)
        n.setOnClickListener { go(k.id) }
        n.setOnLongClickListener { c.showFolderMenu(k.id); true }
        return n
    }

    private fun moreNode(rest: List<Pair<String, () -> Unit>>): View {
        val ctx = context
        val sz = Ui.dp(ctx, 58)
        val t = Ui.text(ctx, "+" + rest.size, 16f, Theme.text(ctx), true)
        t.gravity = Gravity.CENTER
        t.background = Theme.panel(ctx, sz / 2f)
        t.layoutParams = LinearLayout.LayoutParams(sz, sz)
        val n = LinearLayout(ctx)
        n.gravity = Gravity.CENTER
        n.addView(t)
        n.setOnClickListener { Ui.list(ctx, "المزيد", rest.map { it.first }) { i -> rest[i].second() } }
        return n
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount(): Int = apps.size
        override fun getItem(position: Int): Any = apps[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val list = cur()?.view == "list"
            val h = Ui.dp(context, if (list) 56 else Prefs.iconSize.coerceAtMost(64) + 36)
            val v = (convertView as? AppCellView) ?: AppCellView(context).apply {
                layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            }
            v.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            v.bind(apps[position], if (list) 40 else Prefs.iconSize.coerceAtMost(64), true, Theme.text(context), false, list)
            return v
        }
    }

    override fun animateOut(end: () -> Unit) {
        val d = if (Prefs.reduceMotion || !Prefs.folderAnim) 0L else 200L
        card.animate().scaleX(0.6f).scaleY(0.6f).setDuration(d).start()
        animate().alpha(0f).setDuration(d).withEndAction { end() }.start()
    }

    override fun handleBack(): Boolean {
        if (stack.size > 1) { back(); return true }
        return false
    }
}


/** الخيوط البيضاء: ترتسم تدريجياً من المجلد الرئيسي إلى كل عنصر حوله */
private class LinesView(ctx: Context) : View(ctx) {
    private val segs = ArrayList<FloatArray>()
    private var progress = 0f
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)

    init {
        paint.color = 0xCCFFFFFF.toInt()
        paint.strokeWidth = Ui.dpf(ctx, 1.4f)
        paint.strokeCap = android.graphics.Paint.Cap.ROUND
        val a = android.animation.ValueAnimator.ofFloat(0f, 1f)
        a.duration = 560
        a.startDelay = 100
        a.addUpdateListener { progress = it.animatedValue as Float; invalidate() }
        a.start()
    }

    fun set(s: List<FloatArray>) {
        segs.clear(); segs.addAll(s)
        invalidate()
    }

    override fun onDraw(c: android.graphics.Canvas) {
        for (s in segs) c.drawLine(s[0], s[1], s[0] + (s[2] - s[0]) * progress, s[1] + (s[3] - s[1]) * progress, paint)
    }
}

/** حلقتان حول المركز: الداخلية (حتى 6 عناصر) متصلة بالمركز، والخارجية متصلة بأقرب عنصر داخلي */
private class OrbitLayout(ctx: Context, private val lines: LinesView) : FrameLayout(ctx) {
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val cx = w / 2f
        val cy = h / 2f
        lines.layout(0, 0, w, h)
        val ctr = getChildAt(1)
        ctr.layout((cx - ctr.measuredWidth / 2f).toInt(), (cy - ctr.measuredHeight / 2f).toInt(), (cx + ctr.measuredWidth / 2f).toInt(), (cy + ctr.measuredHeight / 2f).toInt())
        val n = childCount - 2
        val ring1 = Math.min(n, 6)
        val ring2 = n - ring1
        val rx = w / 2f - Ui.dpf(context, 46f)
        val ry = h / 2f - Ui.dpf(context, 46f)
        val r1 = if (ring2 > 0) Math.min(rx, ry) * 0.5f else Math.min(rx, ry)
        val segs = ArrayList<FloatArray>()
        val inner = ArrayList<FloatArray>()
        for (i in 0 until n) {
            val ch = getChildAt(2 + i)
            val x: Float
            val y: Float
            if (i < ring1) {
                val a = Math.toRadians(-90.0 + i * 360.0 / ring1)
                x = cx + r1 * Math.cos(a).toFloat()
                y = cy + r1 * Math.sin(a).toFloat()
                inner.add(floatArrayOf(x, y))
                segs.add(floatArrayOf(cx, cy, x, y))
            } else {
                val j = i - ring1
                val a = Math.toRadians(-90.0 + (j + 0.5) * 360.0 / ring2)
                x = cx + rx * Math.cos(a).toFloat()
                y = cy + ry * Math.sin(a).toFloat()
                var best = inner[0]
                var bd = Float.MAX_VALUE
                for (p in inner) {
                    val d = (p[0] - x) * (p[0] - x) + (p[1] - y) * (p[1] - y)
                    if (d < bd) { bd = d; best = p }
                }
                segs.add(floatArrayOf(best[0], best[1], x, y))
            }
            ch.layout((x - ch.measuredWidth / 2f).toInt(), (y - ch.measuredHeight / 2f).toInt(), (x + ch.measuredWidth / 2f).toInt(), (y + ch.measuredHeight / 2f).toInt())
        }
        lines.set(segs)
    }
}
