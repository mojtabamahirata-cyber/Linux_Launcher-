package com.sparrow.launcher.widgets

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import com.sparrow.launcher.core.Bg
import com.sparrow.launcher.core.LauncherController
import com.sparrow.launcher.core.Overlay
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.core.afterLayout
import com.sparrow.launcher.workspace.CarouselView
import kotlin.math.ceil
import kotlin.math.max

/**
 * منتقي ويدجت خاص بـ Sparrow (بأسلوب لانشرات الهواتف): كل تطبيق له بطاقات بمعاينة حقيقية
 * من الويدجت نفسها، وكل بطاقة تعرض حجمها بالخلايا (مثل 4×2) فتُضاف مباشرة بذلك الحجم.
 * الويدجت المعروضة هي ويدجت التطبيقات الحقيقية عبر AppWidgetManager.
 */
class WidgetPickerView(
    ctx: Context,
    private val c: LauncherController,
    topInset: Int,
    bottomInset: Int,
    private val cols: Int,
    private val rows: Int,
    private val cellW: Int,
    private val cellH: Int,
    private val onPick: (String, AppWidgetProviderInfo?, Int, Int) -> Unit
) : FrameLayout(ctx), Overlay {

    override val depth: Float get() = 1f
    private val previews = ArrayList<Pair<ImageView, AppWidgetProviderInfo>>()

    init {
        layoutDirection = Ui.layoutDir()
        setBackgroundColor(Theme.surface(ctx))
        isClickable = true
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(ctx, 14), topInset + Ui.dp(ctx, 16), Ui.dp(ctx, 14), bottomInset + Ui.dp(ctx, 10))
        val head = LinearLayout(ctx)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(Ui.text(ctx, "إضافة Widget", 22f, Theme.text(ctx), true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(com.sparrow.launcher.core.Icons.button(ctx, "close", Theme.text(ctx), true) { c.closeOverlay(this) })
        col.addView(head)

        val list = LinearLayout(ctx)
        list.orientation = LinearLayout.VERTICAL

        // Sparrow نفسه: مشغل الموسيقى
        group(list, "ويدجت Sparrow", listOf(
            Card("music", "music", "مشغل الموسيقى", null, minOf(4, cols), 2, false),
            Card("clock", "clock", "الساعة والتاريخ", null, minOf(4, cols), 2, false),
            Card("date", "date", "التاريخ", null, minOf(4, cols), 1, false),
            Card("battery", "battery", "البطارية", null, minOf(2, cols), 2, false),
            Card("search", "search", "بحث سريع", null, minOf(4, cols), 1, false)
        ))

        val pm = ctx.packageManager
        val byPkg = LinkedHashMap<String, ArrayList<AppWidgetProviderInfo>>()
        for (p in AppWidgetManager.getInstance(ctx).installedProviders) {
            byPkg.getOrPut(p.provider.packageName) { ArrayList() }.add(p)
        }
        val groups = byPkg.entries.map { e ->
            val label = try { pm.getApplicationInfo(e.key, 0).loadLabel(pm).toString() } catch (x: Exception) { e.key }
            Pair(label, e.value)
        }.sortedBy { it.first.lowercase() }
        for ((label, infos) in groups) {
            val cards = infos.map { i ->
                val sx = ceil(i.minWidth.toFloat() / max(1, cellW)).toInt().coerceIn(1, cols)
                val sy = ceil(i.minHeight.toFloat() / max(1, cellH)).toInt().coerceIn(1, rows)
                val name = try { i.loadLabel(pm) } catch (x: Exception) { label }
                Card("", "", name, i, sx, sy, (i.resizeMode and AppWidgetProviderInfo.RESIZE_HORIZONTAL) != 0)
            }
            group(list, label, cards)
        }
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        col.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = Ui.dp(ctx, 8) })
        addView(col, LayoutParams(-1, -1))

        // المعاينات تُحمَّل في خيط خلفي حتى لا يتأخر فتح المنتقي
        Bg.io.execute {
            for ((iv, info) in previews) {
                val d: Drawable? = try { info.loadPreviewImage(ctx, 0) ?: info.loadIcon(ctx, 0) } catch (x: Throwable) { null }
                Bg.main.post { if (d != null) iv.setImageDrawable(d) }
            }
        }
        alpha = 0f
        afterLayout { animate().alpha(1f).setDuration(if (Prefs.reduceMotion) 0L else 220L).start() }
    }

    private class Card(val emoji: String, val kind: String, val name: CharSequence, val info: AppWidgetProviderInfo?, val sx: Int, val sy: Int, val hResize: Boolean)

    private fun group(parent: LinearLayout, title: String, cards: List<Card>) {
        val ctx = context
        val t = Ui.text(ctx, title, 15f, Theme.ACCENT, true)
        t.setPadding(Ui.dp(ctx, 4), Ui.dp(ctx, 18), 0, Ui.dp(ctx, 6))
        parent.addView(t)
        // بطاقات الويدجت بتنقل ثلاثي الأبعاد (Perspective + Depth) عند التمرير بين الأحجام والأنواع
        val car = CarouselView(ctx)
        val ch = Ui.dp(ctx, 205)
        car.setCards(cards.map { cardView(it) }, Ui.dp(ctx, 190), ch, 0)
        parent.addView(car, LinearLayout.LayoutParams(-1, ch + Ui.dp(ctx, 12)))
    }

    private fun cardView(cd: Card): View {
        val ctx = context
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10), Ui.dp(ctx, 10))
        box.background = Theme.panel(ctx, Ui.dpf(ctx, 22f))
        val w = Ui.dp(ctx, 160)
        val pv: View
        if (cd.info == null) {
            val e = ImageView(ctx)
            e.setImageDrawable(com.sparrow.launcher.core.VIcon(cd.emoji, Theme.text(ctx)))
            e.setPadding(Ui.dp(ctx, 26), Ui.dp(ctx, 14), Ui.dp(ctx, 26), Ui.dp(ctx, 14))
            pv = e
        } else {
            val iv = ImageView(ctx)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            previews.add(Pair(iv, cd.info))
            pv = iv
        }
        box.addView(pv, LinearLayout.LayoutParams(w, Ui.dp(ctx, 96)))
        val n = Ui.text(ctx, cd.name, 12f, Theme.text(ctx))
        n.maxLines = 1
        n.gravity = Gravity.CENTER
        box.addView(n, LinearLayout.LayoutParams(w, -2))
        // أحجام جاهزة: الافتراضي، وعرض كامل إن كانت الويدجت تقبل التمديد
        val sizes = LinearLayout(ctx)
        sizes.gravity = Gravity.CENTER
        fun chip(sx: Int, sy: Int) {
            val ch = Ui.text(ctx, "$sx×$sy", 12f, 0xFF0B1020.toInt(), true)
            ch.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 4), Ui.dp(ctx, 10), Ui.dp(ctx, 4))
            ch.background = Ui.round(Theme.ACCENT, Ui.dpf(ctx, 12f))
            ch.setOnClickListener { c.closeOverlay(this); onPick(cd.kind, cd.info, sx, sy) }
            sizes.addView(ch, LinearLayout.LayoutParams(-2, -2).apply { setMargins(4, 6, 4, 0) })
        }
        chip(cd.sx, cd.sy)
        if (cd.hResize && cd.sx < cols) chip(cols, cd.sy)
        box.addView(sizes)
        box.setOnClickListener { c.closeOverlay(this); onPick(cd.kind, cd.info, cd.sx, cd.sy) }
        box.layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4), 0) }
        return box
    }

    override fun animateOut(end: () -> Unit) {
        animate().alpha(0f).setDuration(if (Prefs.reduceMotion) 0L else 160L).withEndAction { end() }.start()
    }

    override fun handleBack(): Boolean = false
}
