package com.sparrow.launcher.recent

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import com.sparrow.launcher.apps.AppInfo
import com.sparrow.launcher.apps.AppRepository
import com.sparrow.launcher.apps.ShapedIcon
import com.sparrow.launcher.core.LauncherController
import com.sparrow.launcher.core.Overlay
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.core.pillIcon
import com.sparrow.launcher.core.afterLayout
import com.sparrow.launcher.persistence.StateStore
import com.sparrow.launcher.workspace.CarouselView

/**
 * التطبيقات الأخيرة: بطاقات 3D. السحب للأعلى يزيل البطاقة، والضغط يفتح التطبيق.
 * ملاحظة: أندرويد لا يسمح للانشر بقراءة قائمة Recents الخاصة بالنظام، لذلك هذه قائمة
 * التطبيقات التي فتحتها عبر Sparrow نفسه (محفوظة وتبقى بعد إعادة التشغيل).
 */
class RecentsView(
    ctx: Context,
    private val c: LauncherController,
    private val topInset: Int,
    private val bottomInset: Int
) : FrameLayout(ctx), Overlay {

    override val depth: Float get() = 1f
    private val carousel = CarouselView(ctx)
    private val empty = Ui.text(ctx, "لا توجد تطبيقات حديثة بعد", 16f, Color.WHITE, true)
    private var apps = ArrayList<AppInfo>()

    init {
        setBackgroundColor(0x99000000.toInt())
        isClickable = true
        layoutDirection = Ui.layoutDir()
        carousel.dismissable = true
        carousel.setOnClickListener { c.closeOverlay(this) }
        carousel.onDismiss = { i ->
            if (i in apps.indices) {
                StateStore.recents.remove(apps[i].key)
                StateStore.save()
                build(i.coerceAtMost(apps.size - 2))
            }
        }
        addView(carousel, LayoutParams(-1, -1).apply { topMargin = topInset + Ui.dp(ctx, 30); bottomMargin = bottomInset + Ui.dp(ctx, 90) })
        empty.gravity = Gravity.CENTER
        addView(empty, LayoutParams(-1, -2, Gravity.CENTER))
        addView(com.sparrow.launcher.core.Ui.pillIcon(ctx, "trash", "مسح الكل") {
            StateStore.recents.clear(); StateStore.save(); build(0)
        }, LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = bottomInset + Ui.dp(ctx, 28) })
        build(0)
        alpha = 0f
        afterLayout {
            animate().alpha(1f).setDuration(if (Prefs.reduceMotion) 0L else 240L).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun build(start: Int) {
        apps = ArrayList()
        val keys = ArrayList<String>()
        if (UsageRecents.granted(context)) {
            for (pkg in UsageRecents.recentPackages(context, 25)) {
                if (pkg == context.packageName) continue
                val a = AppRepository.apps.firstOrNull { it.pkg == pkg }
                if (a != null && a.key !in keys) keys.add(a.key)
            }
        }
        for (k in StateStore.recents) if (k !in keys) keys.add(k)
        for (k in keys) {
            val a = AppRepository.byKey[k] ?: continue
            if (k !in StateStore.hidden) apps.add(a)
        }
        empty.visibility = if (apps.isEmpty()) View.VISIBLE else View.GONE
        val dm = resources.displayMetrics
        val cw = (dm.widthPixels * 0.62f).toInt()
        val ch = (cw * 1.45f).toInt().coerceAtMost((dm.heightPixels * 0.6f).toInt())
        val list = ArrayList<View>()
        for (a in apps) {
            val card = LinearLayout(context)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER
            card.setBackgroundColor(Theme.card(context))
            val iv = ImageView(context)
            val b = AppRepository.icon(a.key)
            if (b != null) iv.setImageDrawable(ShapedIcon(b, Prefs.iconShape))
            val sz = (cw * 0.42f).toInt()
            card.addView(iv, LinearLayout.LayoutParams(sz, sz))
            val name = Ui.text(context, StateStore.names[a.key] ?: a.label, 16f, Theme.text(context), true)
            name.gravity = Gravity.CENTER
            name.setPadding(Ui.dp(context, 8), Ui.dp(context, 14), Ui.dp(context, 8), 0)
            card.addView(name, LinearLayout.LayoutParams(-1, -2))
            val ago = Ui.text(context, ago(StateStore.lastLaunch[a.key] ?: 0L), 12f, Theme.sub(context))
            ago.gravity = Gravity.CENTER
            card.addView(ago, LinearLayout.LayoutParams(-1, -2))
            card.setOnClickListener { c.launchApp(a.key, card) }
            list.add(card)
        }
        carousel.setCards(list, cw, ch, start.coerceAtLeast(0))
    }

    private fun ago(t: Long): String {
        if (t == 0L) return ""
        val m = (System.currentTimeMillis() - t) / 60000
        return when {
            m < 1 -> "الآن"
            m < 60 -> "قبل $m دقيقة"
            m < 1440 -> "قبل ${m / 60} ساعة"
            else -> "قبل ${m / 1440} يوم"
        }
    }

    override fun animateOut(end: () -> Unit) {
        animate().alpha(0f).setDuration(if (Prefs.reduceMotion) 0L else 180L).withEndAction { end() }.start()
    }

    override fun handleBack(): Boolean = false
}
