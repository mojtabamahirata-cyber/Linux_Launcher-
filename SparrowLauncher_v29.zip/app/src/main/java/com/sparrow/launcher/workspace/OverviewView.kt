package com.sparrow.launcher.workspace

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import com.sparrow.launcher.core.Icons
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.pillIcon
import com.sparrow.launcher.core.Overlay
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.core.afterLayout
import com.sparrow.launcher.persistence.StateStore
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * قائمة بطاقات ثلاثية الأبعاد تُمرَّر أفقياً (Perspective + Depth + Scale + Shadow).
 * تُستعمل في Overview وفي Recents. السحب للأعلى على بطاقة = إزالتها (إذا dismissable).
 */
open class CarouselView(ctx: Context) : FrameLayout(ctx) {
    val cards = ArrayList<View>()
    var position = 0f
        private set
    var cardW = 0
    var cardH = 0
    var dismissable = false
    var onSettle: ((Int) -> Unit)? = null
    var onDismiss: ((Int) -> Unit)? = null

    private var anim: ValueAnimator? = null
    private var vt: VelocityTracker? = null
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var mode = 0 // 0 لا شيء، 1 أفقي، 2 عمودي (إزالة)
    private var dragCard: View? = null
    private var dragIndex = -1
    private val step = 0.64f

    val current: Int get() = position.roundToInt().coerceIn(0, max(0, cards.size - 1))
    private val dirSign: Float get() = if (layoutDirection == LAYOUT_DIRECTION_RTL) -1f else 1f

    fun setCards(list: List<View>, w: Int, h: Int, start: Int) {
        anim?.cancel()
        removeAllViews()
        cards.clear()
        cards.addAll(list)
        cardW = w
        cardH = h
        for (c in cards) {
            addView(c, LayoutParams(w, h, Gravity.CENTER))
            c.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, Ui.dpf(context, 18f))
                }
            }
            c.clipToOutline = true
        }
        position = start.coerceIn(0, max(0, cards.size - 1)).toFloat()
        apply()
    }

    private fun apply() {
        val dir = dirSign
        for (i in cards.indices) {
            val v = cards[i]
            val off = i - position
            val a = abs(off)
            v.translationX = dir * off * cardW * step
            val s = 1f - 0.15f * min(a, 1.5f)
            v.scaleX = s
            v.scaleY = s
            v.rotationY = -dir * off.coerceIn(-1.5f, 1.5f) * 32f
            v.alpha = (1f - 0.4f * a).coerceIn(0.15f, 1f)
            v.translationZ = (2f - min(a, 2f)) * Ui.dpf(context, 6f)
            v.cameraDistance = cardW * 9f
        }
    }

    fun scrollTo(i: Int, animate: Boolean) {
        val t = i.coerceIn(0, max(0, cards.size - 1)).toFloat()
        anim?.cancel()
        if (!animate) {
            position = t; apply(); onSettle?.invoke(t.toInt()); return
        }
        val a = ValueAnimator.ofFloat(position, t)
        a.duration = if (Prefs.reduceMotion) 100L else 280L
        a.interpolator = DecelerateInterpolator(1.5f)
        a.addUpdateListener { position = it.animatedValue as Float; apply() }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: android.animation.Animator) {
                if (position == t) onSettle?.invoke(t.toInt())
            }
        })
        anim = a
        a.start()
    }

    private fun cardAt(x: Float, y: Float): Int {
        var best = -1
        var bestOff = 99f
        for (i in cards.indices) {
            val v = cards[i]
            val cx = v.left + v.translationX + v.width / 2f
            val cy = v.top + v.translationY + v.height / 2f
            val hw = v.width * v.scaleX / 2f
            val hh = v.height * v.scaleY / 2f
            if (x >= cx - hw && x <= cx + hw && y >= cy - hh && y <= cy + hh) {
                val o = abs(i - position)
                if (o < bestOff) { bestOff = o; best = i }
            }
        }
        return best
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            vt?.recycle(); vt = VelocityTracker.obtain()
            downX = e.x; downY = e.y; lastX = e.x; mode = 0
            dragIndex = cardAt(e.x, e.y)
            dragCard = if (dragIndex >= 0) cards[dragIndex] else null
            if (anim?.isRunning == true) { anim?.cancel(); mode = 1 }
        }
        vt?.addMovement(e)
        if (e.actionMasked == MotionEvent.ACTION_MOVE && mode == 0 && e.pointerCount == 1) {
            val dx = e.x - downX
            val dy = e.y - downY
            if (abs(dx) > slop && abs(dx) > abs(dy)) mode = 1
            else if (dismissable && dragCard != null && dy < -slop * 1.5f && abs(dy) > abs(dx)) mode = 2
        }
        return mode != 0
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        vt?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; lastX = e.x }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 0) {
                    val dx = e.x - downX
                    val dy = e.y - downY
                    if (abs(dx) > slop && abs(dx) > abs(dy)) mode = 1
                }
                if (mode == 1) {
                    val dx = e.x - lastX
                    lastX = e.x
                    position = (position - dirSign * dx / (cardW * step)).coerceIn(-0.3f, cards.size - 0.7f)
                    apply()
                } else if (mode == 2) {
                    val dy = min(0f, e.y - downY)
                    dragCard?.translationY = dy
                    dragCard?.alpha = (1f + dy / (cardH * 0.9f)).coerceIn(0.2f, 1f)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f
                val vy = vt?.yVelocity ?: 0f
                vt?.recycle(); vt = null
                if (mode == 1) {
                    val v = -dirSign * vx
                    val t = when {
                        v > 900f -> floor(position).toInt() + 1
                        v < -900f -> ceil(position).toInt() - 1
                        else -> position.roundToInt()
                    }
                    scrollTo(t, true)
                } else if (mode == 2) {
                    val card = dragCard
                    val idx = dragIndex
                    val dy = (card?.translationY ?: 0f)
                    if (card != null && (dy < -cardH * 0.25f || vy < -1500f)) {
                        card.animate().translationY(-height.toFloat()).alpha(0f).setDuration(200).withEndAction {
                            onDismiss?.invoke(idx)
                        }.start()
                    } else if (card != null) {
                        card.animate().translationY(0f).alpha(1f).setDuration(180).start()
                    }
                } else if (e.actionMasked == MotionEvent.ACTION_UP && abs(e.x - downX) < slop && abs(e.y - downY) < slop) {
                    performClick()
                }
                mode = 0
                dragCard = null
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}

/**
 * Workspace Overview: كل الـ Workspaces معاً كبطاقات 3D حقيقية (لقطات حية من الصفحات).
 * أزرار: إضافة، رئيسية، تسمية، لون، تحريك، حذف.
 */
class OverviewView(
    ctx: Context,
    snaps: List<Bitmap>,
    start: Int,
    topInset: Int,
    bottomInset: Int,
    private val onOpen: (Int) -> Unit,
    private val onAdd: () -> Unit,
    private val onDelete: (Int) -> Unit,
    private val onHome: (Int) -> Unit,
    private val onRename: (Int) -> Unit,
    private val onTint: (Int) -> Unit,
    private val onMove: (Int, Int) -> Unit,
    private val onClose: () -> Unit
) : FrameLayout(ctx), Overlay {

    override val depth: Float get() = 1f
    private val carousel = CarouselView(ctx)
    private val title = Ui.text(ctx, "", 16f, Color.WHITE, true)

    init {
        setBackgroundColor(0x88000000.toInt())
        isClickable = true
        layoutDirection = Ui.layoutDir()

        val dm = resources.displayMetrics
        val cw = (dm.widthPixels * 0.58f).toInt()
        val ratio = if (snaps.isNotEmpty()) snaps[0].height.toFloat() / snaps[0].width else 2f
        val ch = min((cw * ratio).toInt(), (dm.heightPixels * 0.62f).toInt())
        val views = ArrayList<View>()
        for ((i, b) in snaps.withIndex()) {
            val card = FrameLayout(ctx)
            card.setBackgroundColor(0x44FFFFFF)
            val iv = ImageView(ctx)
            iv.setImageBitmap(b)
            iv.scaleType = ImageView.ScaleType.FIT_XY
            card.addView(iv, LayoutParams(-1, -1))
            val n = StateStore.workspaces.getOrNull(i)
            val tag = Ui.text(ctx, (if (i == StateStore.homeIndex) "● " else "") + (n?.name ?: ""), 12f, Color.WHITE, true)
            tag.background = Ui.round(0x99000000.toInt(), Ui.dpf(ctx, 12f))
            tag.setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 4), Ui.dp(ctx, 10), Ui.dp(ctx, 4))
            card.addView(tag, LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(Ui.dp(ctx, 8), Ui.dp(ctx, 8), 0, 0) })
            card.setOnClickListener { onOpen(i) }
            views.add(card)
        }
        carousel.setCards(views, cw, ch, start)
        carousel.setOnClickListener { onClose() }
        carousel.onSettle = { updateTitle() }
        addView(carousel, LayoutParams(-1, -1).apply { topMargin = topInset + Ui.dp(ctx, 40); bottomMargin = bottomInset + Ui.dp(ctx, 96) })

        title.gravity = Gravity.CENTER
        addView(title, LayoutParams(-1, -2, Gravity.TOP).apply { topMargin = topInset + Ui.dp(ctx, 14) })

        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(Ui.dp(ctx, 10), 0, Ui.dp(ctx, 10), 0)
        fun btn(kind: String, label: String, f: () -> Unit) {
            val p = if (label.isEmpty()) Icons.button(ctx, kind, Theme.text(ctx), true, f) else Ui.pillIcon(ctx, kind, label, f)
            bar.addView(p, LinearLayout.LayoutParams(-2, -2).apply { setMargins(Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4), 0) })
        }
        btn("workspace", "مساحة") { onAdd() }
        btn("home", "رئيسية") { onHome(carousel.current) }
        btn("edit", "اسم") { onRename(carousel.current) }
        btn("palette", "لون") { onTint(carousel.current) }
        btn("back", "") { onMove(carousel.current, carousel.current - 1) }
        btn("fwd", "") { onMove(carousel.current, carousel.current + 1) }
        btn("trash", "حذف") { onDelete(carousel.current) }
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(bar)
        addView(hs, LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = bottomInset + Ui.dp(ctx, 24) })
        updateTitle()

        // دخول: البطاقات تقترب من الكاميرا
        alpha = 0f
        carousel.scaleX = 0.85f
        carousel.scaleY = 0.85f
        afterLayout {
            val d = if (Prefs.reduceMotion) 0L else 280L
            animate().alpha(1f).setDuration(d).start()
            carousel.animate().scaleX(1f).scaleY(1f).setDuration(d).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun updateTitle() {
        val n = StateStore.workspaces.getOrNull(carousel.current)
        title.text = "مساحات العمل  •  " + (n?.name ?: "")
    }

    override fun animateOut(end: () -> Unit) {
        animate().alpha(0f).setDuration(if (Prefs.reduceMotion) 0L else 200L).withEndAction { end() }.start()
    }

    override fun handleBack(): Boolean = false
}
