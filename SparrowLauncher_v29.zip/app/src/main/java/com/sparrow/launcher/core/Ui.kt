package com.sparrow.launcher.core

import android.app.AlertDialog
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewTreeObserver
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** خيوط العمل: io لتحميل التطبيقات والحفظ، search للبحث (حتى لا يتجمد الـ UI أبداً) */
object Bg {
    val io: ExecutorService = Executors.newSingleThreadExecutor()
    val search: ExecutorService = Executors.newSingleThreadExecutor()
    val main = Handler(Looper.getMainLooper())
}

/** خيار في قائمة: اسم + ما ينفَّذ عند الاختيار */
class Opt(val label: String, val run: () -> Unit)

/** أدوات مساعدة للواجهة (كلها برمجية بدون XML) */
object Ui {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()
    fun dpf(ctx: Context, v: Float): Float = v * ctx.resources.displayMetrics.density

    /** اتجاه الواجهة حسب إعداد المستخدم (RTL افتراضياً للعربية) */
    fun layoutDir(): Int = when (Prefs.direction) {
        "ltr" -> View.LAYOUT_DIRECTION_LTR
        "auto" -> View.LAYOUT_DIRECTION_LOCALE
        else -> View.LAYOUT_DIRECTION_RTL
    }

    fun text(ctx: Context, s: CharSequence, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        t.typeface = if (bold) Typeface.create(Prefs.typeface(), Typeface.BOLD) else Prefs.typeface()
        return t
    }

    fun round(color: Int, radius: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radius
        return g
    }

    /** زر بشكل حبة (Pill) */
    fun pill(ctx: Context, label: String, onClick: () -> Unit): TextView {
        val t = text(ctx, label, 14f, Theme.text(ctx), true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(ctx, 14), dp(ctx, 9), dp(ctx, 14), dp(ctx, 9))
        t.background = Theme.panel(ctx, dp(ctx, 20).toFloat())
        t.setOnClickListener { onClick() }
        return t
    }

    fun toast(ctx: Context, msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    fun builder(ctx: Context): AlertDialog.Builder = AlertDialog.Builder(
        ctx,
        if (Theme.dark(ctx)) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
    )

    private fun fixDir(d: AlertDialog) {
        d.window?.decorView?.layoutDirection = layoutDir()
    }

    fun list(ctx: Context, title: String?, items: List<String>, onPick: (Int) -> Unit) {
        val b = builder(ctx)
        if (title != null) b.setTitle(title)
        b.setItems(items.toTypedArray()) { _, i -> onPick(i) }
        fixDir(b.show())
    }

    fun options(ctx: Context, title: String?, opts: List<Opt>) {
        Sheet.show(ctx, title, opts)
    }

    fun input(ctx: Context, title: String, initial: String, onOk: (String) -> Unit) {
        val e = EditText(ctx)
        e.setText(initial)
        e.setSelectAllOnFocus(true)
        e.inputType = InputType.TYPE_CLASS_TEXT
        val box = FrameLayout(ctx)
        box.setPadding(dp(ctx, 20), dp(ctx, 8), dp(ctx, 20), 0)
        box.addView(e, FrameLayout.LayoutParams(-1, -2))
        val b = builder(ctx)
        b.setTitle(title)
        b.setView(box)
        b.setPositiveButton("حسناً") { _, _ -> onOk(e.text.toString()) }
        b.setNegativeButton("إلغاء", null)
        fixDir(b.show())
    }

    fun confirm(ctx: Context, msg: String, onYes: () -> Unit) {
        val b = builder(ctx)
        b.setMessage(msg)
        b.setPositiveButton("نعم") { _, _ -> onYes() }
        b.setNegativeButton("إلغاء", null)
        fixDir(b.show())
    }
}

/** ينفّذ الكود بعد أن يُقاس الـ View ويُرسم مرة واحدة على الأقل */
fun View.afterLayout(block: () -> Unit) {
    if (isLaidOut && !isLayoutRequested) {
        block()
        return
    }
    viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
        override fun onGlobalLayout() {
            viewTreeObserver.removeOnGlobalLayoutListener(this)
            block()
        }
    })
}

/** زر بأيقونة متجهة + نص (بدل الإيموجي) */
fun Ui.pillIcon(ctx: Context, kind: String, label: String, onClick: () -> Unit): TextView {
    val t = pill(ctx, label, onClick)
    Icons.withText(ctx, t, kind, 16, Theme.text(ctx))
    return t
}
