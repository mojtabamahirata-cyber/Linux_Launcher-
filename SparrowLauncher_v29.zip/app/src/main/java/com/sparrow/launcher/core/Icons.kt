package com.sparrow.launcher.core

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * أيقونات متجهة (Vector) مرسومة بالكود على شبكة 24×24 بخطوط ناعمة.
 * تستبدل الإيموجي: حادة بأي حجم وتتلوّن حسب الثيم.
 */
class VIcon(private val kind: String, private var color: Int = Color.WHITE) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    fun tint(c: Int): VIcon { color = c; invalidateSelf(); return this }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) = c.drawLine(x1, y1, x2, y2, p)

    private fun poly(c: Canvas, close: Boolean, vararg v: Float) {
        path.reset()
        path.moveTo(v[0], v[1])
        var i = 2
        while (i < v.size) { path.lineTo(v[i], v[i + 1]); i += 2 }
        if (close) path.close()
        c.drawPath(path, p)
    }

    private fun fill(c: Canvas, block: () -> Unit) {
        p.style = Paint.Style.FILL
        block()
        p.style = Paint.Style.STROKE
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val s = min(b.width(), b.height()) / 24f
        if (s <= 0f) return
        c.save()
        c.translate(b.left.toFloat(), b.top.toFloat())
        c.scale(s, s)
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            "close" -> { line(c, 6f, 6f, 18f, 18f); line(c, 18f, 6f, 6f, 18f) }
            "plus" -> { line(c, 12f, 5f, 12f, 19f); line(c, 5f, 12f, 19f, 12f) }
            "back" -> { line(c, 19f, 12f, 5f, 12f); poly(c, false, 11f, 6f, 5f, 12f, 11f, 18f) }
            "fwd" -> { line(c, 5f, 12f, 19f, 12f); poly(c, false, 13f, 6f, 19f, 12f, 13f, 18f) }
            "gear" -> {
                c.drawCircle(12f, 12f, 3.2f, p); c.drawCircle(12f, 12f, 7f, p)
                for (i in 0 until 8) {
                    val a = i * Math.PI / 4
                    line(c, 12f + 7f * cos(a).toFloat(), 12f + 7f * sin(a).toFloat(), 12f + 9.6f * cos(a).toFloat(), 12f + 9.6f * sin(a).toFloat())
                }
            }
            "search" -> { c.drawCircle(10.5f, 10.5f, 5.8f, p); line(c, 15f, 15f, 20f, 20f) }
            "more" -> fill(c) { for (y in listOf(5f, 12f, 19f)) c.drawCircle(12f, y, 1.7f, p) }
            "play" -> fill(c) { poly(c, true, 8f, 5f, 19f, 12f, 8f, 19f) }
            "pause" -> { p.strokeWidth = 3.2f; line(c, 9f, 5f, 9f, 19f); line(c, 15f, 5f, 15f, 19f) }
            "next" -> { fill(c) { poly(c, true, 6f, 5f, 15f, 12f, 6f, 19f) }; line(c, 18.5f, 5f, 18.5f, 19f) }
            "prev" -> { fill(c) { poly(c, true, 18f, 5f, 9f, 12f, 18f, 19f) }; line(c, 5.5f, 5f, 5.5f, 19f) }
            "sort" -> {
                line(c, 8f, 5f, 8f, 19f); poly(c, false, 4f, 9f, 8f, 5f, 12f, 9f)
                line(c, 16f, 19f, 16f, 5f); poly(c, false, 12f, 15f, 16f, 19f, 20f, 15f)
            }
            "trash" -> {
                line(c, 5f, 7f, 19f, 7f); poly(c, false, 7f, 7f, 8f, 19f, 16f, 19f, 17f, 7f)
                poly(c, false, 10f, 7f, 10f, 4f, 14f, 4f, 14f, 7f); line(c, 10f, 11f, 10f, 16f); line(c, 14f, 11f, 14f, 16f)
            }
            "home" -> { poly(c, false, 4f, 12f, 12f, 4f, 20f, 12f); poly(c, false, 6f, 11f, 6f, 20f, 18f, 20f, 18f, 11f); poly(c, false, 10f, 20f, 10f, 14f, 14f, 14f, 14f, 20f) }
            "edit" -> { poly(c, true, 15f, 5f, 19f, 9f, 9f, 19f, 5f, 19f, 5f, 15f); line(c, 13f, 7f, 17f, 11f) }
            "palette" -> {
                c.drawCircle(12f, 12f, 8.5f, p)
                fill(c) { c.drawCircle(8f, 10f, 1.4f, p); c.drawCircle(12f, 7.5f, 1.4f, p); c.drawCircle(16f, 10f, 1.4f, p); c.drawCircle(9f, 15f, 1.4f, p) }
            }
            "workspace" -> { c.drawRoundRect(RectF(4f, 4f, 20f, 20f), 4f, 4f, p); line(c, 12f, 8f, 12f, 16f); line(c, 8f, 12f, 16f, 12f) }
            "music" -> { fill(c) { c.drawCircle(8f, 17f, 2.8f, p); c.drawCircle(17f, 15f, 2.8f, p) }; poly(c, false, 10.8f, 17f, 10.8f, 6f, 19.8f, 4f, 19.8f, 15f) }
            "gamepad" -> {
                c.drawRoundRect(RectF(2.5f, 7.5f, 21.5f, 17.5f), 5f, 5f, p); line(c, 7f, 10.5f, 7f, 14.5f); line(c, 5f, 12.5f, 9f, 12.5f)
                fill(c) { c.drawCircle(16f, 11f, 1.2f, p); c.drawCircle(18.3f, 13.5f, 1.2f, p) }
            }
            "chat" -> { c.drawRoundRect(RectF(3.5f, 4.5f, 20.5f, 16.5f), 4f, 4f, p); poly(c, false, 9f, 16.5f, 9f, 20.5f, 13.5f, 16.5f) }
            "camera" -> { c.drawRoundRect(RectF(3f, 7f, 21f, 19f), 3f, 3f, p); c.drawCircle(12f, 13f, 3.6f, p); poly(c, false, 8f, 7f, 9.5f, 4.5f, 14.5f, 4.5f, 16f, 7f) }
            "folder" -> poly(c, true, 3f, 6f, 10f, 6f, 12f, 8.5f, 21f, 8.5f, 21f, 19f, 3f, 19f)
            "coin" -> { c.drawCircle(12f, 12f, 8.5f, p); c.drawCircle(12f, 12f, 4.5f, p) }
            "book" -> { poly(c, true, 4.5f, 5f, 12f, 7f, 19.5f, 5f, 19.5f, 18f, 12f, 20f, 4.5f, 18f); line(c, 12f, 7f, 12f, 20f) }
            "star" -> {
                path.reset()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 9f else 4f
                    val a = -Math.PI / 2 + i * Math.PI / 5
                    val x = 12f + r * cos(a).toFloat(); val y = 12.5f + r * sin(a).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close(); c.drawPath(path, p)
            }
            "heart" -> {
                path.reset(); path.moveTo(12f, 20f); path.cubicTo(3f, 13f, 4f, 5f, 9f, 5f); path.cubicTo(11f, 5f, 12f, 7f, 12f, 8f)
                path.cubicTo(12f, 7f, 13f, 5f, 15f, 5f); path.cubicTo(20f, 5f, 21f, 13f, 12f, 20f); path.close(); c.drawPath(path, p)
            }
            "flame" -> {
                path.reset(); path.moveTo(12f, 3f); path.cubicTo(16f, 8f, 19f, 11f, 19f, 15f); path.cubicTo(19f, 19f, 16f, 21f, 12f, 21f)
                path.cubicTo(8f, 21f, 5f, 19f, 5f, 15f); path.cubicTo(5f, 11f, 9f, 9f, 12f, 3f); path.close(); c.drawPath(path, p)
            }
            "globe" -> { c.drawCircle(12f, 12f, 8.5f, p); c.drawOval(RectF(8f, 3.5f, 16f, 20.5f), p); line(c, 3.5f, 12f, 20.5f, 12f) }
            "briefcase" -> { c.drawRoundRect(RectF(3.5f, 8f, 20.5f, 19f), 2.5f, 2.5f, p); poly(c, false, 9f, 8f, 9f, 5f, 15f, 5f, 15f, 8f); line(c, 3.5f, 13f, 20.5f, 13f) }
            "lock" -> { c.drawRoundRect(RectF(5.5f, 11f, 18.5f, 20.5f), 2.5f, 2.5f, p); poly(c, false, 8f, 11f, 8f, 8f, 9.5f, 5f, 14.5f, 5f, 16f, 8f, 16f, 11f) }
            "info" -> { c.drawCircle(12f, 12f, 8.5f, p); line(c, 12f, 11f, 12f, 16.5f); fill(c) { c.drawCircle(12f, 7.8f, 1.2f, p) } }
            "move" -> {
                line(c, 12f, 3f, 12f, 21f); line(c, 3f, 12f, 21f, 12f)
                poly(c, false, 9f, 6f, 12f, 3f, 15f, 6f); poly(c, false, 9f, 18f, 12f, 21f, 15f, 18f)
                poly(c, false, 6f, 9f, 3f, 12f, 6f, 15f); poly(c, false, 18f, 9f, 21f, 12f, 18f, 15f)
            }
            "eye" -> { c.drawOval(RectF(2.5f, 6.5f, 21.5f, 17.5f), p); c.drawCircle(12f, 12f, 3f, p) }
            "eyeoff" -> { c.drawOval(RectF(2.5f, 6.5f, 21.5f, 17.5f), p); c.drawCircle(12f, 12f, 3f, p); line(c, 4f, 20f, 20f, 4f) }
            "apps" -> for (r in listOf(RectF(4f, 4f, 10.5f, 10.5f), RectF(13.5f, 4f, 20f, 10.5f), RectF(4f, 13.5f, 10.5f, 20f), RectF(13.5f, 13.5f, 20f, 20f))) c.drawRoundRect(r, 2f, 2f, p)
            "image" -> {
                c.drawRoundRect(RectF(3.5f, 5f, 20.5f, 19f), 3f, 3f, p)
                poly(c, false, 4f, 18f, 10f, 12.5f, 14f, 16f, 16.5f, 13.5f, 20f, 17f)
                fill(c) { c.drawCircle(8.5f, 10f, 1.5f, p) }
            }
            "tag" -> { poly(c, true, 3.5f, 12f, 12f, 3.5f, 20.5f, 3.5f, 20.5f, 12f, 12f, 20.5f); fill(c) { c.drawCircle(16.5f, 7.5f, 1.4f, p) } }
            "open" -> { poly(c, false, 14f, 4f, 20f, 4f, 20f, 10f); line(c, 20f, 4f, 11f, 13f); poly(c, false, 17f, 14f, 17f, 20f, 4f, 20f, 4f, 7f, 10f, 7f) }
            "widget" -> { c.drawRoundRect(RectF(3.5f, 3.5f, 20.5f, 20.5f), 4f, 4f, p); line(c, 3.5f, 9.5f, 20.5f, 9.5f); line(c, 10f, 9.5f, 10f, 20.5f) }
            "minus" -> line(c, 5f, 12f, 19f, 12f)
            "flash" -> poly(c, true, 13f, 3f, 6f, 13f, 11f, 13f, 10f, 21f, 18f, 10f, 13f, 10f)
            "wifi" -> {
                c.drawArc(RectF(1f, 8f, 23f, 30f), 225f, 90f, false, p); c.drawArc(RectF(5f, 12f, 19f, 26f), 225f, 90f, false, p)
                c.drawArc(RectF(9f, 16f, 15f, 22f), 225f, 90f, false, p); fill(c) { c.drawCircle(12f, 19.5f, 1.4f, p) }
            }
            "bluetooth" -> poly(c, false, 7f, 7.5f, 17f, 16.5f, 12f, 21f, 12f, 3f, 17f, 7.5f, 7f, 16.5f)
            "airplane" -> poly(c, true, 12f, 3f, 14f, 9f, 21f, 13f, 21f, 15f, 14f, 13f, 13f, 19f, 16f, 21f, 16f, 22f, 12f, 21f, 8f, 22f, 8f, 21f, 11f, 19f, 10f, 13f, 3f, 15f, 3f, 13f, 10f, 9f)
            "calc" -> {
                c.drawRoundRect(RectF(5f, 3f, 19f, 21f), 2.5f, 2.5f, p); line(c, 8f, 8f, 16f, 8f)
                fill(c) { for (x in listOf(9f, 12f, 15f)) for (y in listOf(12f, 15f, 18f)) c.drawCircle(x, y, 0.9f, p) }
            }
            "volume" -> { poly(c, true, 4f, 10f, 8f, 10f, 12.5f, 6f, 12.5f, 18f, 8f, 14f, 4f, 14f); c.drawArc(RectF(10f, 8f, 18f, 16f), -55f, 110f, false, p); c.drawArc(RectF(10f, 5f, 21f, 19f), -50f, 100f, false, p) }
            "sun" -> {
                c.drawCircle(12f, 12f, 4f, p)
                for (i in 0 until 8) { val a = i * Math.PI / 4; line(c, 12f + 7f * cos(a).toFloat(), 12f + 7f * sin(a).toFloat(), 12f + 9.5f * cos(a).toFloat(), 12f + 9.5f * sin(a).toFloat()) }
            }
            "clock" -> { c.drawCircle(12f, 12f, 8.5f, p); poly(c, false, 12f, 7f, 12f, 12f, 15.5f, 14f) }
            "date" -> { c.drawRoundRect(RectF(4f, 5f, 20f, 20f), 3f, 3f, p); line(c, 4f, 10f, 20f, 10f); line(c, 8.5f, 3f, 8.5f, 7f); line(c, 15.5f, 3f, 15.5f, 7f) }
            "battery" -> { c.drawRoundRect(RectF(3.5f, 7.5f, 19f, 16.5f), 2.5f, 2.5f, p); line(c, 21f, 10.5f, 21f, 13.5f); fill(c) { c.drawRoundRect(RectF(5.5f, 9.5f, 14f, 14.5f), 1f, 1f, p) } }
            "dock" -> { c.drawRoundRect(RectF(3f, 13f, 21f, 20f), 3.5f, 3.5f, p); fill(c) { for (x in listOf(8f, 12f, 16f)) c.drawCircle(x, 16.5f, 1.2f, p) }; c.drawRoundRect(RectF(7f, 4f, 17f, 9f), 2f, 2f, p) }
            else -> c.drawCircle(12f, 12f, 8f, p)
        }
        c.restore()
    }

    override fun setAlpha(a: Int) { p.alpha = a }
    override fun setColorFilter(cf: ColorFilter?) { p.colorFilter = cf }
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        /** أيقونات مجلدات يختارها المستخدم من المجموعة */
        val FOLDER_GLYPHS = listOf("gamepad", "chat", "music", "camera", "folder", "coin", "book", "star", "heart", "flame", "globe", "briefcase", "lock", "palette", "home", "gear")
    }
}

/** إنشاء أيقونات جاهزة للأزرار */
object Icons {
    fun drawable(ctx: Context, kind: String, dp: Int, color: Int): VIcon {
        val d = VIcon(kind, color)
        val px = Ui.dp(ctx, dp)
        d.setBounds(0, 0, px, px)
        return d
    }

    /** زر أيقونة (ImageView) بخلفية زجاجية دائرية اختيارية */
    fun button(ctx: Context, kind: String, color: Int, glass: Boolean, onClick: () -> Unit): ImageView {
        val v = ImageView(ctx)
        v.setImageDrawable(VIcon(kind, color))
        val pad = Ui.dp(ctx, 9)
        v.setPadding(pad, pad, pad, pad)
        if (glass) v.background = Theme.panel(ctx, Ui.dpf(ctx, 22f))
        v.setOnClickListener { onClick() }
        return v
    }

    /** يضع أيقونة متجهة بجانب نص TextView (بدل الإيموجي) */
    fun withText(ctx: Context, t: TextView, kind: String, dp: Int, color: Int) {
        val d = drawable(ctx, kind, dp, color)
        t.setCompoundDrawablesRelative(d, null, null, null)
        t.compoundDrawablePadding = Ui.dp(ctx, 8)
        t.gravity = Gravity.CENTER_VERTICAL
    }
}
