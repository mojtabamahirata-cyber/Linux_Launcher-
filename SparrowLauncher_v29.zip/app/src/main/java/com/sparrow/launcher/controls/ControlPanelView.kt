package com.sparrow.launcher.controls

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.sparrow.launcher.apps.AppRepository
import com.sparrow.launcher.core.Bg
import com.sparrow.launcher.core.Icons
import com.sparrow.launcher.core.LauncherController
import com.sparrow.launcher.core.Overlay
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.core.VIcon
import com.sparrow.launcher.core.afterLayout
import com.sparrow.launcher.widgets.SparrowNotificationListener
import kotlin.math.roundToInt

/**
 * لوحة تحكم عائمة ثلاثية الأبعاد: بطاقتان زجاجيتان مائلتان بمنظور حقيقي.
 * الأولى مشغل موسيقى (MediaSession) مع كلمات متزامنة اختيارية، والثانية أزرار وشرائط (صوت، سطوع).
 * قيود أندرويد: لا يمكن لأي تطبيق تشغيل Wi-Fi/بلوتوث مباشرة، فتفتح لوحتها الرسمية. الفلاش والصوت يعملان مباشرة،
 * والسطوع يحتاج صلاحية "تعديل إعدادات النظام" يمنحها المستخدم.
 */
class ControlPanelView(
    ctx: Context,
    private val c: LauncherController,
    private val topInset: Int,
    private val bottomInset: Int
) : FrameLayout(ctx), Overlay {

    override val depth: Float get() = 1f

    private val music = LinearLayout(ctx)
    private val controls = LinearLayout(ctx)
    private val rtl: Float = if (Ui.layoutDir() == LAYOUT_DIRECTION_RTL) -1f else 1f
    private val baseM = 13f * rtl
    private val baseC = -13f * rtl

    // ----- الموسيقى
    private val art = ImageView(ctx)
    private val title = Ui.text(ctx, "", 18f, Theme.text(ctx), true)
    private val artist = Ui.text(ctx, "", 13f, Theme.sub(ctx))
    private val lyPrev = Ui.text(ctx, "", 13f, Theme.sub(ctx))
    private val lyCur = Ui.text(ctx, "", 18f, Theme.text(ctx), true)
    private val lyNext = Ui.text(ctx, "", 13f, Theme.sub(ctx))
    private val progress = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
    private val play = ImageView(ctx)
    private var ctl: MediaController? = null
    private var lines: List<LyricsRepo.Line> = emptyList()
    private var lastIdx = -2
    private var trackKey = ""
    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val comp = ComponentName(ctx, SparrowNotificationListener::class.java)
    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(s: PlaybackState?) { refreshMeta() }
        override fun onMetadataChanged(m: MediaMetadata?) { refreshMeta() }
    }
    private val sessions = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }
    private val tick = object : Runnable {
        override fun run() { updateProgress(); Bg.main.postDelayed(this, 250) }
    }
    private var torchOn = false

    init {
        layoutDirection = Ui.layoutDir()
        isClickable = true
        setBackgroundColor(0x66000000)
        setOnClickListener { c.closeOverlay(this) }

        buildMusic()
        buildControls()
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(Ui.dp(ctx, 16), topInset + Ui.dp(ctx, 12), Ui.dp(ctx, 16), bottomInset + Ui.dp(ctx, 12))
        col.addView(music, LinearLayout.LayoutParams(-1, -2))
        col.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 18) })
        addView(col, LayoutParams(-1, -1))

        // منظور حقيقي: البطاقات مائلة ومبتعدة عن الكاميرا
        for (v in listOf(music, controls)) { v.cameraDistance = 14000f * resources.displayMetrics.density; v.isClickable = true }
        music.rotationY = baseM
        controls.rotationY = baseC
        music.rotationX = 4f
        controls.rotationX = 4f

        // دخول: تطير من العمق وتستقر بميلها
        val cards = listOf(music, controls)
        for ((i, v) in cards.withIndex()) { v.alpha = 0f; v.translationY = Ui.dp(ctx, 70).toFloat(); v.scaleX = 0.8f; v.scaleY = 0.8f; v.rotationX = 28f }
        afterLayout {
            for ((i, v) in cards.withIndex()) {
                v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).rotationX(4f)
                    .setStartDelay(i * 110L).setDuration(if (Prefs.reduceMotion) 0L else 520)
                    .setInterpolator(PathInterpolator(0.05f, 0.7f, 0.1f, 1f)).start()
            }
        }
        refreshMeta()
    }

    // ------------------------------------------------------------ بطاقة الموسيقى
    private fun roundOutline(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
    }

    private fun buildMusic() {
        val ctx = context
        music.orientation = LinearLayout.VERTICAL
        music.background = Theme.panel(ctx, Ui.dpf(ctx, 30f))
        music.setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 16), Ui.dp(ctx, 16), Ui.dp(ctx, 14))
        val top = LinearLayout(ctx)
        top.gravity = Gravity.CENTER_VERTICAL
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = Ui.round(0x22FFFFFF, Ui.dpf(ctx, 18f))
        art.outlineProvider = roundOutline(Ui.dpf(ctx, 18f))
        art.clipToOutline = true
        top.addView(art, LinearLayout.LayoutParams(Ui.dp(ctx, 92), Ui.dp(ctx, 92)))
        val tc = LinearLayout(ctx)
        tc.orientation = LinearLayout.VERTICAL
        title.maxLines = 1
        artist.maxLines = 1
        tc.addView(title)
        tc.addView(artist)
        top.addView(tc, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = Ui.dp(ctx, 14) })
        music.addView(top)

        // الكلمات المتزامنة: السطر الحالي كبير والسابق والتالي خافتان
        val ly = LinearLayout(ctx)
        ly.orientation = LinearLayout.VERTICAL
        ly.gravity = Gravity.CENTER
        for (t in listOf(lyPrev, lyCur, lyNext)) { t.gravity = Gravity.CENTER; t.maxLines = 2; ly.addView(t, LinearLayout.LayoutParams(-1, -2)) }
        lyPrev.alpha = 0.55f
        lyNext.alpha = 0.55f
        ly.setPadding(0, Ui.dp(ctx, 12), 0, Ui.dp(ctx, 6))
        music.addView(ly, LinearLayout.LayoutParams(-1, Ui.dp(ctx, 120)))

        progress.max = 1000
        progress.progressTintList = android.content.res.ColorStateList.valueOf(Theme.text(ctx))
        music.addView(progress, LinearLayout.LayoutParams(-1, Ui.dp(ctx, 4)))

        val row = LinearLayout(ctx)
        row.gravity = Gravity.CENTER
        fun b(kind: String, f: () -> Unit) {
            row.addView(Icons.button(ctx, kind, Theme.text(ctx), false, f), LinearLayout.LayoutParams(Ui.dp(ctx, 56), Ui.dp(ctx, 56)))
        }
        b("prev") { ctl?.transportControls?.skipToPrevious() }
        play.setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 12), Ui.dp(ctx, 12), Ui.dp(ctx, 12))
        play.setOnClickListener {
            if (ctl?.playbackState?.state == PlaybackState.STATE_PLAYING) ctl?.transportControls?.pause() else ctl?.transportControls?.play()
        }
        row.addView(play, LinearLayout.LayoutParams(Ui.dp(ctx, 64), Ui.dp(ctx, 64)))
        b("next") { ctl?.transportControls?.skipToNext() }
        music.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(ctx, 6) })
    }

    private fun hasAccess(): Boolean =
        (Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: "").contains(context.packageName)

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        try {
            if (hasAccess()) {
                msm.addOnActiveSessionsChangedListener(sessions, comp)
                pick(msm.getActiveSessions(comp))
            } else {
                title.text = "فعّل الوصول للإشعارات"
                artist.text = "اضغط هنا لتشغيل المشغل"
                music.setOnClickListener {
                    try { c.activity.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
        }
        Bg.main.post(tick)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        Bg.main.removeCallbacks(tick)
        try { msm.removeOnActiveSessionsChangedListener(sessions) } catch (_: Exception) {}
        ctl?.unregisterCallback(cb)
        ctl = null
    }

    private fun pick(list: List<MediaController>?) {
        ctl?.unregisterCallback(cb)
        ctl = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        ctl?.registerCallback(cb)
        refreshMeta()
    }

    private fun refreshMeta() {
        val k = ctl
        if (k == null) {
            title.text = "لا يوجد تشغيل"
            artist.text = "شغّل أغنية في Spotify أو أي مشغل"
            play.setImageDrawable(VIcon("play", Theme.text(context)))
            return
        }
        val m = k.metadata
        val t = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: ""
        val a = m?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        title.text = if (t.isEmpty()) k.packageName else t
        artist.text = a
        art.setImageBitmap(m?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_ART) ?: m?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON))
        play.setImageDrawable(VIcon(if (k.playbackState?.state == PlaybackState.STATE_PLAYING) "pause" else "play", Theme.text(context)))
        val key = "$a|$t"
        if (key != trackKey && t.isNotEmpty()) {
            trackKey = key
            lines = emptyList()
            lastIdx = -2
            if (!Prefs.lyrics) { setLy("", "الكلمات: فعّلها من الإعدادات (تستخدم الإنترنت)", "") }
            else {
                setLy("", "جارٍ جلب الكلمات…", "")
                val dur = ((m?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L) / 1000).toInt()
                LyricsRepo.get(a, t, dur) { res ->
                    if (key == trackKey) {
                        lines = res
                        lastIdx = -2
                        if (res.isEmpty()) setLy("", "لا توجد كلمات متزامنة لهذه الأغنية", "")
                    }
                }
            }
        }
    }

    private fun setLy(p: String, cur: String, n: String) { lyPrev.text = p; lyCur.text = cur; lyNext.text = n }

    private fun positionMs(): Long {
        val st = ctl?.playbackState ?: return 0L
        var p = st.position
        if (st.state == PlaybackState.STATE_PLAYING) p += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        return p
    }

    /** يحرّك شريط التقدم ويختار سطر الكلمات المناسب لموضع التشغيل */
    private fun updateProgress() {
        val k = ctl ?: return
        val dur = k.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val pos = positionMs()
        if (dur > 0) progress.progress = (pos * 1000 / dur).toInt().coerceIn(0, 1000)
        if (lines.isEmpty()) return
        var idx = -1
        for (i in lines.indices) { if (lines[i].ms <= pos + 150) idx = i else break }
        if (idx != lastIdx) {
            lastIdx = idx
            setLy(lines.getOrNull(idx - 1)?.text ?: "", if (idx >= 0) lines[idx].text else "♪", lines.getOrNull(idx + 1)?.text ?: "")
            lyCur.alpha = 0f
            lyCur.animate().alpha(1f).setDuration(220).start()
        }
    }

    // ------------------------------------------------------------ بطاقة الأزرار والشرائط
    private fun tile(kind: String, onClick: (ImageView) -> Unit): ImageView {
        val ctx = context
        val v = Icons.button(ctx, kind, Theme.text(ctx), true) {}
        v.setPadding(Ui.dp(ctx, 15), Ui.dp(ctx, 15), Ui.dp(ctx, 15), Ui.dp(ctx, 15))
        v.setOnClickListener { onClick(v) }
        return v
    }

    private fun buildControls() {
        val ctx = context
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER_VERTICAL
        controls.background = Theme.panel(ctx, Ui.dpf(ctx, 30f))
        controls.setPadding(Ui.dp(ctx, 14), Ui.dp(ctx, 14), Ui.dp(ctx, 14), Ui.dp(ctx, 14))

        val grid = GridLayout(ctx)
        grid.columnCount = 3
        fun add(v: View) {
            val lp = GridLayout.LayoutParams()
            lp.width = Ui.dp(ctx, 62); lp.height = Ui.dp(ctx, 62)
            lp.setMargins(Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 4))
            grid.addView(v, lp)
        }
        add(tile("flash") { toggleTorch(it) })
        add(tile("wifi") { open(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) })
        add(tile("bluetooth") { open(Settings.ACTION_BLUETOOTH_SETTINGS) })
        add(tile("airplane") { open(Settings.ACTION_AIRPLANE_MODE_SETTINGS) })
        add(tile("camera") { open(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA) })
        add(tile("calc") {
            val a = AppRepository.apps.firstOrNull { it.pkg.contains("calculator", true) }
            if (a != null) c.launchApp(a.key, null) else Ui.toast(ctx, "لا يوجد تطبيق حاسبة")
        })
        controls.addView(grid, LinearLayout.LayoutParams(0, -2, 1f))

        // الصوت (يعمل مباشرة) والسطوع (يحتاج صلاحية تعديل إعدادات النظام)
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val bright = VSlider(ctx, "sun") { v ->
            try {
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, (v * 255).roundToInt().coerceIn(1, 255))
            } catch (_: Exception) {}
        }
        bright.locked = !Settings.System.canWrite(ctx)
        bright.onLockedTap = {
            Ui.toast(ctx, "امنح Sparrow إذن تعديل إعدادات النظام لتحريك السطوع")
            try { c.activity.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName))) } catch (_: Exception) {}
        }
        bright.value = try { Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f } catch (e: Exception) { 0.5f }
        val vol = VSlider(ctx, "volume") { v -> am.setStreamVolume(AudioManager.STREAM_MUSIC, (v * maxV).roundToInt(), 0) }
        vol.value = am.getStreamVolume(AudioManager.STREAM_MUSIC) / maxV.toFloat()
        controls.addView(bright, LinearLayout.LayoutParams(Ui.dp(ctx, 54), Ui.dp(ctx, 150)).apply { marginStart = Ui.dp(ctx, 10) })
        controls.addView(vol, LinearLayout.LayoutParams(Ui.dp(ctx, 54), Ui.dp(ctx, 150)).apply { marginStart = Ui.dp(ctx, 10) })
    }

    private fun open(action: String) {
        try { c.activity.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Ui.toast(context, "تعذر الفتح") }
    }

    private fun toggleTorch(tile: ImageView) {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { Ui.toast(context, "لا يوجد فلاش"); return }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
            tile.background = if (torchOn) Ui.round(Theme.ACCENT, Ui.dpf(context, 22f)) else Theme.panel(context, Ui.dpf(context, 22f))
        } catch (e: Exception) {
            torchOn = false
            Ui.toast(context, "تعذر تشغيل الفلاش")
        }
    }

    /** ميل البطاقات يتبع إصبعك قليلاً (Parallax) فتحس أنها معلّقة بالفراغ */
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_MOVE && width > 0) {
            val tx = (e.x / width - 0.5f) * 10f
            val ty = (e.y / height - 0.5f) * -6f
            music.rotationY = baseM + tx
            controls.rotationY = baseC + tx
            music.rotationX = 4f + ty
            controls.rotationX = 4f + ty
        }
        return super.dispatchTouchEvent(e)
    }

    override fun animateOut(end: () -> Unit) {
        val d = if (Prefs.reduceMotion) 0L else 220L
        for (v in listOf(music, controls)) v.animate().alpha(0f).translationY(Ui.dp(context, 50).toFloat()).scaleX(0.85f).scaleY(0.85f).setDuration(d).start()
        animate().alpha(0f).setDuration(d).withEndAction { end() }.start()
    }

    override fun handleBack(): Boolean = false
}
