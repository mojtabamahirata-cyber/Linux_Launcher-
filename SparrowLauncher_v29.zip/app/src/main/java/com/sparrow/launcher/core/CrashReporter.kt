package com.sparrow.launcher.core

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/**
 * يحفظ سبب أي انهيار في ملف داخلي، وعند فتح اللانشر مرة ثانية يعرضه على الشاشة
 * (نص قابل للنسخ) بدل أن ينغلق بصمت. هكذا نعرف السبب بدون adb.
 */
object CrashReporter {
    fun install(ctx: Context) {
        val f = File(ctx.filesDir, "crash.txt")
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { f.writeText(Log.getStackTraceString(e)) } catch (_: Exception) {}
            old?.uncaughtException(t, e)
        }
    }

    /** true = يوجد انهيار سابق وتم عرضه (لا تكمل تشغيل اللانشر) */
    fun showIfAny(a: Activity): Boolean {
        val f = File(a.filesDir, "crash.txt")
        if (!f.exists()) return false
        val txt = try { f.readText() } catch (e: Exception) { return false }
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(Color.parseColor("#101420"))
        col.setPadding(30, 90, 30, 30)
        val title = TextView(a)
        title.text = "انهار Sparrow في المرة السابقة. انسخ النص وأرسله:"
        title.setTextColor(Color.WHITE)
        title.textSize = 16f
        col.addView(title)
        val tv = TextView(a)
        tv.text = txt.take(3500)
        tv.textSize = 10f
        tv.setTextColor(Color.parseColor("#FFB4A8"))
        tv.setTextIsSelectable(true)
        val sv = ScrollView(a)
        sv.addView(tv)
        col.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val copy = Button(a)
        copy.text = "نسخ"
        copy.setOnClickListener {
            val cm = a.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("crash", txt))
        }
        col.addView(copy)
        val go = Button(a)
        go.text = "حذف السجل والمتابعة"
        go.setOnClickListener { f.delete(); a.recreate() }
        col.addView(go)
        a.setContentView(col)
        return true
    }
}
