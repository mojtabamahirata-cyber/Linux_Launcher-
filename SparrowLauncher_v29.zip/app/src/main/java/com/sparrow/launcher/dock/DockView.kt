package com.sparrow.launcher.dock

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import com.sparrow.launcher.apps.AppCellView
import com.sparrow.launcher.apps.AppRepository
import com.sparrow.launcher.apps.FolderIconView
import com.sparrow.launcher.core.LauncherController
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.persistence.StateStore

/** Dock / Taskbar: شريط أفقي قابل للتمرير. لكل Workspace Dock خاص به. */
class DockView(ctx: Context, private val c: LauncherController) : FrameLayout(ctx) {
    private val scroll = HorizontalScrollView(ctx)
    private val row = LinearLayout(ctx)

    init {
        scroll.isHorizontalScrollBarEnabled = false
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        scroll.addView(row, LayoutParams(-2, -1))
        addView(scroll, LayoutParams(-1, -1))
    }

    fun heightPx(): Int = Ui.dp(context, Prefs.dockSize + 22)

    fun bind() {
        val a = (Prefs.dockAlpha * 255 / 100).coerceIn(0, 255)
        val base = if (Theme.dark(context)) 0x101420 else 0xF0F2F8
        val bg = if (Prefs.glass) Theme.panel(context, Ui.dpf(context, 28f)) else Ui.round((a shl 24) or base, Ui.dpf(context, 28f))
        if (Prefs.glass) bg.alpha = a.coerceAtLeast(40)
        background = bg
        row.removeAllViews()
        val slotW = (resources.displayMetrics.widthPixels - Ui.dp(context, 40)) / Prefs.dockMax.coerceIn(3, 9)
        val icon = Ui.dp(context, Prefs.dockSize)
        for (entry in StateStore.dock) {
            val v: View = if (entry.startsWith("a:")) {
                val app = AppRepository.byKey[entry.substring(2)] ?: continue
                AppCellView(context).apply { bind(app, Prefs.dockSize, false, 0, false) }
            } else {
                val f = StateStore.folders[entry.substring(2)] ?: continue
                FolderIconView(context, f, icon)
            }
            v.setOnClickListener { c.launchDockEntry(entry, v) }
            v.setOnLongClickListener { c.dragDockEntry(v, entry); true }
            row.addView(v, LinearLayout.LayoutParams(slotW, -1))
        }
        val plus = com.sparrow.launcher.core.Icons.button(context, "plus", Theme.text(context), false) { c.addToDock() }
        plus.alpha = 0.7f
        row.addView(plus, LinearLayout.LayoutParams(slotW, -1))
    }

    /** موضع الإدراج في الـDock عند إفلات عنصر (إحداثيات الشاشة). آخر عنصر هو زر + فلا يُحسب */
    fun indexAt(screenX: Float): Int {
        val rtl = layoutDirection == View.LAYOUT_DIRECTION_RTL
        val n = row.childCount - 1
        val loc = IntArray(2)
        for (i in 0 until n) {
            val ch = row.getChildAt(i)
            ch.getLocationOnScreen(loc)
            val cx = loc[0] + ch.width / 2f
            if (if (rtl) screenX > cx else screenX < cx) return i
        }
        return n.coerceAtLeast(0)
    }
}
