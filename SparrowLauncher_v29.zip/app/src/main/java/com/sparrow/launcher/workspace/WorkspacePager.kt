package com.sparrow.launcher.workspace

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.home.CellLayout
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * ينقل بين الـ Workspaces مع تأثير ثلاثي الأبعاد: Perspective + Depth + Scale + Rotation + Parallax.
 * كل الحركة تعتمد على رقم واحد (position) والتحويلات تُطبَّق على الـ Views مباشرة (GPU) بدون إعادة بناء.
 */
class WorkspacePager(ctx: Context) : FrameLayout(ctx) {

    interface Listener {
        fun onPosition(pos: Float)
        fun onSettled(index: Int)
    }

    var listener: Listener? = null
    private val pages = ArrayList<CellLayout>()
    var position = 0f
        private set
    private var anim: ValueAnimator? = null
    private var vt: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    val rtl: Boolean get() = layoutDirection == View.LAYOUT_DIRECTION_RTL
    val current: Int get() = position.roundToInt().coerceIn(0, max(0, pages.size - 1))
    val count: Int get() = pages.size
    fun page(i: Int): CellLayout? = pages.getOrNull(i)

    fun setPages(list: List<CellLayout>, index: Int) {
        anim?.cancel()
        removeAllViews()
        pages.clear()
        pages.addAll(list)
        for (p in pages) addView(p, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        position = index.coerceIn(0, max(0, pages.size - 1)).toFloat()
        applyTransforms()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        applyTransforms()
    }

    private fun applyTransforms() {
        val w = width.toFloat()
        if (w <= 0f) return
        val dir = if (rtl) -1f else 1f
        val style = if (Prefs.reduceMotion) "flat" else Prefs.transition
        val persp = Prefs.perspective / 100f
        val par = Prefs.parallax / 100f
        for (i in pages.indices) {
            val p = pages[i]
            val off = i - position
            val a = abs(off)
            if (a >= 1.6f) {
                if (p.visibility != View.INVISIBLE) p.visibility = View.INVISIBLE
                continue
            }
            if (p.visibility != View.VISIBLE) p.visibility = View.VISIBLE
            val t = min(a, 1f)
            when (style) {
                "flat" -> {
                    p.translationX = dir * off * w
                    p.scaleX = 1f; p.scaleY = 1f; p.rotationY = 0f
                    p.alpha = 1f - 0.3f * t
                    p.translationZ = 0f
                }
                "depth" -> {
                    // الصفحة الخارجة تنزلق فوق، والداخلة تبقى ثابتة وتكبر تدريجياً
                    if (off <= 0f) {
                        p.translationX = dir * off * w
                        p.scaleX = 1f; p.scaleY = 1f; p.alpha = 1f; p.translationZ = 2f
                    } else {
                        p.translationX = 0f
                        val s = 0.78f + 0.22f * (1f - t)
                        p.scaleX = s; p.scaleY = s; p.alpha = 1f - t; p.translationZ = 0f
                    }
                    p.rotationY = 0f
                }
                else -> {
                    // carousel: صفحات في مساحة حقيقية، تبتعد وتصغر وتدور قليلاً
                    p.cameraDistance = w * 9f
                    p.translationX = dir * off * w * 0.94f
                    val s = 1f - (0.05f + 0.13f * persp) * t
                    p.scaleX = s; p.scaleY = s
                    p.rotationY = -dir * off.coerceIn(-1f, 1f) * 32f * persp
                    p.alpha = 1f - 0.55f * t
                    p.translationZ = (1f - t) * 6f
                }
            }
            p.applyParallax(off, dir, par)
        }
        listener?.onPosition(position)
    }

    fun goTo(i: Int, animate: Boolean = true) {
        val t = i.coerceIn(0, max(0, pages.size - 1))
        anim?.cancel()
        if (!animate || width == 0) {
            position = t.toFloat()
            applyTransforms()
            listener?.onSettled(t)
            return
        }
        val from = position
        val target = t.toFloat()
        val a = ValueAnimator.ofFloat(from, target)
        a.duration = if (Prefs.reduceMotion) 120L else min(520L, (260L + 90L * abs(target - from)).toLong())
        a.interpolator = android.view.animation.PathInterpolator(0.05f, 0.7f, 0.1f, 1f)
        a.addUpdateListener {
            position = it.animatedValue as Float
            applyTransforms()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(an: Animator) {
                if (position == target) listener?.onSettled(t)
            }
        })
        anim = a
        a.start()
    }

    // ------------------------------------------------------------ اللمس
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (pages.size < 2) return false
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            vt?.recycle()
            vt = VelocityTracker.obtain()
        }
        vt?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x
                dragging = false
                if (anim?.isRunning == true) {
                    anim?.cancel()
                    dragging = true
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && e.pointerCount == 1) {
                    val dx = e.x - downX
                    val dy = e.y - downY
                    if (abs(dx) > slop && abs(dx) > abs(dy) * 1.2f) {
                        dragging = true
                        lastX = e.x
                        parent?.requestDisallowInterceptTouchEvent(true)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) finishDrag()
            }
        }
        return dragging
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (pages.size < 2) return true
        vt?.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    val dir = if (rtl) -1f else 1f
                    val dx = e.x - lastX
                    lastX = e.x
                    position = (position - dir * dx / width).coerceIn(-0.3f, pages.size - 1 + 0.3f)
                    applyTransforms()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) finishDrag()
            }
        }
        return true
    }

    private fun finishDrag() {
        dragging = false
        val dir = if (rtl) -1f else 1f
        vt?.computeCurrentVelocity(1000)
        val v = -dir * (vt?.xVelocity ?: 0f)
        vt?.recycle()
        vt = null
        val target = when {
            v > 900f -> floor(position).toInt() + 1
            v < -900f -> ceil(position).toInt() - 1
            else -> position.roundToInt()
        }
        goTo(target, true)
    }
}
