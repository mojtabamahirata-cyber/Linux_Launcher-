package com.sparrow.launcher.persistence

/** عنصر موضوع على شبكة Workspace: تطبيق / مجلد / ويدجت حقيقي / مشغل موسيقى */
class Item(
    var id: String,
    var type: String,
    /** app: مفتاح التطبيق (pkg/class) | folder: id المجلد | widget: رقم الويدجت | media: "media" */
    var ref: String,
    var col: Int,
    var row: Int,
    var sx: Int = 1,
    var sy: Int = 1
) {
    companion object {
        const val APP = "app"
        const val FOLDER = "folder"
        const val WIDGET = "widget"
        const val MEDIA = "media"
        const val BUILTIN = "builtin"   // ويدجت مصنوعة داخل Sparrow (ref = clock/date/battery/search)
    }
}

/** مساحة عمل: عناصرها + Dock خاص بها ("a:key" أو "f:folderId") */
class Workspace(
    var id: String,
    var name: String,
    var tint: Int = 0,
    val items: MutableList<Item> = ArrayList(),
    val dock: MutableList<String> = ArrayList()
)

/** مجلد. يحتوي تطبيقات ومجلدات فرعية (بدون حد للتداخل) */
class Folder(
    var id: String,
    var name: String,
    var emoji: String = "",
    var iconPath: String = "",
    var color: Int = 0,
    var view: String = "grid",
    val apps: MutableList<String> = ArrayList(),
    val folders: MutableList<String> = ArrayList()
)
