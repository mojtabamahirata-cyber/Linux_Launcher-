package com.sparrow.launcher.widgets

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import com.sparrow.launcher.core.Overlay
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.home.CellLayout
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * تغيير حجم الويدجت بالسحب بحرية: اسحب الزاوية السفلية، والحجم يلتصق بخلايا الشبكة ويحترم حدود الصفحة والعناصر الأخرى.
 * اضغط خارج الإطار للانتهاء.
 */
class ResizeOverlay(
    ctx: Context,
    private val target: View,
    private val lp: CellLayout.LP,
    private val cell: CellLayout,
    private val canSet: (Int, Int) -> Boolean,
    private val onDone: () -> Unit,
    private val onClose: (ResizeOverlay) -> Unit
) : FrameLayout(ctx), Overlay {

    override val depth: Float get() = 0f
    private val rect = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var dragging = false

    init {
        setWillNotDraw(false)
        isClickable = true
        setBackgroundColor(0x55000000)
    }

    private fun updateRect() {
        val a = IntArray(2)
        val b = IntArray(2)
        target.getLocationOnScreen(a)
        getLocationOnScreen(b)
        rect.set((a[0] - b[0]).toFloat(), (a[1] - b[1]).toFloat(), (a[0] - b[0] + target.width).toFloat(), (a[1] - b[1] + target.height).toFloat())
    }

    override fun onDraw(c: Canvas) {
        updateRect()
        val r = Ui.dpf(context, 18f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = Ui.dpf(context, 2.5f)
        paint.color = Theme.ACCENT
        c.drawRoundRect(rect, r, r, paint)
        paint.style = Paint.Style.FILL
        c.drawCircle(rect.right, rect.bottom, Ui.dpf(context, 13f), paint)
        paint.color = 0xFFFFFFFF.toInt()
        c.drawCircle(rect.right, rect.bottom, Ui.dpf(context, 5f), paint)
        paint.textSize = Ui.dpf(context, 13f)
        paint.textAlign = Paint.Align.CENTER
        c.drawText("اسحب الزاوية لتغيير الحجم  •  اضغط خارج الإطار للإنهاء", width / 2f, Ui.dpf(context, 90f), paint)
        if (dragging) postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                updateRect()
                if (hypot(e.x - rect.right, e.y - rect.bottom) < Ui.dpf(context, 40f)) {
                    dragging = true
                    invalidate()
                } else if (!rect.contains(e.x, e.y)) {
                    onClose(this)
                }
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val loc = IntArray(2)
                cell.getLocationOnScreen(loc)
                val nx = ((e.rawX - loc[0] - target.left) / cell.cellW).roundToInt().coerceAtLeast(1)
                val ny = ((e.rawY - loc[1] - target.top) / cell.cellH).roundToInt().coerceAtLeast(1)
                if ((nx != lp.sx || ny != lp.sy) && canSet(nx, ny)) {
                    lp.sx = nx
                    lp.sy = ny
                    target.requestLayout()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) { dragging = false; onDone() }
            }
        }
        return true
    }

    override fun animateOut(end: () -> Unit) { end() }
    override fun handleBack(): Boolean = false
}
