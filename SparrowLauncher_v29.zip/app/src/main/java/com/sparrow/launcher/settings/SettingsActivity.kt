package com.sparrow.launcher.settings

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.CompoundButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.sparrow.launcher.apps.AppRepository
import com.sparrow.launcher.core.*
import com.sparrow.launcher.gestures.GestureActions
import com.sparrow.launcher.persistence.StateStore

/** الإعدادات مقسّمة لأقسام. كل تغيير يُحفظ فوراً ويُطبَّق عند الرجوع للشاشة الرئيسية */
class SettingsActivity : Activity() {
    private lateinit var col: LinearLayout
    private var pendingGesture = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        StateStore.load(this)
        window.setBackgroundDrawable(android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            if (Theme.dark(this)) intArrayOf(0xFF0A0F1F.toInt(), 0xFF14214A.toInt()) else intArrayOf(0xFFF5F7FC.toInt(), 0xFFDCE6FA.toInt())
        ))
        val sv = ScrollView(this)
        sv.layoutDirection = Ui.layoutDir()
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(this, 16), Ui.dp(this, 40), Ui.dp(this, 16), Ui.dp(this, 40))
        sv.addView(col)
        setContentView(sv)
        build()
    }

    private var idx = 0
    private fun rebuild() { col.removeAllViews(); idx = 0; build() }

    /** حركة دخول متتابعة (تدخل الأقسام واحداً بعد الآخر) */
    private fun lively(v: android.view.View) {
        v.alpha = 0f
        v.translationY = Ui.dp(this, 18).toFloat()
        v.animate().alpha(1f).translationY(0f).setStartDelay(minOf(idx * 40L, 480L)).setDuration(300)
            .setInterpolator(android.view.animation.PathInterpolator(0.05f, 0.7f, 0.1f, 1f)).start()
        idx++
    }

    private var card: LinearLayout? = null
    private var secIcon = "gear"
    private val secIcons = mapOf(
        "المظهر" to "palette", "الشاشة الرئيسية" to "home", "App Drawer" to "apps", "الإيماءات" to "move",
        "Dock" to "dock", "Widgets" to "widget", "المجلدات" to "folder", "Workspace" to "workspace",
        "النسخ الاحتياطي والأخيرة" to "open", "النظام" to "gear"
    )

    /** كل قسم = بطاقة زجاجية بعنوان، وفيها صفوف بأيقونة دائرية ملونة */
    private fun section(t: String) {
        val h = Ui.text(this, t, 14f, Theme.ACCENT, true)
        h.setPadding(Ui.dp(this, 8), Ui.dp(this, 22), Ui.dp(this, 8), Ui.dp(this, 8))
        col.addView(h)
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = Theme.panel(this, Ui.dpf(this, 22f))
        col.addView(c, LinearLayout.LayoutParams(-1, -2))
        card = c
        secIcon = secIcons[t] ?: "gear"
        lively(h)
        lively(c)
    }

    private fun leading(): android.view.View {
        val iv = android.widget.ImageView(this)
        iv.setImageDrawable(VIcon(secIcon, Theme.ACCENT))
        val p = Ui.dp(this, 9)
        iv.setPadding(p, p, p, p)
        iv.background = Ui.round(0x2A7EA6FF, Ui.dpf(this, 19f))
        return iv
    }

    private fun addRow(v: android.view.View) {
        val c = card ?: return
        if (c.childCount > 0) {
            val d = android.view.View(this)
            d.setBackgroundColor(0x22FFFFFF)
            val lp = LinearLayout.LayoutParams(-1, 1)
            lp.marginStart = Ui.dp(this, 64)
            lp.marginEnd = Ui.dp(this, 14)
            c.addView(d, lp)
        }
        c.addView(v, LinearLayout.LayoutParams(-1, -2))
    }

    private fun press(v: android.view.View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> view.animate().alpha(0.55f).setDuration(80).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> view.animate().alpha(1f).setDuration(180).start()
            }
            false
        }
    }

    private fun rowBase(title: String, sub: String?): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = android.view.Gravity.CENTER_VERTICAL
        r.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12))
        r.addView(leading(), LinearLayout.LayoutParams(Ui.dp(this, 38), Ui.dp(this, 38)))
        val tc = LinearLayout(this)
        tc.orientation = LinearLayout.VERTICAL
        tc.addView(Ui.text(this, title, 15f, Theme.text(this), true))
        if (sub != null) {
            val s = Ui.text(this, sub, 12f, Theme.sub(this))
            s.setPadding(0, Ui.dp(this, 2), 0, 0)
            tc.addView(s)
        }
        val lp = LinearLayout.LayoutParams(0, -2, 1f)
        lp.marginStart = Ui.dp(this, 12)
        lp.marginEnd = Ui.dp(this, 8)
        r.addView(tc, lp)
        return r
    }

    private fun row(title: String, sub: String? = null, onClick: () -> Unit) {
        val r = rowBase(title, sub)
        val ch = android.widget.ImageView(this)
        ch.setImageDrawable(VIcon(if (Ui.layoutDir() == android.view.View.LAYOUT_DIRECTION_LTR) "fwd" else "back", Theme.sub(this)))
        r.addView(ch, LinearLayout.LayoutParams(Ui.dp(this, 20), Ui.dp(this, 20)))
        r.setOnClickListener { onClick() }
        press(r)
        addRow(r)
    }

    private fun sw(title: String, key: String, def: Boolean) {
        val r = rowBase(title, null)
        val s = Switch(this)
        s.isChecked = Prefs.bool(key, def)
        s.trackTintList = android.content.res.ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(Theme.ACCENT, 0x55FFFFFF)
        )
        s.thumbTintList = android.content.res.ColorStateList.valueOf(0xFFFFFFFF.toInt())
        s.setOnCheckedChangeListener { _: CompoundButton, on: Boolean -> Prefs.put(key, on) }
        r.addView(s)
        r.setOnClickListener { s.toggle() }
        addRow(r)
    }

    private fun seek(title: String, key: String, min: Int, max: Int, def: Int) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val r = rowBase(title, null)
        val vt = Ui.text(this, Prefs.int(key, def).toString(), 14f, Theme.ACCENT, true)
        r.addView(vt)
        box.addView(r)
        val s = SeekBar(this)
        s.max = max - min
        s.progress = Prefs.int(key, def) - min
        s.progressTintList = android.content.res.ColorStateList.valueOf(Theme.ACCENT)
        s.thumbTintList = android.content.res.ColorStateList.valueOf(Theme.ACCENT)
        s.setPaddingRelative(Ui.dp(this, 62), 0, Ui.dp(this, 18), Ui.dp(this, 10))
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { vt.text = (p + min).toString() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { Prefs.put(key, (sb?.progress ?: 0) + min) }
        })
        box.addView(s)
        addRow(box)
    }

    private fun choice(title: String, key: String, def: String, ids: List<String>, labels: List<String>) {
        val cur = Prefs.str(key, def)
        row(title, labels.getOrElse(ids.indexOf(cur)) { cur }) {
            Ui.list(this, title, labels) { i -> Prefs.put(key, ids[i]); rebuild() }
        }
    }

    private fun build() {
        // رأس الصفحة: زر رجوع + عنوان كبير
        val head = LinearLayout(this)
        head.gravity = android.view.Gravity.CENTER_VERTICAL
        head.addView(Icons.button(this, if (Ui.layoutDir() == android.view.View.LAYOUT_DIRECTION_LTR) "back" else "fwd", Theme.text(this), true) { finish() },
            LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)))
        val ttl = Ui.text(this, "الإعدادات", 26f, Theme.text(this), true)
        ttl.setPadding(Ui.dp(this, 14), 0, 0, 0)
        head.addView(ttl)
        col.addView(head)
        lively(head)

        section("المظهر")
        choice("الثيم", "theme", "dark", listOf("dark", "light", "auto"), listOf("داكن", "فاتح", "تلقائي"))
        choice("اتجاه الواجهة", "direction", "rtl", listOf("rtl", "ltr", "auto"), listOf("يمين لليسار (عربي)", "يسار لليمين", "حسب لغة الهاتف"))
        sw("وضع الزجاج (شفاف مع حواف لامعة)", "glass", true)
        sw("ألوان الواجهة من لون الخلفية", "dynamic_color", true)
        seek("شفافية عناصر الواجهة %", "ui_alpha", 30, 100, 88)
        seek("قوة الطمس (Blur)", "blur", 0, 100, 40)
        seek("حجم الأيقونات (dp)", "icon_size", 40, 80, 56)
        choice("شكل الأيقونات", "icon_shape", "circle", listOf("circle", "rounded", "square", "custom", "original"), listOf("دائرة", "مربع مدوّر", "مربع", "مخصص", "الأصلي"))
        seek("استدارة الشكل المخصص %", "icon_radius", 0, 50, 30)
        row("حزمة أيقونات (Icon Pack)", Prefs.str("icon_pack", "").ifEmpty { "بدون" }) {
            val packs = AppRepository.listPacks(this)
            val labels = ArrayList<String>(); labels.add("بدون")
            packs.forEach { labels.add(it.second) }
            Ui.list(this, "Icon Pack", labels) { i -> Prefs.put("icon_pack", if (i == 0) "" else packs[i - 1].first); rebuild() }
        }
        seek("حجم اسم التطبيق (sp)", "label_size", 9, 16, 11)
        sw("إظهار أسماء التطبيقات", "show_labels", true)
        choice("الخط", "font", "medium", listOf("default", "medium", "bold", "serif"), listOf("افتراضي", "متوسط", "عريض", "Serif"))

        section("الشاشة الرئيسية")
        seek("المسافة بين الأيقونات (dp)", "spacing", 0, 24, 8)
        seek("أعمدة الشبكة", "grid_cols", 3, 8, 4)
        seek("صفوف الشبكة", "grid_rows", 3, 12, 6)
        seek("الهوامش الجانبية للشبكة (dp)", "grid_pad", 0, 32, 6)
        sw("كلمة (بحث) بدل النقاط عند الاستقرار", "search_pill", true)
        seek("الانتظار قبل ظهور البحث (ثانية)", "search_delay", 1, 15, 5)
        sw("نقاط الصفحات", "show_dots", true)
        sw("شاشة تحميل بأيقونة التطبيق عند فتحه", "launch_splash", true)
        sw("Parallax للخلفية", "wp_parallax", true)
        row("تغيير الخلفية") { startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "الخلفية")) }

        row("الصفحة الرئيسية الافتراضية", StateStore.workspaces.getOrNull(StateStore.homeIndex)?.name) {
            Ui.list(this, "اختر الصفحة الرئيسية", StateStore.workspaces.map { it.name }) { i -> StateStore.homeIndex = i; StateStore.flush(); rebuild() }
        }
        row("إدارة المساحات (إضافة، حذف، ترتيب، اسم، لون)") {
            startActivity(Intent(this, com.sparrow.launcher.home.HomeActivity::class.java).setAction(Intent.ACTION_MAIN).putExtra("overview", true))
        }

        section("App Drawer")
        seek("أعمدة الدرج", "drawer_cols", 3, 7, 4)
        choice("الترتيب", "drawer_sort", "az", listOf("az", "za", "recent", "used"), listOf("أبجدي", "أبجدي عكسي", "الأحدث استخداماً", "الأكثر استخداماً"))
        sw("شريط التصنيفات", "drawer_chips", true)
        row("التطبيقات المخفية", "اضغط لإظهار تطبيق") {
            val h = StateStore.hidden.toList()
            if (h.isEmpty()) Ui.toast(this, "لا توجد تطبيقات مخفية")
            else Ui.list(this, "اضغط لإظهار", h.map { AppRepository.byKey[it]?.label ?: it }) { i -> StateStore.hidden.remove(h[i]); StateStore.flush(); Prefs.put("_touch", true) }
        }

        section("الإيماءات")
        for ((name, label) in GestureActions.NAMES) {
            row(label, GestureActions.typeLabel(GestureActions.spec(name))) { pickGesture(name) }
        }

        section("Dock")
        sw("إظهار الـDock", "dock_show", true)
        seek("حجم الأيقونات (dp)", "dock_size", 40, 72, 54)
        seek("شفافية الخلفية %", "dock_alpha", 0, 100, 55)
        seek("عدد التطبيقات الظاهرة قبل التمرير", "dock_max", 3, 9, 5)

        section("Widgets")
        seek("الحواف الداخلية (dp)", "widget_pad", 0, 12, 4)
        seek("استدارة الزوايا (dp)", "widget_radius", 0, 28, 18)
        sw("زر ⋮ على الويدجت (تكبير/تصغير/نقل)", "widget_handle", true)
        sw("كلمات الأغاني المتزامنة في لوحة التحكم (تتصل بـ lrclib.net)", "lyrics", false)

        section("المجلدات")
        sw("حركة فتح وإغلاق المجلد", "folder_anim", true)
        seek("أعمدة التطبيقات داخل المجلد", "folder_cols", 3, 6, 4)
        choice("طريقة عرض المجلدات الجديدة", "folder_view", "orbit", listOf("orbit", "list"), listOf("خيوط (دائري)", "قائمة"))

        section("Workspace")
        choice("نوع الانتقال", "transition", "carousel", listOf("carousel", "depth", "flat"), listOf("3D Carousel", "Depth", "عادي"))
        seek("قوة الـPerspective", "perspective", 0, 100, 60)
        seek("قوة الـParallax", "parallax", 0, 100, 60)
        sw("تقليل الحركة", "reduce_motion", false)

        section("النسخ الاحتياطي والأخيرة")
        row("تصدير نسخة احتياطية", "يُحفظ في مجلد Download باسم SparrowBackup") { exportBackup() }
        row("استرجاع نسخة احتياطية", "اختر ملف SparrowBackup.json") {
            try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE), 11) } catch (_: Exception) {}
        }
        row("التطبيقات الأخيرة الحقيقية", "اختياري: فعّل Sparrow من (الوصول لبيانات الاستخدام)") {
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) {}
        }

        section("النظام")
        row("تعيين Sparrow كلانشر افتراضي") {
            try {
                if (Build.VERSION.SDK_INT >= 29) startActivityForResult(getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_HOME), 7)
                else startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (e: Exception) { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        }
        row("تفعيل الوصول للإشعارات (لمشغل الموسيقى)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
    }

    private fun exportBackup() {
        try {
            val json = org.json.JSONObject()
            json.put("app", "sparrow")
            json.put("state", org.json.JSONObject(StateStore.exportState()))
            json.put("prefs", Prefs.exportJson())
            val cv = android.content.ContentValues()
            cv.put(android.provider.MediaStore.Downloads.DISPLAY_NAME, "SparrowBackup.json")
            cv.put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/json")
            cv.put(android.provider.MediaStore.Downloads.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
            val uri = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw Exception("insert")
            contentResolver.openOutputStream(uri)?.use { it.write(json.toString().toByteArray()) }
            Ui.toast(this, "تم الحفظ في Download")
        } catch (e: Exception) { Ui.toast(this, "تعذر الحفظ") }
    }

    private fun restoreBackup(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: return
            val o = org.json.JSONObject(text)
            if (o.optString("app") != "sparrow") { Ui.toast(this, "هذا ليس ملف نسخة Sparrow"); return }
            Ui.confirm(this, "استبدال الترتيب والإعدادات الحالية بالنسخة الاحتياطية؟") {
                if (StateStore.importState(o.getJSONObject("state").toString())) {
                    Prefs.importJson(o.getJSONObject("prefs"))
                    Ui.toast(this, "تم الاسترجاع. ارجع للشاشة الرئيسية")
                } else Ui.toast(this, "الملف تالف، لم يتغير شيء")
            }
        } catch (e: Exception) { Ui.toast(this, "تعذر قراءة الملف") }
    }

    private fun pickGesture(name: String) {
        val types = GestureActions.TYPES
        Ui.list(this, "الإجراء", types.map { it.second }) { i ->
            when (types[i].first) {
                "app" -> { val a = AppRepository.apps; Ui.list(this, "اختر تطبيقاً", a.map { it.label }) { j -> save(name, "app|" + a[j].key) } }
                "sysset" -> { val s = GestureActions.SYSTEM_SETTINGS; Ui.list(this, "اختر إعداداً", s.map { it.first }) { j -> save(name, "sysset|" + s[j].second) } }
                "workspace" -> { val w = StateStore.workspaces; Ui.list(this, "اختر مساحة", w.map { it.name }) { j -> save(name, "workspace|$j") } }
                "image" -> {
                    pendingGesture = name
                    try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 9) } catch (_: Exception) {}
                }
                else -> save(name, types[i].first)
            }
        }
    }

    private fun save(name: String, spec: String) { Prefs.put("g_$name", spec); rebuild() }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 11 && res == RESULT_OK) { data?.data?.let { restoreBackup(it) }; return }
        if (req == 9 && res == RESULT_OK) {
            val u: Uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            save(pendingGesture, "image|$u")
        }
    }
}
