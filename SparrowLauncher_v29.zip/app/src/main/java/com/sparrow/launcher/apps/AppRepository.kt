package com.sparrow.launcher.apps

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.util.Xml
import com.sparrow.launcher.core.Bg
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Ui
import com.sparrow.launcher.persistence.StateStore
import org.xmlpull.v1.XmlPullParser
import java.util.concurrent.ConcurrentHashMap

/** تطبيق مثبت فعلياً على الجهاز (يُقرأ عبر Launcher Intent بدون صلاحيات واسعة) */
class AppInfo(
    val key: String,       // pkg/class
    val pkg: String,
    val cls: String,
    val label: String,
    val category: String,  // تصنيف تلقائي
    val system: Boolean
) {
    val lower: String = label.lowercase()
    val component: ComponentName get() = ComponentName(pkg, cls)
}

/** التصنيفات الذكية (عربي/إنجليزي). التصنيفات المخصصة تبدأ بـ "c:" */
object Categories {
    val builtin = listOf("comm", "social", "games", "media", "prod", "tools", "finance", "edu", "system", "other")
    private val names = mapOf(
        "comm" to "التواصل", "social" to "اجتماعي", "games" to "الألعاب", "media" to "الوسائط",
        "prod" to "الإنتاجية", "tools" to "الأدوات", "finance" to "المال", "edu" to "التعليم",
        "system" to "النظام", "other" to "أخرى"
    )

    fun name(id: String): String = if (id.startsWith("c:")) id.substring(2) else (names[id] ?: id)

    fun of(app: AppInfo): String = StateStore.categories[app.key] ?: app.category

    /** تصنيف تلقائي من معلومات التطبيق (فئة النظام + كلمات مفتاحية في الاسم/الحزمة) */
    fun auto(ai: ApplicationInfo, label: String): String {
        val p = ai.packageName.lowercase()
        val l = label.lowercase()
        fun has(vararg k: String): Boolean = k.any { p.contains(it) || l.contains(it) }

        if (ai.category == ApplicationInfo.CATEGORY_GAME) return "games"
        if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return "games"
        if (has("supercell", "garena", "pubg", "roblox", "minecraft", "mojang", "mihoyo", "game", "ألعاب", "لعبة")) return "games"
        if (has("whatsapp", "telegram", "messenger", "signal", "viber", "dialer", "contacts", "mms", "messag", "sms", "gmail", "skype", "zoom", "teams",
                "واتساب", "تيليجرام", "رسائل", "هاتف", "جهات", "بريد", "com.android.phone")) return "comm"
        if (has("facebook", "instagram", "twitter", "tiktok", "snapchat", "reddit", "linkedin", "pinterest", "threads", "discord",
                "فيسبوك", "انستغرام", "تيك")) return "social"
        if (has("spotify", "youtube", "music", "video", "netflix", "photos", "gallery", "camera", "podcast", "vlc", "soundcloud", "anghami", "radio",
                "كاميرا", "صور", "معرض", "موسيقى", "فيديو")) return "media"
        if (has("bank", "wallet", "finance", "crypto", "binance", "paypal", "pay.", "بنك", "محفظة")) return "finance"
        if (has("duolingo", "khan", "coursera", "udemy", "dictionary", "translate", "school", "edu", "learn", "تعليم", "قاموس", "ترجمة")) return "edu"
        if (has("docs", "sheets", "slides", "office", "word", "excel", "powerpoint", "calendar", "keep", "notes", "note", "drive", "dropbox", "notion", "todo", "task", "pdf",
                "مفكرة", "ملاحظات", "تقويم", "مستندات")) return "prod"
        if (has("calculator", "clock", "files", "filemanager", "documentsui", "terminal", "termux", "browser", "chrome", "vpn", "weather", "flashlight", "compass", "scanner",
                "حاسبة", "ساعة", "الملفات", "متصفح", "طقس")) return "tools"
        return when (ai.category) {
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_IMAGE -> "media"
            ApplicationInfo.CATEGORY_SOCIAL -> "social"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "prod"
            ApplicationInfo.CATEGORY_MAPS, ApplicationInfo.CATEGORY_NEWS -> "tools"
            else -> if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) "system" else "other"
        }
    }
}

/** حزمة أيقونات (ADW / Nova): تربط Component باسم Drawable داخل الحزمة */
class IconPack(val pkg: String, val res: Resources, val map: HashMap<String, String>)

object AppRepository {
    @Volatile
    var apps: List<AppInfo> = emptyList()
        private set

    @Volatile
    var byKey: Map<String, AppInfo> = emptyMap()
        private set

    @Volatile
    private var icons: Map<String, Bitmap> = emptyMap()
    private val fileCache = ConcurrentHashMap<String, Bitmap>()

    /** الأيقونة النهائية: المخصصة من المستخدم، وإلا أيقونة الحزمة/النظام (المخزنة مسبقاً) */
    fun icon(key: String): Bitmap? {
        val path = StateStore.icons[key]
        if (path != null) {
            val b = bitmapFile(path)
            if (b != null) return b
        }
        return icons[key]
    }

    fun bitmapFile(path: String): Bitmap? {
        val c = fileCache[path]
        if (c != null) return c
        val b = BitmapFactory.decodeFile(path) ?: return null
        fileCache[path] = b
        return b
    }

    /** قراءة التطبيقات في خيط خلفي ثم استدعاء done على الخيط الرئيسي */
    fun load(ctx: Context, done: () -> Unit) {
        val app = ctx.applicationContext
        Bg.io.execute {
            try {
                val pm = app.packageManager
                val res = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val px = Ui.dp(app, Prefs.iconSize).coerceIn(96, 192)
                val masked = Prefs.iconShape == "original"
                val packName = Prefs.iconPack
                val pack = if (packName.isEmpty()) null else loadPack(app, packName)
                val list = ArrayList<AppInfo>()
                val map = HashMap<String, AppInfo>()
                val newIcons = ConcurrentHashMap<String, Bitmap>()
                for (ri in res) {
                    val ai = ri.activityInfo ?: continue
                    if (ai.packageName == app.packageName) continue
                    val key = ai.packageName + "/" + ai.name
                    if (map.containsKey(key)) continue
                    val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { ai.packageName }
                    val info = AppInfo(
                        key, ai.packageName, ai.name, label,
                        Categories.auto(ai.applicationInfo, label),
                        (ai.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    )
                    list.add(info)
                    map[key] = info
                    try {
                        val fromPack = if (pack != null) packDrawable(pack, info.component) else null
                        val bmp = if (fromPack != null) render(fromPack, px, false, 0f)
                        else render(ri.loadIcon(pm), px, masked, 0.08f)
                        newIcons[key] = bmp
                    } catch (e: Throwable) {
                        // أيقونة تالفة: نتجاهلها ويُعرض التطبيق بدون صورة بدل أن ينهار اللانشر
                    }
                }
                list.sortBy { it.lower }
                apps = list
                byKey = map
                icons = newIcons
            } catch (e: Throwable) {
                // فشل القراءة: نبقي القائمة السابقة
            }
            Bg.main.post { done() }
        }
    }

    /** يحوّل Drawable إلى Bitmap مربع. الأيقونات التكيّفية تُرسم بدون قناع النظام لنطبّق عليها الشكل الذي يختاره المستخدم */
    private fun render(d: Drawable, px: Int, masked: Boolean, inset: Float): Bitmap {
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        if (d is AdaptiveIconDrawable && !masked) {
            // طبقات الأيقونة التكيّفية 108dp والجزء الظاهر 72dp => النسبة 1.5
            val big = (px * 1.5f).toInt()
            val tmp = Bitmap.createBitmap(big, big, Bitmap.Config.ARGB_8888)
            val tc = Canvas(tmp)
            d.background?.let { it.setBounds(0, 0, big, big); it.draw(tc) }
            d.foreground?.let { it.setBounds(0, 0, big, big); it.draw(tc) }
            val off = (big - px) / 2
            c.drawBitmap(tmp, Rect(off, off, off + px, off + px), Rect(0, 0, px, px), null)
            tmp.recycle()
        } else if (d is AdaptiveIconDrawable) {
            d.setBounds(0, 0, px, px)
            d.draw(c)
        } else {
            val i = (px * inset).toInt()
            d.setBounds(i, i, px - i, px - i)
            d.draw(c)
        }
        return out
    }

    /** أيقونات حزمة (حتى 400) لعرضها في شبكة الاختيار */
    fun packIcons(ctx: Context, pkg: String): List<Pair<String, Drawable>> {
        val pk = loadPack(ctx, pkg) ?: return emptyList()
        val out = ArrayList<Pair<String, Drawable>>()
        for (n in pk.map.values.distinct().take(400)) {
            val id = pk.res.getIdentifier(n, "drawable", pkg)
            if (id == 0) continue
            try { out.add(Pair(n, pk.res.getDrawable(id, null))) } catch (_: Exception) {}
        }
        return out
    }

    fun toBitmap(d: Drawable, px: Int): Bitmap = render(d, px, false, 0f)

    // ------------------------------------------------------------ Icon packs
    fun listPacks(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val out = LinkedHashMap<String, String>()
        for (action in listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.gau.go.launcherex.theme")) {
            try {
                for (ri in pm.queryIntentActivities(Intent(action), 0)) {
                    out[ri.activityInfo.packageName] = ri.loadLabel(pm).toString()
                }
            } catch (_: Exception) {
            }
        }
        return out.map { Pair(it.key, it.value) }
    }

    private fun loadPack(ctx: Context, pkg: String): IconPack? {
        try {
            val res = ctx.packageManager.getResourcesForApplication(pkg)
            val map = HashMap<String, String>()
            var parser: XmlPullParser? = null
            val id = res.getIdentifier("appfilter", "xml", pkg)
            if (id != 0) {
                parser = res.getXml(id)
            } else {
                try {
                    val p = Xml.newPullParser()
                    p.setInput(res.assets.open("appfilter.xml"), null)
                    parser = p
                } catch (_: Exception) {
                }
            }
            if (parser != null) {
                var ev = parser.eventType
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG && parser.name == "item") {
                        val comp = parser.getAttributeValue(null, "component")
                        val dr = parser.getAttributeValue(null, "drawable")
                        if (comp != null && dr != null) map[comp] = dr
                    }
                    ev = parser.next()
                }
            }
            return IconPack(pkg, res, map)
        } catch (e: Exception) {
            return null
        }
    }

    private fun packDrawable(pack: IconPack, cn: ComponentName): Drawable? {
        val name = pack.map[cn.toString()] ?: return null
        val id = pack.res.getIdentifier(name, "drawable", pack.pkg)
        if (id == 0) return null
        return try { pack.res.getDrawable(id, null) } catch (e: Exception) { null }
    }
}
