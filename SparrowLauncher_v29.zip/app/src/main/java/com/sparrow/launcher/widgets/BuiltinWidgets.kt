package com.sparrow.launcher.widgets

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextClock
import android.widget.TextView
import com.sparrow.launcher.core.Icons
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Theme
import com.sparrow.launcher.core.Ui

/** ويدجت مصنوعة داخل Sparrow (تظهر أول المنتقي قبل ويدجت التطبيقات). كلها حقيقية وتتحدث تلقائياً */
object BuiltinWidgets {
    fun create(ctx: Context, kind: String, onSearch: () -> Unit): View = when (kind) {
        "clock" -> clock(ctx)
        "date" -> date(ctx)
        "battery" -> BatteryView(ctx)
        "search" -> search(ctx, onSearch)
        else -> TextView(ctx)
    }

    private fun clock(ctx: Context): View {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.background = Theme.panel(ctx, Ui.dpf(ctx, 24f))
        val t = TextClock(ctx)
        t.format12Hour = "h:mm"
        t.format24Hour = "HH:mm"
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 46f)
        t.setTextColor(Theme.text(ctx))
        t.typeface = Prefs.typeface()
        t.gravity = Gravity.CENTER
        box.addView(t)
        val d = TextClock(ctx)
        d.format12Hour = "EEEE، d MMMM"
        d.format24Hour = "EEEE، d MMMM"
        d.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
        d.setTextColor(Theme.sub(ctx))
        d.gravity = Gravity.CENTER
        box.addView(d)
        return box
    }

    private fun date(ctx: Context): View {
        val t = TextClock(ctx)
        t.format12Hour = "EEEE d MMMM"
        t.format24Hour = "EEEE d MMMM"
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 18f)
        t.setTextColor(Theme.text(ctx))
        t.typeface = Prefs.typeface()
        t.gravity = Gravity.CENTER
        t.background = Theme.panel(ctx, Ui.dpf(ctx, 24f))
        return t
    }

    private fun search(ctx: Context, onSearch: () -> Unit): View {
        val t = Ui.text(ctx, "ابحث في التطبيقات", 15f, Theme.text(ctx), true)
        Icons.withText(ctx, t, "search", 20, Theme.text(ctx))
        t.gravity = Gravity.CENTER
        t.setPadding(Ui.dp(ctx, 18), 0, Ui.dp(ctx, 18), 0)
        t.background = Theme.panel(ctx, Ui.dpf(ctx, 26f))
        t.setOnClickListener { onSearch() }
        return t
    }
}

/** بطارية: نسبة وشريط تقدم، تتحدث عند تغير الشحن */
class BatteryView(ctx: Context) : LinearLayout(ctx) {
    private val pct = Ui.text(ctx, "--%", 28f, Theme.text(ctx), true)
    private val state = Ui.text(ctx, "", 11f, Theme.sub(ctx))
    private val bar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal)
    private val rec = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { update(i) }
    }

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        background = Theme.panel(ctx, Ui.dpf(ctx, 24f))
        setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 8), Ui.dp(ctx, 12), Ui.dp(ctx, 8))
        bar.max = 100
        bar.progressTintList = android.content.res.ColorStateList.valueOf(Theme.ACCENT)
        addView(pct)
        addView(bar, LayoutParams(Ui.dp(ctx, 70), Ui.dp(ctx, 6)).apply { topMargin = Ui.dp(ctx, 4) })
        addView(state)
    }

    private fun update(i: Intent?) {
        if (i == null) return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val p = if (scale > 0) level * 100 / scale else 0
        pct.text = "$p%"
        bar.progress = p
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        state.text = if (st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL) "قيد الشحن" else ""
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        update(context.registerReceiver(rec, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        try { context.unregisterReceiver(rec) } catch (_: Exception) {}
    }
}
