package com.sparrow.launcher.home

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import com.sparrow.launcher.core.Prefs
import com.sparrow.launcher.core.Ui
import kotlin.math.abs
import kotlin.math.min

/**
 * صفحة Workspace: شبكة خلايا. كل عنصر له (col,row,sx,sy).
 * الحسابات تتم مرة واحدة في onMeasure، ولا تُعاد بناء العناصر عند اللمس.
 */
class CellLayout(ctx: Context) : ViewGroup(ctx) {

    class LP(var col: Int, var row: Int, var sx: Int = 1, var sy: Int = 1) :
        ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    var cols = 4
        private set
    var rows = 6
        private set
    var cellW = 0
        private set
    var cellH = 0
        private set
    var tint = 0
    var showGrid = false
        set(v) {
            field = v
            invalidate()
        }

    /** الخلية التي يمرّ فوقها العنصر أثناء السحب (تُلوَّن للتوضيح) */
    var hover: IntArray? = null
        set(v) {
            field = v
            invalidate()
        }

    var lastX = 0f
        private set
    var lastY = 0f
        private set
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var padPx = 0

    init {
        setWillNotDraw(false)
        clipChildren = false
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = MeasureSpec.getSize(hSpec)
        cols = Prefs.cols
        rows = Prefs.rows
        padPx = Ui.dp(context, Prefs.gridPad)
        cellW = (w - 2 * padPx) / cols
        val labelH = if (Prefs.showLabels) (Prefs.labelSize * 1.6f).toInt() else 0
        val want = Ui.dp(context, Prefs.iconSize + labelH + Prefs.spacing * 2 + 6)
        cellH = min(if (rows > 0) h / rows else want, want)
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as LP
            c.measure(
                MeasureSpec.makeMeasureSpec(cellW * lp.sx, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(cellH * lp.sy, MeasureSpec.EXACTLY)
            )
        }
        setMeasuredDimension(w, h)
    }

    private fun originX(): Int = padPx + (width - 2 * padPx - cellW * cols) / 2

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val ox = originX()
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as LP
            val x = ox + lp.col * cellW
            val y = lp.row * cellH
            c.layout(x, y, x + cellW * lp.sx, y + cellH * lp.sy)
        }
    }

    override fun onDraw(canvas: Canvas) {
        if ((tint ushr 24) != 0) canvas.drawColor(tint)
        drawHover(canvas)
        if (showGrid) {
            gridPaint.color = 0x33FFFFFF
            val ox = originX().toFloat()
            val inset = Ui.dpf(context, 4f)
            val rad = Ui.dpf(context, 12f)
            for (c in 0 until cols) for (r in 0 until rows) {
                canvas.drawRoundRect(
                    RectF(ox + c * cellW + inset, r * cellH + inset, ox + (c + 1) * cellW - inset, (r + 1) * cellH - inset),
                    rad, rad, gridPaint
                )
            }
        }
    }

    private fun drawHover(canvas: Canvas) {
        val h = hover ?: return
        gridPaint.color = 0x557EA6FF
        val ox = originX().toFloat()
        val inset = Ui.dpf(context, 4f)
        canvas.drawRoundRect(
            RectF(ox + h[0] * cellW + inset, h[1] * cellH + inset, ox + (h[0] + 1) * cellW - inset, (h[1] + 1) * cellH - inset),
            Ui.dpf(context, 14f), Ui.dpf(context, 14f), gridPaint
        )
    }

    /** الخلية (col,row) تحت نقطة لمس، أو null */
    fun cellAt(x: Float, y: Float): IntArray? {
        if (cellW == 0 || cellH == 0) return null
        val c = ((x - originX()) / cellW).toInt()
        val r = (y / cellH).toInt()
        if (x < originX() || c !in 0 until cols || r !in 0 until rows) return null
        return intArrayOf(c, r)
    }

    /** العنصر تحت نقطة بإحداثيات الشاشة (لتجاهل الإيماءات فوق الويدجت) */
    fun hitChild(rawX: Float, rawY: Float): View? {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val x = rawX - loc[0]
        val y = rawY - loc[1]
        for (i in childCount - 1 downTo 0) {
            val c = getChildAt(i)
            if (x >= c.left && x <= c.right && y >= c.top && y <= c.bottom) return c
        }
        return null
    }

    /** Parallax داخل الصفحة: الويدجت تتحرك أسرع من المجلدات والتطبيقات فيظهر العمق */
    fun applyParallax(off: Float, dir: Float, amount: Float) {
        val w = width.toFloat()
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val f = when (c.tag) {
                "widget" -> 0.10f
                "folder" -> 0.06f
                else -> 0.035f
            }
            c.translationX = dir * off * w * f * amount
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        lastX = ev.x
        lastY = ev.y
        return super.dispatchTouchEvent(ev)
    }

    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is LP
    override fun generateDefaultLayoutParams(): ViewGroup.LayoutParams = LP(0, 0)
    override fun generateLayoutParams(attrs: AttributeSet?): ViewGroup.LayoutParams = LP(0, 0)
    override fun generateLayoutParams(p: ViewGroup.LayoutParams?): ViewGroup.LayoutParams = LP(0, 0)
}
